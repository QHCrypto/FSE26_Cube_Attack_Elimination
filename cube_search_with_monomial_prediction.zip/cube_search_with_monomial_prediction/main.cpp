#include<iostream>
#include<fstream>
#include<vector>
#include<bitset>
#include<algorithm>
#include<thread>
#include<mutex>
#include<future>
#include<sstream>
#include<malloc.h>
#include<array>
#include"log.h"
#include"deg.h"
#include"thread_pool.h"
#include"trivium.h"
#include"triviumtrack.h"
#include"newtrivium.h"
#include"triviumcallback.h"
#include"triviumframework.h"
#include"main.h"

using namespace std;
using namespace thread_pool;

using std::chrono::high_resolution_clock;
using std::chrono::duration_cast;
using std::chrono::seconds;
namespace fs = std::filesystem;


mutex stream_mutex;
mutex map_mutex;
mutex term_mutex;


vector<vector<int>> readFileTo2DVector(const string& filePath) {
    ifstream inputFile(filePath);
    if (!inputFile.is_open()) {
        cerr << "Error: Unable to open file " << filePath << endl;
        return {};
    }   
    vector<vector<int>> result;
    string line;   
    while (getline(inputFile, line)) {        
        vector<int> row;
        stringstream ss(line);
        int number;        
        while (ss >> number) {
            row.push_back(number);
        }
        if ((row.size() > 20)&&(row.size() <= 55))
        {
            result.push_back(row);
        }        
    }
    inputFile.close();
    return result;
}

vector<vector<int>> readFileTo2DVector1(const string& filePath) {
    ifstream inputFile(filePath);
    if (!inputFile.is_open()) {
        cerr << "Error: Unable to open file " << filePath << endl;
        return {};
    }   
    vector<vector<int>> result;
    string line;   
    while (getline(inputFile, line)) {        
        vector<int> row;
        stringstream ss(line);
        int number;        
        while (ss >> number) {
            row.push_back(number);
        }
        if ((row.size() > 5))
        {
            result.push_back(row);
        }        
    }
    inputFile.close();
    return result;
}

set<vector<int>> readFileToset1(const string& filePath) {
    ifstream inputFile(filePath);
	// cout << "Trying to open: " << filePath << endl;
    if (!inputFile.is_open()) {
        cerr << "Error: Unable to open file " << filePath << endl;
        return {};
    }   
    set<vector<int>> result;
    string line;   
    while (getline(inputFile, line)) {        
        vector<int> row;
        stringstream ss(line);
        int number;        
        while (ss >> number) {
            row.push_back(number);
        }
        if(row.size()>3) {
            result.insert(row);
        }
    }
    inputFile.close();
	// cout<<"AA"<<endl;
    return result;
}

set<vector<int>> getRangeFromSet(const set<vector<int>>& s, size_t m, size_t n) {
    set<vector<int>> result;
    if (m > n || s.size() <= m) {
        return result;
    }
    n = min(n, s.size() - 1);
    auto it = s.begin();
    advance(it, m);
    for (size_t i = m; i <= n; ++i) {
        result.insert(*it);
        ++it;
    }
    return result;
}

set<int> extractIsolatedNumbers1(const vector<int>& sortedVec) {
    set<int> result;
    int n = sortedVec.size();
    
    if (n == 0) {
        return result; 
    }
    
    for (int i = 0; i < n; ++i) {
        bool isIsolated = true;
        
        if (i == 0) { 
            if (n > 1 && sortedVec[i+1] - sortedVec[i] == 1) {
                isIsolated = false;
            }
        } 
        else if (i == n - 1) { 
            if (sortedVec[i] - sortedVec[i-1] == 1) {
                isIsolated = false;
            }
        } 
        else { 
            if (sortedVec[i] - sortedVec[i-1] == 1 || sortedVec[i+1] - sortedVec[i] == 1) {
                isIsolated = false;
            }
        }
        
        if (isIsolated) {
            result.insert(sortedVec[i]);
        }
    }
    
    return result;
}

// ************************************************************************************************

//  When you want to search cubes at round N, you should change the value FASTBOUND into N-330.

//  For example, if you want to search cubes at round 840, you should set FASTBOUND = 510.

//  If you want to search cubes at round 845, you should set FASTBOUND = 515.

// ************************************************************************************************


void cube_expand840() {
	int Round = 840;
    int cube_length = 58; //set the mother cube size.
    // select initial cube from "840_37_0_0solutions.txt"

	vector<int> cubeIndex = {1, 3, 5, 7, 9, 12, 14, 16, 18, 20, 22, 25, 27, 29, 31, 33, 35, 37, 40, 42, 44, 46, 48, 50, 52, 55, 57, 59, 61, 63, 65, 67, 70, 72, 74, 76, 78};
    string filename = to_string(Round) + "_expand.txt";
    set<int> id_set;
    for (int id = 0; id < 80; id++) {
        id_set.insert(id);
    }
    cube_expand(Round, cubeIndex, id_set, filename, cube_length);
}

void cube_expand845() {
	int Round = 845;
    int cube_length = 54; 
    // select initial cube from "845_37_3_6solutions.txt"
	vector<int> cubeIndex = {0,2,4,7,9,11,13,15,17,19,22,24,26,28,30,32,34,37,39,41,43,45,47,49,52,54,56,58,60,62,64,67,69,71,73,75,79};
    string filename = to_string(Round) + "_expand.txt";
    set<int> id_set;
    for (int id = 0; id < 80; id++) {
        id_set.insert(id);
    }
    cube_expand(Round, cubeIndex, id_set, filename, cube_length);
}

// using isolated Variable Preservation

void select_subcube840() {
	int Round = 840;
    int threshold = 17;
	vector<int> cube = {0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,27,29,30,31,32,33,34,35,36,37,38,40,42,44,46,48,50,52,55,57,59,61,63,65,67,70,72,74,76,77,78,79}; 
    set<vector<int>> cubeIndex;
    cubeIndex.insert(cube);
	string filename = to_string(Round) + "_subcubes.txt";
    select_subcube(Round, cubeIndex, filename,threshold);
}


// using isolated Variable Preservation
void select_subcube845_2() {
	int Round = 845;
    int threshold = 120;
	vector<int> cube = {0,2,4,6,8,10,13,15,17,19,21,23,26,28,30,32,34,36,38,41,43,45,47,49,51,53,56,58,60,62,64,66,68,71,73,75,79,77,11,1,3,9,12,29,5,7,25,31,37,76,39,44,54,24}; 
    set<vector<int>> cubeIndex;
    cubeIndex.insert(cube);
	string filename = to_string(Round) + "_subcubes.txt";
    select_subcube_2(Round, cubeIndex, filename,threshold);
}

// using initial-Cube Preservation
void select_subcube845_1() {
	int Round = 845;
    int threshold = 120;
	vector<int> cube = {0,2,4,6,8,10,13,15,17,19,21,23,26,28,30,32,34,36,38,41,43,45,47,49,51,53,56,58,60,62,64,66,68,71,73,75,79,77,11,1,3,9,12,29,5,7,25,31,37,76,39,44,54,24}; 
    set<vector<int>> cubeIndex;
    cubeIndex.insert(cube);
    set<int> fix_bit;
    for (size_t i = 0; i < 37; i++)
    {
        fix_bit.insert(cube[i]);
    }
    
	string filename = to_string(Round) + "_subcubes.txt";
    select_subcube_1(Round, cubeIndex, filename,threshold,fix_bit);
}


int main() {
    // cube_expand840();
    // cube_expand845();
    // select_subcube840();
    // select_subcube845_1();
    // select_subcube845_2();
    return 0;
}