#include"gurobi_c++.h"
#include <string.h>
#include<iostream>
#include<fstream>
#include<string>
#include<sstream>
#include<vector>
#include<bitset>
#include<set>
#include<algorithm>
#include<map>
#include<iomanip>
#include<utility>
#include<math.h>
#include<time.h>
#include<stdlib.h>
#include <iterator>


#ifndef __MAIN_H__
#define __MAIN_H__

//#define N 542
// #define N 542
#define N 542  //83轮截断
#define M 80
#define INDEG -4096


#define BOUND 200000 //prevent out of memory
#define BOUND1 79
#define TIMELIMIT 1200 //time limit for optimizer


using namespace std;


template <size_t T> struct cmpBitset {
	bool operator()(const bitset<T>& a, const bitset<T>& b) const {
		for (int i = T - 1; i >= 0; i--) {
			if (a[i] < b[i])
				return true;
			else if (a[i] > b[i])
				return false;
		}
		return false;
	}
};

class Vmono {
public: bitset<M> v;
public:
	friend ostream & operator <<(ostream &out, Vmono &vmono);
	friend istream & operator>>(istream &in, Vmono & vmono);
	friend ostream & operator <<(ostream &out, const Vmono &vmono);
	friend Vmono operator*(const Vmono &vm1, const Vmono &vm2);
};

struct cmpVmono {
	bool operator()(const Vmono &vm1, const Vmono &vm2) const {
		cmpBitset<M> cmp;
		return cmp(vm1.v, vm2.v);
	}
};

class Kmono {
public: bitset<N> k;//N=542
public:
	friend ostream & operator <<(ostream &out, Kmono &kmono);
	friend istream & operator >>(istream &in, Kmono & kmono);
	friend ostream & operator <<(ostream &out, const Kmono &kmono);
	friend Kmono operator*(const Kmono &km1, const Kmono &km2);
};

struct cmpKmono {
	bool operator()(const Kmono &km1, const Kmono &km2) const {
		cmpBitset<N> cmp;//N=542
		return cmp(km1.k, km2.k);
	}
};

class Kpoly {
public: set<Kmono, cmpKmono> p;
public: 
	friend ostream & operator <<(ostream &out, Kpoly &kpoly);
	friend istream & operator >>(istream &in, Kpoly &kpoly);
	friend Kpoly operator + (const Kpoly &kpoly1, const Kpoly &kpoly2);
	friend Kpoly operator * (const Kpoly &kpoly1, const Kpoly &kpoly2);
};

class KVpoly {
public: map<Vmono, Kpoly, cmpVmono> p;
public:
	friend ostream & operator <<(ostream &out, KVpoly &kvp);
	friend istream & operator >>(istream &in, KVpoly &kvp);
	friend KVpoly operator + (const KVpoly &kvp1, const KVpoly &kvp2);
	friend KVpoly operator * (const KVpoly &kvp1, const KVpoly &kvp2);
};

void trivium_poly(vector<KVpoly>& state, int round0);
void trivium_simplify_poly(vector<KVpoly> &state, vector<Kpoly> & k_fun, int round0);
void trivium_flag_poly(bitset<80> flag, vector<KVpoly> &state, vector<KVpoly> &pstate);

int calculate_first_expand_num(int ROUND, vector<int> cubeIndex, string filename,int threshold);
void cube_expand(int ROUND, vector<int>& cubeIndex, set<int>id_set,string filename,int cube_length);
void select_subcube(int ROUND, set<vector<int>>& cubeIndex, string filename,int threshold);
void select_subcube_1(int ROUND, set<vector<int>>& cubeIndex, string filename,int threshold,set<int> fix_bit);
void select_subcube_2(int ROUND, set<vector<int>>& cubeIndex, string filename,int threshold);

int recover_spoly_from_vt(int ROUND, int THREAD_NUM, vector<int> cubeIndex, string foldername, int threshold);
void trivium_flag_poly_1(bitset<80> flag, bitset<N> key, vector<KVpoly>& state, vector<KVpoly>& pstate);
int calculate_singular_degree(int ROUND, vector<int> cubeIndex, string filename, int threshold,int outbit);


vector<int> k_count(KVpoly spoly);
vector<int> get_maxdeg(vector<KVpoly> pstate, bitset<M> cube);
vector<int> find_basis(vector<KVpoly> pstate, bitset<M> cube);

map<vector<int>, vector<int>> trivium_flag_poly_2(bitset<80> flag, bitset<N> key, vector<KVpoly>& state, vector<KVpoly>& pstate);

// 函数声明
int N0_round_model(std::vector<KVpoly> pstate, std::bitset<80> cube, int threadNumber, std::bitset<288> piconstr, KVpoly& spoly);
//void singular_1(int output_round, int output_mode, int cube_size);
#endif
