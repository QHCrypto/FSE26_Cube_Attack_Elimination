#include<malloc.h>
#include<map>
#include<cmath>
#include<vector>
#include<bitset>
#include<string>
#include"trivium.h"
#include"gurobi_c++.h" 
#include"node.h"
#include"thread_pool.h"
#include"triviumcallback.h"
#include"log.h"
#include"triviumframework.h"
#include "main.h"

using namespace std;
using namespace thread_pool;
mutex threadMutex;

const int BITSET_SIZE = 288;

vector<bitset<BITSET_SIZE>> readFileToBitsets(const string& filename) {
    vector<bitset<BITSET_SIZE>> bitsets;
    ifstream file(filename);

    if (file.is_open()) {
        string line;
        while (getline(file, line)) {
            try {
                // 将 01 串转换为 bitset
                bitset<BITSET_SIZE> bitset(line);
                bitsets.push_back(bitset);
            } catch (const invalid_argument& e) {
                cerr << "无效的 01 串: " << line << endl;
            }
        }
        file.close();
    } else {
        cerr << "无法打开文件: " << filename << endl;
    }

    return bitsets;
}

set<vector<int>> readFileToset(const string& filePath) {
    ifstream inputFile(filePath);
	// cout << "Trying to open: " << filePath << endl;
    if (!inputFile.is_open()) {
        cerr << "Error: Unable to open file " << filePath << endl;
        return {};
    }   
    set<vector<int>> result;
    string line;   
    while (getline(inputFile, line)) {        
        vector<int> row;
        stringstream ss(line);
        int number;        
        while (ss >> number) {
            row.push_back(number);
        }
        if(row.size()>3) {
            result.insert(row);
        }
    }
    inputFile.close();
	// cout<<"AA"<<endl;
    return result;
}

set<int> extractIsolatedNumbers(const vector<int>& sortedVec) {
    set<int> result;
    int n = sortedVec.size();
    
    if (n == 0) {
        return result; // 空向量直接返回
    }
    
    for (int i = 0; i < n; ++i) {
        bool isIsolated = true;
        
        if (i == 0) { // 首部元素，只需检查右边
            if (n > 1 && sortedVec[i+1] - sortedVec[i] == 1) {
                isIsolated = false;
            }
        } 
        else if (i == n - 1) { // 尾部元素，只需检查左边
            if (sortedVec[i] - sortedVec[i-1] == 1) {
                isIsolated = false;
            }
        } 
        else { // 中间元素，检查左右两边
            if (sortedVec[i] - sortedVec[i-1] == 1 || sortedVec[i+1] - sortedVec[i] == 1) {
                isIsolated = false;
            }
        }
        
        if (isIsolated) {
            result.insert(sortedVec[i]);
        }
    }
    
    return result;
}

// second Expand using divde-and-conquer
void ThreadWorkerExpand(const vector<bitset<288>>& layerTerm, const bitset<80>& cube,
	int start, int end, int step,
	map<bitset<288>, int, CMPS<288>>& layerMap, int singlethread)
{
	//map<bitset<80>, int, CMPS<80>> solutions;
	map<bitset<288>, int, CMPS<288>>  threadLayerMap;

	int END = end <= layerTerm.size() ? end : layerTerm.size();

	vector<bitset<288>> terms;


	for (int i = start; i < END; i++)
	{
		terms.clear();
		SecondBackExpandPolynomial(step, layerTerm[i], terms, singlethread);


		for (auto& it : terms)
			threadLayerMap[it] += 1;
	}

	lock_guard<mutex> guard(threadMutex);
	for (auto& it : threadLayerMap)
		layerMap[it.first] += it.second;
}

void expandFunc(bitset<80>& cube, vector<bitset<288> >& layerTerms, int& start, float time, int singlethread)
{
	vector<thread> threads;
	int THREAD_NUM = 16;
	int step = 0;
	map<bitset<288>, int, CMPS<288> > layerMap;

	while (layerMap.size() < SIZEBOUND)
	{
		step++;
		layerMap.clear();

		int size = layerTerms.size();

		int base = (size / THREAD_NUM) >= 1 ? (size / THREAD_NUM) :
			1;
		int size_multiple = base * THREAD_NUM;

		threads.clear();

		// expand the terms 
		for (int i = 0; i < THREAD_NUM; i++)
			threads.push_back(thread(ThreadWorkerExpand, ref(
				layerTerms), ref(cube), base * i, base * (i + 1), step,
				ref(layerMap), singlethread));
		for (auto& th : threads) th.join();

		if (size > size_multiple)
		{
			threads.clear();
			for (int i = 0; i < THREAD_NUM; i++)
				threads.push_back(thread(ThreadWorkerExpand, ref(
					layerTerms), ref(cube), size_multiple + i, size_multiple + i + 1, step,
					ref(layerMap), singlethread));
			for (auto& th : threads) th.join();
		}
	}

	start = start - step;

	logger("Step New " + to_string(step));
	logger("Round New " + to_string(start));
	logger(string("layerMapSize ") + to_string(layerMap.size()));

	layerTerms.clear();
	filterMap<288>(layerMap);

	for (auto& x : layerMap)
		layerTerms.emplace_back(x.first);

	filterTerms(cube, start, layerTerms);

	for (auto& x : layerTerms)
		loggerState(x.to_string(), start);
}



// second Expand using callback function

void newThreadWorkerCallBack(int rounds, int midround, bitset<80>& cube, bitset<288>& last, map<bitset<288>, int, CMPS<288> >& resMap, float time, int threads, bool mode, bool& indicator)//rounds是更高的轮数，midround是rounds减去step的轮数，last是x，表示一个在rounds的解，x是states的分量，加入一个示性变量以及一个模式选择变量
{
	vector<bitset<288>> res;
	auto status = uMidSolutionCallBack(rounds, cube, last, res, time, threads, midround);

	if (mode) {
		if (status == EXPAND)
		{
			logger("timeout" + string(" : need expand."));
			res.clear();
			SecondBackExpandPolynomial(rounds - midround, last, res, threads);
		}
	}

	else {
		if (status == EXPAND)
		{
			indicator = false; 
		}
	}

	{
		lock_guard<mutex> guard(threadMutex);
		for (auto& x : res)
			resMap[x] ++;
	}
}

void newExpandFunc(bitset<80>& cube, vector<bitset<288> >& states, int& start, int step, ThreadPool& threadpool, float time, int threads, int threshold, bool mode, bool& indicator)
{
	if (step > start)
		return;

	int midround = start - step;
	int execCnt = 0;
	ofstream sl("840_expand.log",ios::app);
	// ofstream sl("845_expand.log",ios::app);

	for (int cu = 0; cu < 80; cu++) {
		if (cube[cu] == 1) {
			sl<< cu <<" ";
		}
	}
	sl << endl;
	while ((states.size() < SIZEBOUND && start > FASTBOUND) || (start <= FASTBOUND && execCnt == 0))
	{
		map<bitset<288>, int, CMPS<288> > resMap;
		vector<std::future<void>> futures;

		for (auto& x : states)
			futures.emplace_back(threadpool.Submit(newThreadWorkerCallBack, start, midround, ref(cube), ref(x), ref(resMap), time, threads,mode,ref(indicator)));

		for (auto& x : futures)
			x.get();

		logger("from " + to_string(start) + " to " + to_string(midround) + " complete.");

		// filterMap
		filterMap<288>(resMap);

#ifdef _WIN32
#else
		showProcessMemUsage();
		malloc_trim(0);
		showProcessMemUsage();
#endif

		// save resMap
		states.clear();
		for (auto& x : resMap)
		{
			// loggerState(x.first.to_string(), midround);
			states.emplace_back(x.first);
		}

		// update start and midround and states
		start = midround;
		midround = start - step;
		if (midround < FASTBOUND) {
			midround = FASTBOUND;
		}
		filterTerms(cube, start, states);

		logger("next states Size : " + to_string(states.size()));
		execCnt++;
		
		cout << "round: " << start <<"  solutions:  " << states.size() << endl;
		sl << "round: " << start <<"  solutions:  " << states.size() << endl;
		// auto start = chrono::system_clock::now();
    	string startTime = getCurrentSystemTime(TIMEFLAG);
    	sl << "Start Time: " << startTime << endl;

		sl << "size of a: "<< states.size()<<endl;
		time = time + 100;

	}
}



//Calculate the valuable terms for singgle outbit.
int calculate_singular_degree(int ROUND, vector<int> cubeIndex, string filename, int threshold,int outbit) {
	int midround = 200;
	int step = 300;
	int expandStep = 30;
	float expandTime = 30;
	bool mode = false;
	bool indicator = true;
	bitset<80> cube{ 0 };
	for (auto& it : cubeIndex) {
		cube[it] = 1;
	}
	cout << cube << endl;

	ThreadPool thread_pool{};
    auto start = chrono::system_clock::now();
    string startTime = getCurrentSystemTime(TIMEFLAG);
    cout << "Start Time: " << startTime << endl;
	vector<bitset<288>> terms;
	int BB = Singular_BackExpand(step, terms,outbit);
	if (BB == -1)
	{
		return -1;//第一步扩展有问题
	}
	ROUND = ROUND - step;
	filterTerms(cube, ROUND, terms);

	logger(__func__ + string("First expand"));
	int singlethread = 8;
	newExpandFunc(cube, terms, ROUND, expandStep, thread_pool, expandTime, singlethread,threshold,mode ,indicator);

	int a = terms.size();
	return a;
}

//Calculate the valuable terms for outbit.

int calculate_first_expand_num(int ROUND, vector<int> cubeIndex, string filename, int threshold) {
	int midround = 200;
	int step = 300;
	int expandStep = 30;
	float expandTime = 30;

	bool mode = false;
	bool indicator = true;
	bitset<80> cube{ 0 };
	for (auto& it : cubeIndex) {
		cube[it] = 1;
	}
	cout << cube << endl;

	ThreadPool thread_pool{};
    auto start = chrono::system_clock::now();
    string startTime = getCurrentSystemTime(TIMEFLAG);
    cout << "Start Time: " << startTime << endl;
	vector<bitset<288>> terms;
	int BB = BackExpandPolynomial(step, terms); 
	if (BB == -1)
	{
		return -1;
	}
	ROUND = ROUND - step;
	filterTerms(cube, ROUND, terms);
	logger(__func__ + string("First expand"));
	int singlethread = 8;
	newExpandFunc(cube, terms, ROUND, expandStep, thread_pool, expandTime, singlethread,threshold,mode ,indicator);
	int a = terms.size(); // number of valuable terms
	ofstream cc;
	try {
		cc.open(filename, ios::app);
		if (!cc.is_open()) {
			throw std::runtime_error("Failed to open file: " + filename);
		}
	} catch (const std::exception& e) {
		cerr << "Error: " << e.what() << endl;
	} 
	
	for (auto& it : cubeIndex) {
		cc << it << " ";
	}
	cc << endl;
	cc << "vt: " << a << endl;
	cc.close();

	return a;
}

//expand the cube obtained by numeric map to a mother cube

void cube_expand(int ROUND, vector<int>& cubeIndex, set<int> id_set,string filename, int cube_length) {
	ofstream cc; 
	try {
		cc.open(filename, ios::app); 
		if (!cc.is_open()) {
			throw std::runtime_error("Failed to open file: " + filename);
		}
	} catch (const std::exception& e) {
		cerr << "Error: " << e.what() << endl;
	} 
    // Create a copy of the current cube state
    vector<int> current_cube = cubeIndex;
	bitset<M> cube;
    for (auto it : current_cube) {
        cube[it] = 1;
    }
    vector<int> outbits = {65,92,161,176,242,287}; // these outbits are the output function
	// set<int> new_id_set;
    // Calculate the number of possible expansions
    vector<pair<int, int>> add_ids;
    for (auto i: id_set) {
        if (cube[i] == 0) {
			cout << "now_add: " << i <<endl;
            vector<int> temp_cube = current_cube;
            temp_cube.push_back(i);
			for (auto& it : temp_cube) {
				cc << it << " ";
			}
			cc << endl;
			int vt_sum = 0; // this is vts of output function, by calculating every singgle outbit
			for (auto it:outbits){
				int a = calculate_singular_degree(ROUND, temp_cube, filename,500,it);
				cc << a <<" ";
				vt_sum+=a; 
			}
			cc << endl;
			cc << "vt: " << vt_sum << endl;
			add_ids.push_back(make_pair(vt_sum, i));

        }
    }
    
    // If no more expansions are possible, return
    if (add_ids.empty()) {
		cout<<"gggggg"<<endl;
        return;
    }
    
    // Otherwise, choose the best expansion and recurse
    sort(add_ids.begin(), add_ids.end());

	// int min_bound = min(25,(int)add_ids.size());
	// for(int a=0;a<min_bound;a++){
	// 	new_id_set.insert(add_ids[a].second);
	// }


    int best_a = add_ids[0].first;
    int best_id = add_ids[0].second;
	cout << best_id <<endl;
	cc << best_id <<endl;

	// id_set = new_id_set;

	// Update the cube index and recurse
    cubeIndex.push_back(best_id);
	if (cubeIndex.size() < cube_length) {
		cube_expand(ROUND, cubeIndex, id_set, filename, cube_length);
	}
	else {
		return;
	}
}

//Select subcubes from mother cube 840, using isolated Variable Preservation
void select_subcube(int ROUND, set<vector<int>>& cubeIndex, string filename,int threshold) {
	string filename_all = "all_" + filename;
	string filename_ca = "calculated_" + filename;
	ofstream cd("countdata840.log",ios::app);
	set<vector<int>> newcubes = readFileToset(filename_all);

	set<vector<int>> calculated_cubes = readFileToset(filename_ca);
	ofstream cc;
	cc.open(filename_all, ios::app);
	ofstream aa;
	aa.open(filename_ca, ios::app);

	int count = 0;
    for (auto cube : cubeIndex) {
		set<int> fix_bit = extractIsolatedNumbers(cube);
		for (int i=0; i<cube.size();++i) {
			auto fb = fix_bit.find(cube[i]);
			if (fb == fix_bit.end()) {
				cout << i << " " << cube[i]<<endl;
				vector<int> cube_copy = cube;
				sort(cube_copy.begin(),cube_copy.end());
				cube_copy.erase(cube_copy.begin()+i);
				for (auto id : cube_copy) {
					cout << id <<" ";
				}

				auto it = calculated_cubes.find(cube_copy);

				if (it == calculated_cubes.end()) {
					int a = calculate_first_expand_num(ROUND, cube_copy, filename,threshold);
					cout << "delete: " << cube[i]<<endl;
					if (a <= threshold) {
						newcubes.insert(cube_copy);
						for (auto id : cube_copy) {
							cc << id <<" ";
						}
						cc << endl;	
					}
					calculated_cubes.insert(cube_copy);
					for (auto id : cube_copy) {
						aa << id <<" ";
					}
					aa << endl;						
				}
			}
		}
		count++;
		cd << count << endl;
    }
	cubeIndex = newcubes;
	cc.close();
	aa.close();
	if ((*newcubes.begin()).size() > 46) {
		select_subcube(ROUND, cubeIndex, filename,threshold);
	}
	else {
		return;
	}
}

//Select subcubes from mother cube 845, using initial-Cube Preservation
void select_subcube_1(int ROUND, set<vector<int>>& cubeIndex, string filename,int threshold, set<int> fix_bit) {
	// this id means nothing, it is just a parameter to distinguish the file name when parallel.
	string filename_all = "all_" + filename;
	string filename_ca = "calculated_" + filename;
	ofstream cd("countdata845.log",ios::app);

	set<vector<int>> newcubes;
	ofstream al; 
	al.open(filename_all, ios::app);
	ofstream ca; 
	ca.open(filename_ca, ios::app);
	// set<int> fix_bit = {0,1,3,5,7,9,11,12,13,14,16,18,20,22,24,26,27,28,33,35,37,39,41,44,46,48,50,52,54,57,59,61,63,65,67,69,72,74,76,78};
	
	int count = 0;
    for (auto cube : cubeIndex) {
		if(cube.size() > 41){
			// line623-638 is to check whether the cube is already calculated.
			set<vector<int>> calculated_cubes = readFileToset(filename_ca);
			bool calcu = false;
			for (int i=0; i<cube.size();++i) {
				auto fb = fix_bit.find(cube[i]);
				if (fb == fix_bit.end()) {
					vector<int> cube_copy = cube;
					cube_copy.erase(cube_copy.begin()+i);
					sort(cube_copy.begin(),cube_copy.end());
					auto it = calculated_cubes.find(cube_copy);
					if (it == calculated_cubes.end()) {
						calcu = true;
						cd << count << endl;	
						break;
					}
				}
			}
	
			if(calcu) {
				int bound;
				if (cube.size() == 52) {
					bound = 110;
				}
				else if (cube.size() == 51) {
					bound = 90;
				}
				else if (cube.size() == 50) {
					bound = 75;
				}
				else if (cube.size() == 49) {
					bound = 65;
				}
				else if (cube.size() == 48) {
					bound = 53;
				}
				else if (cube.size() == 47) {
					bound = 42;
				}
				else if (cube.size() == 46) {
					bound = 35;
				}
				else if (cube.size() < 46) {
					bound = 30;
				}
				for (int i=0; i<cube.size();++i) {
					auto fb = fix_bit.find(cube[i]);
					if (fb == fix_bit.end()) {
						vector<int> cube_copy = cube;
						cube_copy.erase(cube_copy.begin()+i);
						vector<int> cube_copy_2 = cube_copy;
						sort(cube_copy.begin(),cube_copy.end());
						auto it = calculated_cubes.find(cube_copy);
						if (it == calculated_cubes.end()) {
							int a = calculate_first_expand_num(ROUND, cube_copy, filename,threshold);
							cout << "delete: " << cube[i]<<endl;
							if (a <= bound) {
								for (auto id : cube_copy) {
									al << id << " ";
								}
								al << endl;	
								al << a << endl;
								if(cube_copy.size() > 42) {
									newcubes.insert(cube_copy_2);
								}
							}
							for (auto id : cube_copy) {
								ca << id << " ";
							}
							ca << endl;
							ca << a << endl;				
						}
					}
				}
				count++;
			}
		}
	}

	cubeIndex = newcubes;
	al.close();
	ca.close();
	if (newcubes.size() < 1)
	{
		return;
	}

	if (count > 0) {
		select_subcube_1(ROUND, cubeIndex, filename,threshold,fix_bit);
	}
	else {//if every cube has been traversed, then stop
		return;
	}
}


//Select subcubes from mother cube 845, using isolated Variable Preservation
void select_subcube_2(int ROUND, set<vector<int>>& cubeIndex, string filename,int threshold) {
	string filename_ca = "calculated_" + filename;
	ofstream cd("countdata845.log",ios::app);
	set<vector<int>> newcubes;
	ofstream ca;
	ca.open(filename_ca, ios::app);
	int count = 0;
    for (auto cube : cubeIndex) {
		if(cube.size() > 41){
			set<int> fix_bit = extractIsolatedNumbers(cube);
			set<vector<int>> calculated_cubes = readFileToset(filename_ca);
			bool calcu = false;
			for (int i=0; i<cube.size();++i) {
				auto fb = fix_bit.find(cube[i]);
				if (fb == fix_bit.end()) {
					vector<int> cube_copy = cube;
					cube_copy.erase(cube_copy.begin()+i);
					sort(cube_copy.begin(),cube_copy.end());
					auto it = calculated_cubes.find(cube_copy);
					if (it == calculated_cubes.end()) {
						calcu = true;
						cd << count << endl;	
						// cd<<
						break;
					}
				}
			}
			if(calcu) {
				int bound;
				if (cube.size() == 52) {
					bound = 110;
				}
				else if (cube.size() == 51) {
					bound = 90;
				}
				else if (cube.size() == 50) {
					bound = 75;
				}
				else if (cube.size() == 49) {
					bound = 65;
				}
				else if (cube.size() == 48) {
					bound = 53;
				}
				else if (cube.size() == 47) {
					bound = 42;
				}
				else if (cube.size() < 46) {
					bound = 40;
				}
				for (int i=0; i<cube.size();++i) {
					auto fb = fix_bit.find(cube[i]);
					if (fb == fix_bit.end()) {
						vector<int> cube_copy = cube;
						cube_copy.erase(cube_copy.begin()+i);
						vector<int> cube_copy_2 = cube_copy;

						sort(cube_copy.begin(),cube_copy.end());
						auto it = calculated_cubes.find(cube_copy);
						if (it == calculated_cubes.end()) {
							int a = calculate_first_expand_num(ROUND, cube_copy, filename,threshold);
							cout << "delete: " << cube[i]<<endl;
							if (a <= bound) {

								newcubes.insert(cube_copy_2);
							}

							for (auto id : cube_copy) {
								ca << id <<" ";
							}
							ca << endl;
							ca << a << endl;						
						}
					}
				}
				count++;
			}
		}
	}
	cubeIndex = newcubes;
	// al.close();
	ca.close();
	if (newcubes.size() < 1 )
	{
		return;
	}

	if (count > 0) {//如果每个立方都遍历过了，就不算了，终止
		select_subcube_2(ROUND, cubeIndex, filename,threshold);
	}
	else {
		return;
	}
}

