# 840 Attack 


## Files
Take the folder 840_54_mothercube_attack as example

To estimate the number of key bits that can be recovered from the equations solved for each key, we performed the following operations: For keys from which at least 153 - 54 equations can be obtained, this means our testing method can directly derive the values of at least 80 - 54 = 26 individual key bits. Therefore, we only need to examine the keys from which fewer than 153 - 54 equations are obtained, to determine the minimum amount of key information that can be extracted. For this purpose, we sequentially extracted the first 30 obtained equations, then used the automated tool to calculate the number of determined variables among them. By counting the number of these keys where the count of determined variables is greater than or equal to 26, and dividing this count by the total number of randomly selected keys, we can obtain the success rate.

### `840_54_equations`
This folder stores the 30 extracted equations.

### `840_organize_spoly`
This folder contains the systems of equations to be solved, where each line represents a monomial.

### `guess_840_54_equations_parallel`
This folder records the results of our determined variables calculations using the automated tool. This tool is available at https://github.com/hadipourh/autoguess

### `log_resolve`
Contains attack results for 1000 randomly sampled keys.

For example: 125_20b69f6ec15c53dac392.log means that we can get 28 = 153 - 125 equations. 

### `solve.py`
Solve the equation for a randomly generated key

### `calculate_success_rate.py`
Calculate the success rate of the attack.

### `Output Information for solve.py (on-screen)`
"round 2": The index of the iteration.
"untested vars": The list of indices of the untested secret variables, sorted by the increasing order of the appearing times.
"to test var": The index of the variable to be tested.
"current_assigns": The list of the assignments determined in previous iterations. Specifically, ['k58=1', 'k61=0'] means k58=1 and k61=0, which obtains from previous tests.
"both_has_solutions": The list of indices of variables whose values cannot be determined.
"fix_k": Is contains the value of the untested variables.
"""
testing k61
Current assigns: ['k61=0']

Solution found in 0.29s
"""
which implies k61 == 0 maybe hold.

"""
Current assigns: ['k61=1']

Proven UNSAT in 1.16s
"""
which implies k61 == 1 is contradiciton, means k61 == 0 must hold


>>The following are an output example of solve.py.


840-Trivium (Extended 153 vars)
start
Initial key bits (80): [1, 1, 0, 0, 1, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0, 1, 1, 0, 1, 0, 1, 0, 1, 0, 0, 0, 0, 1, 1, 1, 0, 0, 1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 0, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 1, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 1, 0, 1, 0, 1, 1, 1]
Extended key bits 153: [1, 1, 0, 0, 1, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0, 1, 1, 0, 1, 0, 1, 0, 1, 0, 0, 0, 0, 1, 1, 1, 0, 0, 1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 0, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 1, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 1, 0, 1, 0, 1, 1, 1, 0, 1, 1, 0, 0, 0, 1, 1, 1, 1, 0, 1, 1, 1, 0, 1, 0, 0, 0, 1, 1, 1, 1, 1, 0, 1, 0, 1, 1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 1, 0, 1, 0, 1, 1, 1, 1, 1, 0, 1, 0, 1, 1, 1, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1]
Hex key: 31cb55835189e0f482ae
now calculate dir: 840_organize_spoly
[147, 79, 74, 75, 76, 77, 73, 71, 72, 69, 70, 78, 149, 66, 67, 148, 146, 103, 133, 116, 31, 120, 151, 118, 19, 15, 135, 40, 105, 21, 28, 53, 29, 12, 13, 95, 22, 23, 114, 41, 131, 10, 92, 17, 82, 88, 52, 42, 107, 25, 138, 38, 97, 112, 101, 51, 136, 39, 27, 90, 14, 84, 145, 30, 122, 24, 134, 26, 86, 99, 80, 150, 55, 81, 144, 49, 121, 20, 137, 110, 125, 32, 132, 44, 129, 140, 47, 18, 58, 34, 11, 60, 64, 36, 33, 142, 62, 127, 139, 4, 37, 5, 16, 123, 46, 48, 68, 119, 3, 35, 1, 65, 143, 124, 43, 9, 45, 126, 2, 152, 117, 141, 104, 130, 89, 56, 6, 8, 128, 94, 50, 7, 57, 108, 0, 115, 91, 111, 106, 109, 54, 87, 96, 102, 93, 113, 98, 100, 63, 83, 85, 59, 61]
[]
2025-07-17 13:09:25.162952
round 0
untested vars:  [147, 79, 74, 75, 76, 77, 73, 71, 72, 69, 70, 78, 149, 66, 67, 148, 146, 103, 133, 116, 31, 120, 151, 118, 19, 15, 135, 40, 105, 21, 28, 53, 29, 12, 13, 95, 22, 23, 114, 41, 131, 10, 92, 17, 82, 88, 52, 42, 107, 25, 138, 38, 97, 112, 101, 51, 136, 39, 27, 90, 14, 84, 145, 30, 122, 24, 134, 26, 86, 99, 80, 150, 55, 81, 144, 49, 121, 20, 137, 110, 125, 32, 132, 44, 129, 140, 47, 18, 58, 34, 11, 60, 64, 36, 33, 142, 62, 127, 139, 4, 37, 5, 16, 123, 46, 48, 68, 119, 3, 35, 1, 65, 143, 124, 43, 9, 45, 126, 2, 152, 117, 141, 104, 130, 89, 56, 6, 8, 128, 94, 50, 7, 57, 108, 0, 115, 91, 111, 106, 109, 54, 87, 96, 102, 93, 113, 98, 100, 63, 83, 85, 59]
to test var: 61
current_assigns:  [] 0
both_has_solutions:  [] 0
Initial phase: find one solution
testing k61
Current assigns: ['k61=0']

Solution found in 0.29s
Solution (first 153 vars): [True, True, False, False, False, False, False, True, False, False, False, True, False, False, False, False, True, False, True, True, False, False, True, False, False, True, False, True, False, True, True, False, True, True, False, True, False, False, True, True, False, False, True, True, False, True, False, True, False, True, True, True, True, True, False, False, True, True, True, True, True, False, False, False, False, True, False, True, False, False, True, True, True, False, False, True, False, True, False, False, False, True, True, True, True, False, True, True, True, True, True, True, False, True, False, True, True, False, False, False, True, True, True, True, False, False, False, False, False, False, True, False, True, False, False, True, True, False, True, False, True, False, True, True, False, False, False, True, False, True, True, True, True, True, True, False, False, True, True, True, True, False, True, True, False, True, False, True, False, False, False, False, True]
Go to next phase
fix_k:  [148, -80, -75, 76, -77, 78, -74, 72, 73, -70, 71, -79, -150, -67, 68, -149, -147, 104, 134, 117, -32, 121, -152, 119, 20, -16, -136, -41, -106, -22, -29, 54, 30, -13, -14, 96, 23, -24, -115, -42, 132, -11, -93, -18, 83, 89, 53, 43, -108, 26, 139, 39, -98, 113, 102, 52, -137, 40, 28, 91, -15, 85, 146, 31, 123, -25, 135, -27, 87, -100, -81, -151, -56, 82, -145, 50, -122, -21, 138, 111, -126, 33, 133, -45, 130, 141, 48, 19, 59, -35, 12, 61, -65, -37, 34, 143, -63, 128, 140, -5, -38, -6, 17, 124, -47, -49, -69, -120, -4, 36, 2, 66, 144, -125, 44, -10, 46, -127, -3, 153, -118, -142, -105, 131, 90, 57, -7, -9, -129, -95, 51, 8, 58, -109, 1, 116, 92, -112, -107, -110, -55, 88, 97, 103, 94, -114, -99, 101, -64, 84, -86, 60]
2025-07-17 13:09:25.845266
round 0
untested vars:  [147, 79, 74, 75, 76, 77, 73, 71, 72, 69, 70, 78, 149, 66, 67, 148, 146, 103, 133, 116, 31, 120, 151, 118, 19, 15, 135, 40, 105, 21, 28, 53, 29, 12, 13, 95, 22, 23, 114, 41, 131, 10, 92, 17, 82, 88, 52, 42, 107, 25, 138, 38, 97, 112, 101, 51, 136, 39, 27, 90, 14, 84, 145, 30, 122, 24, 134, 26, 86, 99, 80, 150, 55, 81, 144, 49, 121, 20, 137, 110, 125, 32, 132, 44, 129, 140, 47, 18, 58, 34, 11, 60, 64, 36, 33, 142, 62, 127, 139, 4, 37, 5, 16, 123, 46, 48, 68, 119, 3, 35, 1, 65, 143, 124, 43, 9, 45, 126, 2, 152, 117, 141, 104, 130, 89, 56, 6, 8, 128, 94, 50, 7, 57, 108, 0, 115, 91, 111, 106, 109, 54, 87, 96, 102, 93, 113, 98, 100, 63, 83, 85, 59]
to test var: 61
current_assigns:  [] 0
both_has_solutions:  [] 0
Second phase, VARIFY
testing k61 == 0
Current assigns: ['k61=1']

Proven UNSAT in 1.16s
round is done

fix_k:  [148, -80, -75, 76, -77, 78, -74, 72, 73, -70, 71, -79, -150, -67, 68, -149, -147, 104, 134, 117, -32, 121, -152, 119, 20, -16, -136, -41, -106, -22, -29, 54, 30, -13, -14, 96, 23, -24, -115, -42, 132, -11, -93, -18, 83, 89, 53, 43, -108, 26, 139, 39, -98, 113, 102, 52, -137, 40, 28, 91, -15, 85, 146, 31, 123, -25, 135, -27, 87, -100, -81, -151, -56, 82, -145, 50, -122, -21, 138, 111, -126, 33, 133, -45, 130, 141, 48, 19, 59, -35, 12, 61, -65, -37, 34, 143, -63, 128, 140, -5, -38, -6, 17, 124, -47, -49, -69, -120, -4, 36, 2, 66, 144, -125, 44, -10, 46, -127, -3, 153, -118, -142, -105, 131, 90, 57, -7, -9, -129, -95, 51, 8, 58, -109, 1, 116, 92, -112, -107, -110, -55, 88, 97, 103, 94, -114, -99, 101, -64, 84, -86]
2025-07-17 13:09:27.372234
round 1
untested vars:  [147, 79, 74, 75, 76, 77, 73, 71, 72, 69, 70, 78, 149, 66, 67, 148, 146, 103, 133, 116, 31, 120, 151, 118, 19, 15, 135, 40, 105, 21, 28, 53, 29, 12, 13, 95, 22, 23, 114, 41, 131, 10, 92, 17, 82, 88, 52, 42, 107, 25, 138, 38, 97, 112, 101, 51, 136, 39, 27, 90, 14, 84, 145, 30, 122, 24, 134, 26, 86, 99, 80, 150, 55, 81, 144, 49, 121, 20, 137, 110, 125, 32, 132, 44, 129, 140, 47, 18, 58, 34, 11, 60, 64, 36, 33, 142, 62, 127, 139, 4, 37, 5, 16, 123, 46, 48, 68, 119, 3, 35, 1, 65, 143, 124, 43, 9, 45, 126, 2, 152, 117, 141, 104, 130, 89, 56, 6, 8, 128, 94, 50, 7, 57, 108, 0, 115, 91, 111, 106, 109, 54, 87, 96, 102, 93, 113, 98, 100, 63, 83, 85]
to test var: 59
current_assigns:  ['k61=0'] 1
both_has_solutions:  [] 0
Second phase, VARIFY
testing k59 == 0
Current assigns: ['k61=0', 'k59=0']

Proven UNSAT in 0.08s
round is done

fix_k:  [148, -80, -75, 76, -77, 78, -74, 72, 73, -70, 71, -79, -150, -67, 68, -149, -147, 104, 134, 117, -32, 121, -152, 119, 20, -16, -136, -41, -106, -22, -29, 54, 30, -13, -14, 96, 23, -24, -115, -42, 132, -11, -93, -18, 83, 89, 53, 43, -108, 26, 139, 39, -98, 113, 102, 52, -137, 40, 28, 91, -15, 85, 146, 31, 123, -25, 135, -27, 87, -100, -81, -151, -56, 82, -145, 50, -122, -21, 138, 111, -126, 33, 133, -45, 130, 141, 48, 19, 59, -35, 12, 61, -65, -37, 34, 143, -63, 128, 140, -5, -38, -6, 17, 124, -47, -49, -69, -120, -4, 36, 2, 66, 144, -125, 44, -10, 46, -127, -3, 153, -118, -142, -105, 131, 90, 57, -7, -9, -129, -95, 51, 8, 58, -109, 1, 116, 92, -112, -107, -110, -55, 88, 97, 103, 94, -114, -99, 101, -64, 84]
2025-07-17 13:09:27.810015
round 2
untested vars:  [147, 79, 74, 75, 76, 77, 73, 71, 72, 69, 70, 78, 149, 66, 67, 148, 146, 103, 133, 116, 31, 120, 151, 118, 19, 15, 135, 40, 105, 21, 28, 53, 29, 12, 13, 95, 22, 23, 114, 41, 131, 10, 92, 17, 82, 88, 52, 42, 107, 25, 138, 38, 97, 112, 101, 51, 136, 39, 27, 90, 14, 84, 145, 30, 122, 24, 134, 26, 86, 99, 80, 150, 55, 81, 144, 49, 121, 20, 137, 110, 125, 32, 132, 44, 129, 140, 47, 18, 58, 34, 11, 60, 64, 36, 33, 142, 62, 127, 139, 4, 37, 5, 16, 123, 46, 48, 68, 119, 3, 35, 1, 65, 143, 124, 43, 9, 45, 126, 2, 152, 117, 141, 104, 130, 89, 56, 6, 8, 128, 94, 50, 7, 57, 108, 0, 115, 91, 111, 106, 109, 54, 87, 96, 102, 93, 113, 98, 100, 63, 83]
to test var: 85
current_assigns:  ['k61=0', 'k59=1'] 2
both_has_solutions:  [] 0
Second phase, VARIFY
testing k85 == 0
Current assigns: ['k61=0', 'k59=1', 'k85=1']

Proven UNSAT in 0.23s
round is done

fix_k:  [148, -80, -75, 76, -77, 78, -74, 72, 73, -70, 71, -79, -150, -67, 68, -149, -147, 104, 134, 117, -32, 121, -152, 119, 20, -16, -136, -41, -106, -22, -29, 54, 30, -13, -14, 96, 23, -24, -115, -42, 132, -11, -93, -18, 83, 89, 53, 43, -108, 26, 139, 39, -98, 113, 102, 52, -137, 40, 28, 91, -15, 85, 146, 31, 123, -25, 135, -27, 87, -100, -81, -151, -56, 82, -145, 50, -122, -21, 138, 111, -126, 33, 133, -45, 130, 141, 48, 19, 59, -35, 12, 61, -65, -37, 34, 143, -63, 128, 140, -5, -38, -6, 17, 124, -47, -49, -69, -120, -4, 36, 2, 66, 144, -125, 44, -10, 46, -127, -3, 153, -118, -142, -105, 131, 90, 57, -7, -9, -129, -95, 51, 8, 58, -109, 1, 116, 92, -112, -107, -110, -55, 88, 97, 103, 94, -114, -99, 101, -64]
2025-07-17 13:09:28.400262
round 3
untested vars:  [147, 79, 74, 75, 76, 77, 73, 71, 72, 69, 70, 78, 149, 66, 67, 148, 146, 103, 133, 116, 31, 120, 151, 118, 19, 15, 135, 40, 105, 21, 28, 53, 29, 12, 13, 95, 22, 23, 114, 41, 131, 10, 92, 17, 82, 88, 52, 42, 107, 25, 138, 38, 97, 112, 101, 51, 136, 39, 27, 90, 14, 84, 145, 30, 122, 24, 134, 26, 86, 99, 80, 150, 55, 81, 144, 49, 121, 20, 137, 110, 125, 32, 132, 44, 129, 140, 47, 18, 58, 34, 11, 60, 64, 36, 33, 142, 62, 127, 139, 4, 37, 5, 16, 123, 46, 48, 68, 119, 3, 35, 1, 65, 143, 124, 43, 9, 45, 126, 2, 152, 117, 141, 104, 130, 89, 56, 6, 8, 128, 94, 50, 7, 57, 108, 0, 115, 91, 111, 106, 109, 54, 87, 96, 102, 93, 113, 98, 100, 63]
to test var: 83
current_assigns:  ['k61=0', 'k59=1', 'k85=0'] 3
both_has_solutions:  [] 0
Second phase, VARIFY
testing k83 == 0
Current assigns: ['k61=0', 'k59=1', 'k85=0', 'k83=0']

Solution found in 0.14s
Both k83=0 and k83=1 are SAT, added to both_has_solutions
round is done

.........


2025-07-17 13:10:39.750240
round 152
untested vars:  []
to test var: 147
current_assigns:  ['k61=0', 'k59=1', 'k85=0', 'k63=0', 'k100=1', 'k98=0', 'k93=1', 'k102=1', 'k87=1', 'k109=0', 'k91=1', 'k0=1', 'k57=1', 'k50=1', 'k56=1', 'k89=1', 'k104=0', 'k117=0', 'k152=1', 'k9=0', 'k119=0', 'k68=0', 'k46=0', 'k16=1', 'k11=1', 'k18=1', 'k132=1', 'k121=0', 'k80=0', 'k24=0', 'k14=0', 'k22=1', 'k118=1', 'k67=1'] 34
both_has_solutions:  [-81, -76, 75, -78, 77, -75, 71, 72, -71, 70, -80, -151, -68, -150, -148, 103, 133, 116, -33, 120, -153, 19, -17, -137, -42, -107, -23, -30, 53, 29, -14, -15, 95, -25, -116, -43, 131, -12, -94, -19, 82, 88, 52, 42, -109, 25, 138, 38, -99, 112, 101, 51, -138, 39, 27, 90, 84, 145, 30, 122, 134, -28, 86, -101, -152, -57, 81, -146, 49, -22, 137, 110, -127, 32, -46, 129, 140, 47, 58, -36, 60, -66, -38, 33, 142, -64, 127, 139, -6, -39, -7, 123, -50, -5, 35, 1, 65, 143, -126, 43, 45, -128, -4, -143, 130, -8, -10, -130, -96, 7, -110, 115, -113, -108, -56, 96, -115, 83] 118
Second phase, VARIFY
testing k147 == 0
Current assigns: ['k61=0', 'k59=1', 'k85=0', 'k63=0', 'k100=1', 'k98=0', 'k93=1', 'k102=1', 'k87=1', 'k109=0', 'k91=1', 'k0=1', 'k57=1', 'k50=1', 'k56=1', 'k89=1', 'k104=0', 'k117=0', 'k152=1', 'k9=0', 'k119=0', 'k68=0', 'k46=0', 'k16=1', 'k11=1', 'k18=1', 'k132=1', 'k121=0', 'k80=0', 'k24=0', 'k14=0', 'k22=1', 'k118=1', 'k67=1', 'k147=0']

Solution found in 0.12s
Both k147=0 and k147=1 are SAT, added to both_has_solutions
round is done

31cb55835189e0f482ae_119.log
Time cost: 77.22s.