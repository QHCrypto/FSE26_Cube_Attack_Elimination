#ifndef __TRIVIUM_FRAMEWORK_H__
#define  __TRIVIUM_FRAMEWORK_H__


#define FASTBOUND 225 
#define BASEROUND 69 
// #define VTROUND 395
// #define OUTROUND 93 
#define OUTROUND 93 // 855:165, 845: 93, 840: 83
#define BCROUND 250 

#define SIZEBOUND 20000000
#define CALLBACKBOUND 600
#define BITSET_SIZE 288

#include<vector>
#include<bitset>
#include<map>
#include"node.h"
#include"thread_pool.h"

using namespace thread_pool;
void expandFunc(bitset<80>& cube, vector<bitset<288> >& layerTerms, int& start, float time, int singlethread);
void app_newExpandFunc(bitset<80>& cube, vector<bitset<288> >& states, int& start, int step, ThreadPool& threadpool, float time, int threads, int threshold, bool mode, bool& indicator, bitset<BITSET_SIZE> zero_s);

#endif