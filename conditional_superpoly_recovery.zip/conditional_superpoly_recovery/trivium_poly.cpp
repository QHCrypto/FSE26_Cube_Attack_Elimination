#include "main.h"
#include <future>
#include "semaphore.h"
void trivium_initial_state_poly(vector<KVpoly>& state) {
	state.clear();
	Vmono vm;
	Kpoly kp;
	Kmono km;
	kp.p.insert(km);
	for (int i = 0; i < 288; i++) {
		KVpoly kvp;
		state.push_back(kvp);
	}
	for (int i = 0; i < 80; i++) {
		Vmono vm0;
		vm0.v[i] = 1;
		state[i + 93].p[vm0] = kp;
		Kmono km0;
		Kpoly kp0;
		km0.k[i] = 1;
		kp0.p.insert(km0);
		state[i].p[vm] = kp0;
	}
	state[285].p[vm] = kp;
	state[286].p[vm] = kp;
	state[287].p[vm] = kp;
}

void trivium_update_core_poly(vector<KVpoly>& state) {
	KVpoly p;
	
	p = state[90] * state[91] + state[65] + state[92] + state[170];
	state.erase(state.begin() + 92);
	state.insert(state.begin() + 92, p);

	p = state[174] * state[175] + state[161] + state[176] + state[263];
	state.erase(state.begin() + 176);
	state.insert(state.begin() + 176, p);

	p = state[285] * state[286] + state[242] + state[287] + state[68];
	state.pop_back();
	state.insert(state.begin(), p);

}

void trivium_poly(vector<KVpoly>& state, int round0) {
	trivium_initial_state_poly(state);
	for (int r = 1; r <= round0; r++) {
		trivium_update_core_poly(state);
	}
}

void transform_k_fun(KVpoly &kvp, vector<Kpoly>& k_fun) {
	auto it = kvp.p.begin();
	while (it != kvp.p.end()) {
		if (((*it).second.p.size() > 1)) {
			Kmono km;
			Kpoly kp;
			km.k[k_fun.size()] = 1;
			kp.p.insert(km);
			k_fun.push_back((*it).second);
			(*it).second = kp;
		}
		it++;
	}
}

void trivium_init_k_fun_poly(vector<Kpoly> &k_fun) {
	for (int i = 0; i < 80; i++) {
		Kmono km;
		km.k[i] = 1;
		Kpoly kp;
		kp.p.insert(km);
		k_fun.push_back(kp);
	}
}

void trivium_simplify_poly(vector<KVpoly> &state, vector<Kpoly> & k_fun, int round0) {
	state.clear();
	k_fun.clear();
	trivium_initial_state_poly(state);
	trivium_init_k_fun_poly(k_fun);
	for (int r = 1; r <= round0; r++) {
		trivium_update_core_poly(state);
		transform_k_fun(state[0], k_fun);
		transform_k_fun(state[93], k_fun);
		transform_k_fun(state[177], k_fun);
	}
}

void trivium_flag_poly(bitset<80> flag, vector<KVpoly> &state, vector<KVpoly> &pstate) {
    pstate.clear();
    bitset<80> b;
    for (int i = 0; i < 288; i++) {
        pstate.push_back(state[i]);
        auto it = state[i].p.begin();
        while (it != state[i].p.end()) {
            b = (*it).first.v | flag;
            if (b != flag) {
                pstate[i].p.erase((*it).first);
            }
            it++;
        }
    }
}

void trivium_flag_poly_1(bitset<80> flag, bitset<N> key, vector<KVpoly>& state, vector<KVpoly>& pstate) {
	pstate.clear();
	bitset<80> b;
	bitset<N> k_0;
	bitset<N> k_1;

	for (int i = 0; i < 288; i++) {
		pstate.push_back(state[i]);
		auto it = state[i].p.begin();
		while (it != state[i].p.end()) {
			b = (*it).first.v | flag;
			if (b != flag) {
				pstate[i].p.erase((*it).first);
			}
			else if( key != k_0){
				auto is = (*it).second.p.begin();
				k_1 = (*is).k & key;
				if (k_1 != k_0) {
					pstate[i].p.erase((*it).first);
				}
					
				
			}
			it++;
		}
	}
}

map<vector<int>, vector<int>> trivium_flag_poly_2(bitset<80> flag, bitset<N> key, vector<KVpoly>& state, vector<KVpoly>& pstate) {
	pstate.clear();
	bitset<80> b;
	bitset<N> k_0;
	bitset<N> k_1;
	map<vector<int>, vector<int>> vk_table;
	for (int i = 0; i < 288; i++) {
		pstate.push_back(state[i]);
		auto it = state[i].p.begin();
		while (it != state[i].p.end()) {
			b = (*it).first.v | flag;
			if (b != flag) {
				pstate[i].p.erase((*it).first);
			}
			else if (key != k_0) {
				auto is = (*it).second.p.begin();
				k_1 = (*is).k & key;
				if (k_1 != k_0) {
					vector<int> v_term;
					for (int j = 0; j < 80; j++) {
						if ((*it).first.v[j] == 1) {
							v_term.push_back(j);
						}
					}
					vk_table[v_term].push_back(i);
					pstate[i].p.erase((*it).first);
				}
			}
			it++;
		}
	}
	return vk_table;
}

// vector<int> k_count(KVpoly spoly) {
// 	vector<int> kcount(N);
// 	bitset<N> kk;
// 	vector<int> basis;
// 	if (spoly.p.size() == 0) {
// 		vector<int> out;
// 		out.push_back(-1);
// 		return out;
// 	}
// 	auto it = spoly.p.begin();
// 	auto is = (*it).second.p.begin();
// 	if (is == (*it).second.p.end()) {
// 		vector<int> out;
// 		out.push_back(-1);
// 		return out;
// 	}
// 	while (is != (*it).second.p.end()) {
// 		kk = (*is).k;
// 		for (int i = 0; i < N; i++) {
// 			if (kk[i] == 1) {
// 				kcount[i]++;
// 			}
// 		}
// 		is++;
// 	}
// 	auto maxElement = max_element(kcount.begin(), kcount.end());
// 	int maxValue = *maxElement;
// 	for (auto it = kcount.begin(); it != kcount.end(); ++it) {
// 		if (*it == maxValue) {
// 			int index = distance(kcount.begin(), it);
// 			basis.push_back(index);
// 		}
// 	}
// 	if (basis.size() > 0) {
// 		return basis;
// 	}
// 	else {
// 		vector<int> out;
// 		out.push_back(-1);
// 		return out;
// 	}
// }

vector<int> k_count(KVpoly spoly, int n = 1) { 
    vector<int> kcount(N);
    bitset<N> kk;
    vector<int> basis;
    if (spoly.p.size() == 0) {
        vector<int> out;
        out.push_back(-1);
        return out;
    }
    auto it = spoly.p.begin();
    auto is = (*it).second.p.begin();
    if (is == (*it).second.p.end()) {
        vector<int> out;
        out.push_back(-1);
        return out;
    }
    // 计算每个位置的计数
    while (is != (*it).second.p.end()) {
        kk = (*is).k;
        for (int i = 0; i < N; i++) {
            if (kk[i] == 1) {
                kcount[i]++;
            }
        }
        is++;
    }
    
    vector<pair<int, int>> value_index;
    for (int i = 0; i < kcount.size(); i++) {
        value_index.push_back({kcount[i], i});
    }
    
    sort(value_index.begin(), value_index.end(), 
         [](const pair<int,int>& a, const pair<int,int>& b) {
             return a.first > b.first;
         });

    // take top n
    for (int i = 0; i < min(n, (int)value_index.size()); i++) {
        if (value_index[i].first > 0) {  
            basis.push_back(value_index[i].second);
        }
    }
    if (basis.size() > 0) {
        return basis;
    }
    else {
        vector<int> out;
        out.push_back(-1);
        return out;
    }
}

vector<int> find_basis(vector<KVpoly> pstate,bitset<M> cube) {
	vector<int> basis;
	vector<int> vdeg = get_maxdeg(pstate, cube);
	bitset<80> b;
	for (int i = 0; i < pstate.size(); i++) {
		cout << pstate[i] << endl;
		auto it = pstate[i].p.begin();
		while (it != pstate[i].p.end()) {
			b = (*it).first.v | cube;
			bitset<80> bb;
			bb = (*it).first.v;
			int a = bb.count();
			if ((b == cube) && (a == vdeg[i]) && (a>0)) {
				auto is = (*it).second.p.begin();
				bitset<N> kk;
				kk = (*is).k;
				for (int i = 0; i < N; i++) {
					if (kk[i] == 1) {
						bool qq = true;
						for (int elem : basis) {
							if (elem == i) {
								qq = false;
							}
						}
						if (qq) {
							basis.push_back(i);
						}
					}
				}
			}
			it++;
		}
	}
	return basis;
}

vector<int> get_maxdeg(vector<KVpoly> pstate, bitset<M> cube) {
	vector<int> vdeg;
	bitset<80> b;
	for (int i = 0; i < pstate.size(); i++) {
		int deg = 0;
		auto it = pstate[i].p.begin();
		while (it != pstate[i].p.end()) {
			b = (*it).first.v | cube;
			if (b == cube) {
				bitset<80> bb;
				bb = (*it).first.v;
				int a = bb.count();
				deg = max(deg,a);
			}
			it++;
		}
		vdeg.push_back(deg);
	}
	return vdeg;
}


Kpoly recursive_substitute(const Kpoly& poly, const std::unordered_map<int, Kpoly>& rule_map, const std::bitset<N>& zero_vars, int start) 
{
    Kpoly result;
    for (const auto& mono : poly.p) {
		Kpoly partial_result;
        // 跳过包含被赋0变量的单项式
        if ((mono.k & zero_vars).any()) continue;
        // bool substituted = false;
        Kmono base = mono;
        // 只对start之后的操作
        // for (int var = N-1; var >= start; --var) {//倒着算，因为一开始替换的，如果换不干净，肯定可以在前面再替换一次
		Kpoly tmpmul;
		Kmono m2;
		bitset<N> m_b2;
		m2.k = m_b2;
		tmpmul.p.insert(m2);//构造tmpmul=1
        for (int var = start; var < N; ++var) {//倒着算，因为一开始替换的，如果换不干净，肯定可以在前面再替换一次
            if (base.k[var] && rule_map.count(var)) {
                // substituted = true;
                base.k[var] = 0; // 去掉被替换的变量
                // 递归处理替换后的多项式
                Kpoly temp = rule_map.at(var); // 直接通过var获取替换多项式
				temp = recursive_substitute(temp, rule_map, zero_vars, start);//直到全部换完，不满足if了，那么递归就结束了
                tmpmul = tmpmul * temp;//换完接着乘起来
                // 乘以剩余部分（base）这里就是每次都只计算替换一次的，算完接着替换，接着替换的话就从var之后开始遍历就行了
            }
        }
		//如果没替换
		// if(!substituted){

		// }
		//上面把base中要替换掉的k改成1，换元的项，乘起来保存在tmpmul
		partial_result.p.insert(base); 
        partial_result = partial_result * tmpmul;
		result = result + partial_result;
        // std::cout << result << std::endl;
    }
    return result;
}

vector<SubstitutionRule> rule_generate(int round0,int round1,int& start) {
	vector<KVpoly> state0;
	vector<Kpoly> k_fun0;
	trivium_simplify_poly(state0, k_fun0, round0);
	vector<KVpoly> state1;
	vector<Kpoly> k_fun1;
	trivium_simplify_poly(state1, k_fun1, round1);
	start = k_fun0.size();
	vector<SubstitutionRule> rule;
	
	for (int i=start; i< k_fun1.size();i++) {
		if (i==177)
		{
			SubstitutionRule tmp;
			tmp.original_var = i;
			Kpoly p0;

			Kmono m0;
			bitset<N> m_b;
			m_b[87]=1;
			m0.k = m_b;
			p0.p.insert(m0);

			Kmono m1;
			bitset<N> m_b1;
			m_b1[96]=1;
			m1.k = m_b1;
			p0.p.insert(m1);	

			Kmono m2;
			bitset<N> m_b2;
			m2.k = m_b2;
			p0.p.insert(m2);

			tmp.replacement = p0;
			rule.push_back(tmp);
		}
		if ((i>177)&&(i<256)&&(i%2 == 1)) {
			SubstitutionRule tmp;
			tmp.original_var = i;
			int a = i/2 - 1;
			Kpoly p0;

			Kmono m0;
			bitset<N> m_b;
			m_b[a]=1;
			m0.k = m_b;
			p0.p.insert(m0);

			Kmono m1;
			bitset<N> m_b1;
			m_b1[a+9]=1;
			m1.k = m_b1;
			p0.p.insert(m1);

			tmp.replacement = p0;
			rule.push_back(tmp);
		}
		if ((i>257)&&(i<292)&&(i%3 == 0)) {
			SubstitutionRule tmp;
			tmp.original_var = i;
			int a = i/3 +41;
			Kpoly p0;

			Kmono m0;
			bitset<N> m_b;
			m_b[a]=1;
			m0.k = m_b;
			p0.p.insert(m0);

			Kmono m1;
			bitset<N> m_b1;
			m_b1[a+9]=1;
			m1.k = m_b1;
			p0.p.insert(m1);

			tmp.replacement = p0;
			rule.push_back(tmp);
		}
		else {
			SubstitutionRule tmp;
			tmp.original_var = i;
			tmp.replacement = k_fun1[i];
			rule.push_back(tmp);
		}
	}
	return rule;
}


void substitute_kvpoly(KVpoly& result, const KVpoly& original, int round0, int round1, const std::bitset<N>& zero_vars) 
{
    if (round0 > round1) {
        return;
    }
    
    int start = 0;
    vector<SubstitutionRule> rules = rule_generate(round0, round1, start);
    std::unordered_map<int, Kpoly> rule_map;
    for (const auto& rule : rules) {
        rule_map[rule.original_var] = rule.replacement;
    }
    
    result.p.clear();
    
    for (const auto& [vmono, kpoly] : original.p) {
        if (!vmono.v.none()) {
            result.p[vmono] = kpoly;
        }
    }
    
    std::vector<std::future<Kpoly>> futures;
    std::mutex result_mutex;
    
    for (const auto& [vmono, kpoly] : original.p) {
        if (vmono.v.none()) {
            for (const auto& mono : kpoly.p) {
                futures.emplace_back(std::async(std::launch::async, 
                    [&rule_map, &zero_vars, start, mono]() {
                        Kpoly temp;
                        temp.p.insert(mono);
                        return recursive_substitute(temp, rule_map, zero_vars, start);
                    }));
            }
        }
    }
    
    Kpoly substituted_result;
    for (auto& future : futures) {
        Kpoly partial_result = future.get();
        for (const auto& mono : partial_result.p) {
            if (substituted_result.p.count(mono)) {
                substituted_result.p.erase(mono);
            } else {
                substituted_result.p.insert(mono);
            }
        }
    }
    
    if (!substituted_result.p.empty()) {
        Vmono zero_vmono;
        zero_vmono.v.reset();  
        result.p[zero_vmono] = substituted_result;
    }
	// cout<<"result is: "<<result<<endl;
	// cout<<"done!!"<<endl;
}


