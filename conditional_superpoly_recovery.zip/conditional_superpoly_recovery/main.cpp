#include<iostream>
#include<fstream>
#include<vector>
#include<bitset>
#include<algorithm>
#include<thread>
#include<mutex>
#include<future>
#include<sstream>
#include<malloc.h>

#include"log.h"
#include"deg.h"
#include"thread_pool.h"
#include"trivium.h"
#include"triviumtrack.h"
#include"newtrivium.h"
#include"triviumcallback.h"
#include"triviumframework.h"
#include"main.h"

using namespace std;
using namespace thread_pool;



mutex stream_mutex;
mutex map_mutex;
mutex term_mutex;
int THREAD_NUM = 512;

vector<vector<int>> readFileTo2DVector(const string& filePath) {
    ifstream inputFile(filePath);
    if (!inputFile.is_open()) {
        cerr << "Error: Unable to open file " << filePath << endl;
        return {};
    }   
    vector<vector<int>> result;
    string line;   
    while (getline(inputFile, line)) {        
        vector<int> row;
        stringstream ss(line);
        int number;        
        while (ss >> number) {
            row.push_back(number);
        }
        if ((row.size() > 20)&&(row.size() <= 55))
        {
            result.push_back(row);
        }        
    }
    inputFile.close();
    return result;
}

vector<vector<int>> readFileTo2DVector1(const string& filePath) {
    ifstream inputFile(filePath);
    if (!inputFile.is_open()) {
        cerr << "Error: Unable to open file " << filePath << endl;
        return {};
    }   
    vector<vector<int>> result;
    string line;   
    while (getline(inputFile, line)) {        
        vector<int> row;
        stringstream ss(line);
        int number;        
        while (ss >> number) {
            row.push_back(number);
        }
        // if ((row.size() > 5))
        {
            result.push_back(row);
        }        
    }
    inputFile.close();
    return result;
}

set<vector<int>> readFileToset1(const string& filePath) {
    ifstream inputFile(filePath);
	// cout << "Trying to open: " << filePath << endl;
    if (!inputFile.is_open()) {
        cerr << "Error: Unable to open file " << filePath << endl;
        return {};
    }   
    set<vector<int>> result;
    string line;   
    while (getline(inputFile, line)) {        
        vector<int> row;
        stringstream ss(line);
        int number;        
        while (ss >> number) {
            row.push_back(number);
        }
        if(row.size()>3) {
            result.insert(row);
        }
    }
    inputFile.close();
	// cout<<"AA"<<endl;
    return result;
}

set<vector<int>> getRangeFromSet(const set<vector<int>>& s, size_t m, size_t n) {
    set<vector<int>> result;
    if (m > n || s.size() <= m) {
        return result;
    }
    n = min(n, s.size() - 1);

    auto it = s.begin();
    advance(it, m);

    for (size_t i = m; i <= n; ++i) {
        result.insert(*it);
        ++it;
    }
    return result;
}

// 69 round vk table to check whether eliminatable
int get_v_from_k(int k) {
    //k -> v map
    static const std::unordered_map<int, int> k_to_v_map = {
        {138, 9}, {137, 10}, {136, 11}, {135, 12}, {134, 13}, {133, 14}, {132, 15},
        {131, 16}, {130, 17}, {129, 18}, {128, 19}, {127, 20}, {126, 21}, {125, 22},
        {124, 23}, {123, 24}, {122, 25}, {121, 26}, {120, 27}, {119, 28}, {118, 29},
        {117, 30}, {116, 31}, {115, 32}, {114, 33}, {113, 34}, {112, 35}, {111, 36},
        {110, 37}, {109, 38}, {108, 39}, {107, 40}, {106, 41}, {105, 42}, {104, 43},
        {103, 44}, {102, 45}, {101, 46}, {100, 47}, {99, 48},  {98, 49},  {97, 50},
        {96, 51},  {95, 52},  {94, 53},  {93, 54},  {92, 55},  {91, 56},  {90, 57},
        {89, 58},  {88, 59},  {87, 60},  {86, 61},  {85, 62},  {84, 63},  {83, 64},
        {82, 65},  {54, 66},  {55, 67},  {56, 68},  {57, 69},  {58, 70},  {59, 71},
        {60, 72},  {61, 73},  {62, 74},  {63, 75},  {64, 76},  {65, 77}
    };
    auto it = k_to_v_map.find(k);
    return (it != k_to_v_map.end()) ? it->second : -1;
}

// Find a large eliminatable variables set for a set of random cubes 
void Find_eliminatable_set() {
    vector<vector<int>> all_cubes = readFileTo2DVector("845_test_cubes.txt");
    // ofstream ff("845_test_basis_0-25.txt",ios::app);
    ofstream ff("845_test_basis_25-50.txt",ios::app);
    // for (int j = 0; j < 25; j++) {
    for (int j = 25; j < 50; j++) {
        set<int> basis;
        for (size_t i = 0; i < 3; i++)
        {
            int round = 845;
            int THREAD_NUM = 400;
            int threshold = 80;
            string foldername = to_string(round) + "_app_" + to_string(FASTBOUND) + "_" + to_string(BASEROUND);
            vector<int> a = new_recovery_app( round,  THREAD_NUM, all_cubes[j], foldername,threshold,0);
            for(const auto& it:a) {
                basis.insert(it);
            }
        }
        for(const auto& it :all_cubes[j]) {
            ff << it <<" ";
        }
        ff<<endl;
        for(const auto& it:basis) {
            ff << it << " ";
        } 
        ff<<endl;
    }
}

// Find good eliminatable set
void check_eliminatable_set() {
    vector<vector<int>> cubes_and_k = readFileTo2DVector1("845_test_basis_25-50.txt");
    // vector<vector<int>> cubes_and_k = readFileTo2DVector1("845_test_basis_0-25.txt");
    ofstream ff("845_tuples_1.txt",ios::app);
    // ofstream ff("845_tuples.txt",ios::app);
    for(int i=0;i<cubes_and_k.size();i=i+2){
        int round = 845;
        // int bound = 18;
        int bound = 120;
        vector<int> cubeIndex = cubes_and_k[i];
        string filename = "845_test_k_1.txt";
        // string filename = "845_test_k.txt";
        vector<int> k_basis = cubes_and_k[i+1];
        vector<vector<int>> tuples = test_k (round, cubeIndex, bound, filename, k_basis,i);
        for(auto it: tuples) {
            for (auto j:it) {
                ff << j <<" "; 
            }
            ff << endl;
        }
        ff<<endl;
    }
}

// Given eliminatable set, get the corresbonding cube set
void Filter_cubes() {
    string filename0 = "845_small_50_45.txt";
    vector<vector<int>> all_cubes = readFileTo2DVector(filename0);
    string filename;
    // vector<int> kid = {57,82,84};
    // vector<int> kid = {90,116,114};
    // vector<int> kid = {90,116,118};
    // vector<int> kid = {100,113,115};
    // vector<int> kid = {54,56,100};
    // vector<int> kid = {63,65,113};
    // vector<int> kid = {114,116,118};
    // vector<int> kid = {55,57,59};
    // vector<int> kid = {55,57,82};
    // vector<int> kid = {55,57,129};
    // vector<int> kid = {90,103,105};
    // vector<int> kid = {56,54,58};
    // vector<int> kid = {56,58,100};
    vector<int> kid = {90, 103, 88 };
    sort(kid.begin(),kid.end());
    vector<int> vs;
    for(auto it : kid) {
        int v = get_v_from_k(it);
        vs.push_back(v);
        filename += "k"+to_string(it);
    }
    filename += "_" + filename0;
    ofstream ff (filename,ios::app);
    set<vector<int>> select_cubes;
    for (auto vec: all_cubes) {
        bool a = true;
        for (auto v: vs) {
            if (find(vec.begin(), vec.end(), v) != vec.end()) {
                a = false;
                break;
            }
        }
        if (a) {
            select_cubes.insert(vec);
        }
    }
    for (auto vec: select_cubes) {
        for(auto it: vec){
            ff << it << " ";
        }
        ff<<endl;
    }
}

// Given a cube and k, calculate con-spoly. 
void calculate_con_spoly() {
    // int round=840;
    int round = 845;
    int THREAD_NUM = 512;
    int threshold = BOUND;
    vector<int> cubeIndex = {0,1,2,3,4,5,6,8,10,12,13,15,17,19,21,23,25,27,29,30,32,34,36,38,40,41,42,43,45,47,49,51,53,55,56,58,60,62,64,66,68,70,73,75,77,79};
    vector<int> kid ={55,57,84};
    sort(kid.begin(),kid.end());
    new_recovery_spoly_with_fix_basis(round, THREAD_NUM, cubeIndex, threshold, kid,0);
}

// calculate superpoly
void calculate_superpoly() {
    int round = 840;
    int THREAD_NUM = 512;
    // vector<int> cubeIndex = {0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,34,36,38,40,42,45,47,49,51,53,55,57,60,62,64,66,68,70,72,75,77,79}; 843
    // vector<int> cubeIndex = {0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,34,36,38,40,42,45,47,49,51,53,55,57,60,62,64,66,68,70,72,77,75,79};840-1
    // vector<int> cubeIndex = {0,1,2,3,4,5,6,7,8,10,12,13,14,15,16,18,20,23,25,27,29,31,33,35,37,40,42,44,46,48,50,52,55,57,59,61,63,65,67,70,72,74,76,77,78,79};//840-2 
    vector<int> cubeIndex = {0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,24,25,27,29,30,31,33,35,36,37,38,40,42,44,46,48,50,52,55,57,59,61,63,65,67,70,72,74,76,78};//840-3
    int threshold = 784662500; 
    vector<int> kid;
    int p_id = 0;  
    new_recovery_spoly_with_fix_basis(round,  THREAD_NUM, cubeIndex,  threshold, kid, p_id);
}

int main() {
    // ***************************************************************************

    // For check_eliminatable_set(), the FASTBOUND should be Round-330=845-330=515.

    // For other function, FASTBOUND is Round - 630.

    // Detials of parameter settings are in triviumframework.h

    // ***************************************************************************

    // Find_eliminatable_set();
    // check_eliminatable_set();
    // Filter_cubes();
    // calculate_con_spoly();
    // calculate_superpoly();
    cout << "Uncomment the desired function in main() and rebuild." << endl;

    return 0;
}




