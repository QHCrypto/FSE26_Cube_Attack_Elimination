#include<iostream>
#include<fstream>
#include<vector>
#include<bitset>
#include<algorithm>
#include<thread>
#include<mutex>
#include<future>
#include<sstream>
#include<malloc.h>
#include<array>
#include <charconv>  
#include <string_view>
#include <sys/mman.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

#include"log.h"
#include"deg.h"
#include"thread_pool.h"
#include"trivium.h"
#include"triviumtrack.h"
#include"newtrivium.h"
#include"triviumcallback.h"
#include"triviumframework.h"
#include"main.h"

using namespace std;
using namespace thread_pool;

using std::chrono::high_resolution_clock;
using std::chrono::duration_cast;
using std::chrono::seconds;
namespace fs = std::filesystem;


mutex stream_mutex;
mutex map_mutex;
mutex term_mutex;
int THREAD_NUM = 512;

vector<vector<int>> readFileTo2DVector(const string& filePath) {
    ifstream inputFile(filePath);
    if (!inputFile.is_open()) {
        cerr << "Error: Unable to open file " << filePath << endl;
        return {};
    }   
    vector<vector<int>> result;
    string line;   
    while (getline(inputFile, line)) {        
        vector<int> row;
        stringstream ss(line);
        int number;        
        while (ss >> number) {
            row.push_back(number);
        }
        if ((row.size() > 20)&&(row.size() <= 55))
        {
            result.push_back(row);
        }        
    }
    inputFile.close();
    return result;
}

vector<vector<int>> readFileTo2DVector1(const string& filePath) {
    ifstream inputFile(filePath);
    if (!inputFile.is_open()) {
        cerr << "Error: Unable to open file " << filePath << endl;
        return {};
    }   
    vector<vector<int>> result;
    string line;   
    while (getline(inputFile, line)) {        
        vector<int> row;
        stringstream ss(line);
        int number;        
        while (ss >> number) {
            row.push_back(number);
        }
        // if ((row.size() > 5))
        {
            result.push_back(row);
        }        
    }
    inputFile.close();
    return result;
}

set<vector<int>> readFileToset1(const string& filePath) {
    ifstream inputFile(filePath);
	// cout << "Trying to open: " << filePath << endl;
    if (!inputFile.is_open()) {
        cerr << "Error: Unable to open file " << filePath << endl;
        return {};
    }   
    set<vector<int>> result;
    string line;   
    while (getline(inputFile, line)) {        
        vector<int> row;
        stringstream ss(line);
        int number;        
        while (ss >> number) {
            row.push_back(number);
        }
        if(row.size()>3) {
            result.insert(row);
        }
    }
    inputFile.close();
	// cout<<"AA"<<endl;
    return result;
}

set<vector<int>> getRangeFromSet(const set<vector<int>>& s, size_t m, size_t n) {
    set<vector<int>> result;
    if (m > n || s.size() <= m) {
        return result;
    }
    n = min(n, s.size() - 1);

    auto it = s.begin();
    advance(it, m);

    for (size_t i = m; i <= n; ++i) {
        result.insert(*it);
        ++it;
    }
    return result;
}

// Memory-mapped file wrapper class
class MappedFile {
    int fd = -1;
    void* data = nullptr;
    size_t size = 0;
public:
    MappedFile(const string& filename) {
        fd = open(filename.c_str(), O_RDONLY);
        if (fd == -1) throw runtime_error("Cannot open file");
        
        struct stat sb;
        if (fstat(fd, &sb) == -1) throw runtime_error("Cannot get file size");
        size = sb.st_size;
        
        data = mmap(nullptr, size, PROT_READ, MAP_PRIVATE, fd, 0);
        if (data == MAP_FAILED) throw runtime_error("Memory mapping failed");
    }
    
    ~MappedFile() {
        if (data) munmap(data, size);
        if (fd != -1) close(fd);
    }
    
    const char* get_data() const { return static_cast<const char*>(data); }
    size_t get_size() const { return size; }
};

// Global result and mutex lock
mutex g_mutex;
Kpoly g_result;

// Parse a single term (e.g., "k9k54")
Kmono parseTerm(const char* start, const char* end) {
    Kmono km;
    km.k.reset();
    while (start < end) {
        if (*start == 'k') {
            ++start;
            int index = 0;
            auto result = from_chars(start, end, index);
            if (result.ec == errc() && index >= 0 && index <= N) {
                km.k.set(index);
            }
            start = result.ptr;
        } else {
            ++start;
        }
    }
    return km;
}

vector<KVpoly> readPolynomialParallelUnmerged(const string& filename) {
    try {
        MappedFile mmap(filename);
        const char* data = mmap.get_data();
        size_t size = mmap.get_size();

        // Skip "1*(" at beginning and ")" at end
        const char* start = data + 3;
        const char* end = data + size - 1;

        const size_t num_threads = 300;
        const size_t chunk_size = (end - start) / num_threads;
        vector<KVpoly> results(num_threads);  // Each thread gets its own KVpoly
        vector<thread> threads;
        vector<Kpoly> thread_polys(num_threads);  // Each thread's Kpoly

        for (size_t i = 0; i < num_threads; ++i) {
            const char* chunk_start = start + i * chunk_size;
            const char* chunk_end = (i == num_threads - 1) ? end : chunk_start + chunk_size;

            // Align to term boundary
            if (i > 0) {
                while (chunk_start < end && *chunk_start != '+') ++chunk_start;
                if (chunk_start < end) ++chunk_start;
            }

            if (chunk_start < chunk_end) {
                // Each thread processes its own portion without shared data
                threads.emplace_back([i, chunk_start, chunk_end, &thread_polys]() {
                    Kpoly local_poly;
                    const char* pos = chunk_start;
                    
                    while (pos < chunk_end) {
                        const char* term_end = pos;
                        while (term_end < chunk_end && *term_end != '+') ++term_end;
                        
                        if (*pos == 'k') {
                            Kmono term = parseTerm(pos, term_end);
                            if (!term.k.none()) {
                                local_poly.p.insert(move(term));
                            }
                        }
                        pos = term_end + 1;
                    }
                    
                    thread_polys[i] = move(local_poly);
                });
            }
        }

        // Wait for all threads to complete
        for (auto& t : threads) t.join();

        // Build final result (one KVpoly per thread)
        Vmono vm;  // Default all-zero Vmono
        for (size_t i = 0; i < num_threads; ++i) {
            if (!thread_polys[i].p.empty()) {
                results[i].p[vm] = move(thread_polys[i]);
            }
        }

        return results;
    } catch (const exception& e) {
        cerr << "Error: " << e.what() << endl;
        return {};
    }
}

// 69 round vk table to check whether eliminatable
int get_v_from_k(int k) {
    //k -> v map
    static const std::unordered_map<int, int> k_to_v_map = {
        {138, 9}, {137, 10}, {136, 11}, {135, 12}, {134, 13}, {133, 14}, {132, 15},
        {131, 16}, {130, 17}, {129, 18}, {128, 19}, {127, 20}, {126, 21}, {125, 22},
        {124, 23}, {123, 24}, {122, 25}, {121, 26}, {120, 27}, {119, 28}, {118, 29},
        {117, 30}, {116, 31}, {115, 32}, {114, 33}, {113, 34}, {112, 35}, {111, 36},
        {110, 37}, {109, 38}, {108, 39}, {107, 40}, {106, 41}, {105, 42}, {104, 43},
        {103, 44}, {102, 45}, {101, 46}, {100, 47}, {99, 48},  {98, 49},  {97, 50},
        {96, 51},  {95, 52},  {94, 53},  {93, 54},  {92, 55},  {91, 56},  {90, 57},
        {89, 58},  {88, 59},  {87, 60},  {86, 61},  {85, 62},  {84, 63},  {83, 64},
        {82, 65},  {54, 66},  {55, 67},  {56, 68},  {57, 69},  {58, 70},  {59, 71},
        {60, 72},  {61, 73},  {62, 74},  {63, 75},  {64, 76},  {65, 77}
    };
    auto it = k_to_v_map.find(k);
    return (it != k_to_v_map.end()) ? it->second : -1;
}

// Substitution for the 855-round conditional superpoly
void spoly855_substitution() {
    // Example usage
    bitset<N> key;
	vector<int> kid = {61,63,100,102,124,126};
	// vector<int> kid;
	for (auto it : kid) {
		key[it] = 1;
	}
    // Replace with your file path 

    string filename = "/home/Practical_Trivium_attack/855_con_spoly/variable_z83_k61k63k100k102k124k126/dim45v1v3v5v7v9v12v14v16v18v20v22v24v27v29v31v33v35v37v39v42v44v46v48v50v52v54v57v59v61v63v65v67v72v74v76v78v70v68v0v69v2v11v10v13v79.txt";

    vector<KVpoly> all_kvps = readPolynomialParallelUnmerged(filename);
    // cout <<kvp<<endl;
    cout<<all_kvps.size()<<endl;
    cout << "read!"<< endl;
    vector<KVpoly> all_result(all_kvps.size());

    for (int count = 0; count < all_kvps.size(); count++) {
        KVpoly result;
        KVpoly ORIGINAL = all_kvps[count];
        auto start = std::chrono::high_resolution_clock::now();
        vector<Kpoly> results = spoly_without_combine_like_terms(result, ORIGINAL, 0, 83, key);

        createFolder("855_without_combine");
        ofstream spolyfile("855_without_combine/spoly_" + to_string(count) + ".txt");
        cout<< "start output"<<endl;
        for (size_t i = 0; i < results.size(); i++)
        {
            spolyfile << results[i] << "+";
        }
        spolyfile << endl;
        auto end = std::chrono::high_resolution_clock::now();
        auto duration = std::chrono::duration_cast<std::chrono::seconds>(end - start);
        std::cout << "Time: " << duration.count() << " s" << std::endl;
        cout << "num "<<count<<" done"<<endl;
    }
}   





// Givien a cube, calculate eliminatable variables set 
void cube_calculate_eliminatable_set() {
    for (size_t i = 0; i < 3; i++)
    {
        // int round=845;
        int round = 855;
        int THREAD_NUM = 512;
        int threshold = 80;
        string foldername = to_string(round) + "_app_" + to_string(FASTBOUND) + "_" + to_string(BASEROUND);
        // vector<int>cubeIndex = {0,1,2,3,4,5,7,9,10,11,12,13,14,16,18,20,22,24,26,27,28,29,31,33,35,37,39,40,41,42,43,44,46,48,50,52,54,55,57,59,61,63,65,67,69,72,74,76,78};
        vector<int>cubeIndex = {1,3,5,7,9,12,14,16,18,20,22,24,27,29,31,33,35,37,39,42,44,46,48,50,52,54,57,59,61,63,65,67,72,74,76,78,70,68,0,69,2,11,10,13,79};
        vector<int> a = new_recovery_app(round, THREAD_NUM, cubeIndex, foldername,threshold,i);
    }
}

// Find a large eliminatable variables set for a set of random cubes 
void Find_eliminatable_set() {
    vector<vector<int>> all_cubes = readFileTo2DVector("845_test_cubes.txt");
    // ofstream ff("845_test_basis_0-25.txt",ios::app);
    ofstream ff("845_test_basis_25-50.txt",ios::app);
    // for (int j = 0; j < 25; j++) {
    for (int j = 25; j < 50; j++) {
        set<int> basis;
        for (size_t i = 0; i < 3; i++)
        {
            int round = 845;
            int THREAD_NUM = 400;
            int threshold = 80;
            string foldername = to_string(round) + "_app_" + to_string(FASTBOUND) + "_" + to_string(BASEROUND);
            vector<int> a = new_recovery_app( round,  THREAD_NUM, all_cubes[j], foldername,threshold,0);
            for(const auto& it:a) {
                basis.insert(it);
            }
        }
        for(const auto& it :all_cubes[j]) {
            ff << it <<" ";
        }
        ff<<endl;
        for(const auto& it:basis) {
            ff << it << " ";
        } 
        ff<<endl;
    }
}

// Find good eliminatable set
void check_eliminatable_set() {
    vector<vector<int>> cubes_and_k = readFileTo2DVector1("845_test_basis_25-50.txt");
    // vector<vector<int>> cubes_and_k = readFileTo2DVector1("845_test_basis_0-25.txt");
    ofstream ff("845_tuples_1.txt",ios::app);
    // ofstream ff("845_tuples.txt",ios::app);
    for(int i=0;i<cubes_and_k.size();i=i+2){
        int round = 845;
        // int bound = 18;
        int bound = 120;
        vector<int> cubeIndex = cubes_and_k[i];
        string filename = "845_test_k_1.txt";
        // string filename = "845_test_k.txt";
        vector<int> k_basis = cubes_and_k[i+1];
        vector<vector<int>> tuples = test_k (round, cubeIndex, bound, filename, k_basis,i);
        for(auto it: tuples) {
            for (auto j:it) {
                ff << j <<" "; 
            }
            ff << endl;
        }
        ff<<endl;
    }
}

// Given eliminatable set, get the corresbonding cube set
void Filter_cubes() {
    string filename0 = "845_small_50_45.txt";
    vector<vector<int>> all_cubes = readFileTo2DVector(filename0);
    string filename;
    // vector<int> kid = {57,82,84};
    // vector<int> kid = {90,116,114};
    // vector<int> kid = {90,116,118};
    // vector<int> kid = {100,113,115};
    // vector<int> kid = {54,56,100};
    // vector<int> kid = {63,65,113};
    // vector<int> kid = {114,116,118};
    // vector<int> kid = {55,57,59};
    // vector<int> kid = {55,57,82};
    // vector<int> kid = {55,57,129};
    // vector<int> kid = {90,103,105};
    // vector<int> kid = {56,54,58};
    // vector<int> kid = {56,58,100};
    vector<int> kid = {90, 103, 88 };
    sort(kid.begin(),kid.end());
    vector<int> vs;
    for(auto it : kid) {
        int v = get_v_from_k(it);
        vs.push_back(v);
        filename += "k"+to_string(it);
    }
    filename += "_" + filename0;
    ofstream ff (filename,ios::app);
    set<vector<int>> select_cubes;
    for (auto vec: all_cubes) {
        bool a = true;
        for (auto v: vs) {
            if (find(vec.begin(), vec.end(), v) != vec.end()) {
                a = false;
                break;
            }
        }
        if (a) {
            select_cubes.insert(vec);
        }
    }
    for (auto vec: select_cubes) {
        for(auto it: vec){
            ff << it << " ";
        }
        ff<<endl;
    }
}

// Given a cube and k, calculate con-spoly. 
void calculate_con_spoly() {
    // int round=840;
    int round = 845;
    int THREAD_NUM = 512;
    int threshold = BOUND;
    vector<int> cubeIndex = {0,1,2,3,4,5,6,8,10,12,13,15,17,19,21,23,25,27,29,30,32,34,36,38,40,41,42,43,45,47,49,51,53,55,56,58,60,62,64,66,68,70,73,75,77,79};
    vector<int> kid ={55,57,84};
    sort(kid.begin(),kid.end());
    new_recovery_spoly_with_fix_basis(round, THREAD_NUM, cubeIndex, threshold, kid,0);
}

// calculate superpoly
void calculate_superpoly() {
    int round = 840;
    int THREAD_NUM = 512;
    // vector<int> cubeIndex = {0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,34,36,38,40,42,45,47,49,51,53,55,57,60,62,64,66,68,70,72,75,77,79}; 843
    // vector<int> cubeIndex = {0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,34,36,38,40,42,45,47,49,51,53,55,57,60,62,64,66,68,70,72,77,75,79};840-1
    // vector<int> cubeIndex = {0,1,2,3,4,5,6,7,8,10,12,13,14,15,16,18,20,23,25,27,29,31,33,35,37,40,42,44,46,48,50,52,55,57,59,61,63,65,67,70,72,74,76,77,78,79};//840-2 
    vector<int> cubeIndex = {0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,24,25,27,29,30,31,33,35,36,37,38,40,42,44,46,48,50,52,55,57,59,61,63,65,67,70,72,74,76,78};//840-3
    int threshold = 784662500; 
    vector<int> kid;
    int p_id = 0;  
    new_recovery_spoly_with_fix_basis(round,  THREAD_NUM, cubeIndex,  threshold, kid, p_id);
}

int main() {
    // ***************************************************************************

    // For check_eliminatable_set(), the FASTBOUND should be Round-330=845-330=515.

    // For other function, FASTBOUND is Round - 630.

    // Detials of parameter settings are in triviumframework.h

    // ***************************************************************************

    // cube_calculate_eliminatable_set();
    // Find_eliminatable_set();
    // check_eliminatable_set();
    // Filter_cubes();
    // calculate_con_spoly();
    // calculate_superpoly();
    spoly855_substitution();

    return 0;
}




