#include<malloc.h>
#include<map>
#include<cmath>
#include<vector>
#include<bitset>
#include<string>
#include"trivium.h"
#include"gurobi_c++.h" 
#include"node.h"
#include"thread_pool.h"
#include"triviumcallback.h"
#include"log.h"
#include"triviumframework.h"
#include "main.h"

using namespace std;
using namespace thread_pool;
mutex threadMutex;

namespace fs = std::filesystem;

// const int BITSET_SIZE = 288;

vector<bitset<BITSET_SIZE>> readFileToBitsets(const string& filename) {
    vector<bitset<BITSET_SIZE>> bitsets;
    ifstream file(filename);

    if (file.is_open()) {
        string line;
        while (getline(file, line)) {
            try {
                bitset<BITSET_SIZE> bitset(line);
                bitsets.push_back(bitset);
            } catch (const invalid_argument& e) {
                cerr << "invalid 01 string: " << line << endl;
            }
        }
        file.close();
    } else {
        cerr << "Unable to open file: " << filename << endl;
    }

    return bitsets;
}

set<vector<int>> readFileToset(const string& filePath) {
    ifstream inputFile(filePath);
    if (!inputFile.is_open()) {
        cerr << "Error: Unable to open file " << filePath << endl;
        return {};
    }   
    set<vector<int>> result;
    string line;   
    while (getline(inputFile, line)) {        
        vector<int> row;
        stringstream ss(line);
        int number;        
        while (ss >> number) {
            row.push_back(number);
        }
        if(row.size()>3) {
            result.insert(row);
        }
    }
    inputFile.close();
    return result;
}

void selectRandomN(vector<bitset<BITSET_SIZE>>& input, size_t n) {
    if (input.empty()) {
        throw invalid_argument("empty vec");
    }
    if (n > input.size()) {
        throw invalid_argument("n is too large");
    }

    random_device rd;  
    mt19937 gen(rd()); 


    shuffle(input.begin(), input.end(), gen);


    input.resize(n);
}

set<int> extractIsolatedNumbers(const vector<int>& sortedVec) {
    set<int> result;
    int n = sortedVec.size();
    
    if (n == 0) {
        return result; // 空向量直接返回
    }
    
    for (int i = 0; i < n; ++i) {
        bool isIsolated = true;
        
        if (i == 0) { // 首部元素，只需检查右边
            if (n > 1 && sortedVec[i+1] - sortedVec[i] == 1) {
                isIsolated = false;
            }
        } 
        else if (i == n - 1) { // 尾部元素，只需检查左边
            if (sortedVec[i] - sortedVec[i-1] == 1) {
                isIsolated = false;
            }
        } 
        else { // 中间元素，检查左右两边
            if (sortedVec[i] - sortedVec[i-1] == 1 || sortedVec[i+1] - sortedVec[i] == 1) {
                isIsolated = false;
            }
        }
        
        if (isIsolated) {
            result.insert(sortedVec[i]);
        }
    }
    
    return result;
}


// second Expand using divde-and-conquer
void ThreadWorkerExpand(const vector<bitset<288>>& layerTerm, const bitset<80>& cube,
	int start, int end, int step,
	map<bitset<288>, int, CMPS<288>>& layerMap, int singlethread)
{
	//map<bitset<80>, int, CMPS<80>> solutions;
	map<bitset<288>, int, CMPS<288>>  threadLayerMap;

	int END = end <= layerTerm.size() ? end : layerTerm.size();

	vector<bitset<288>> terms;


	for (int i = start; i < END; i++)
	{
		terms.clear();
		SecondBackExpandPolynomial(step, layerTerm[i], terms, singlethread);


		for (auto& it : terms)
			threadLayerMap[it] += 1;
	}

	lock_guard<mutex> guard(threadMutex);
	for (auto& it : threadLayerMap)
		layerMap[it.first] += it.second;
}

void expandFunc(bitset<80>& cube, vector<bitset<288> >& layerTerms, int& start, float time, int singlethread)
{
	vector<thread> threads;
	int THREAD_NUM = 16;
	int step = 0;
	map<bitset<288>, int, CMPS<288> > layerMap;

	while (layerMap.size() < SIZEBOUND)
	{
		step++;
		layerMap.clear();

		int size = layerTerms.size();

		int base = (size / THREAD_NUM) >= 1 ? (size / THREAD_NUM) :
			1;
		int size_multiple = base * THREAD_NUM;

		threads.clear();

		// expand the terms 
		for (int i = 0; i < THREAD_NUM; i++)
			threads.push_back(thread(ThreadWorkerExpand, ref(
				layerTerms), ref(cube), base * i, base * (i + 1), step,
				ref(layerMap), singlethread));
		for (auto& th : threads) th.join();

		if (size > size_multiple)
		{
			threads.clear();
			for (int i = 0; i < THREAD_NUM; i++)
				threads.push_back(thread(ThreadWorkerExpand, ref(
					layerTerms), ref(cube), size_multiple + i, size_multiple + i + 1, step,
					ref(layerMap), singlethread));
			for (auto& th : threads) th.join();
		}
	}

	start = start - step;

	logger("Step New " + to_string(step));
	logger("Round New " + to_string(start));
	logger(string("layerMapSize ") + to_string(layerMap.size()));

	layerTerms.clear();
	filterMap<288>(layerMap);

	for (auto& x : layerMap)
		layerTerms.emplace_back(x.first);

	filterTerms(cube, start, layerTerms);

	for (auto& x : layerTerms)
		loggerState(x.to_string(), start);
}

// second Expand using callback function
void newThreadWorkerCallBack(int rounds, int midround, bitset<80>& cube, bitset<288>& last, map<bitset<288>, int, CMPS<288> >& resMap, float time, int threads, bool mode, bool& indicator, bitset<BITSET_SIZE> zero_s)//rounds是更高的轮数，midround是rounds减去step的轮数，last是x，表示一个在rounds的解，x是states的分量，加入一个示性变量以及一个模式选择变量
{
	vector<bitset<288>> res;
	auto status = uMidSolutionCallBack(rounds, cube, last, res, time, threads, midround, BASEROUND, zero_s);
	if (mode) {
		if (status == EXPAND)
		{
			logger("timeout" + string(" : need expand."));
			res.clear();
			SecondBackExpandPolynomial(rounds - midround, last, res, threads);
			// auto status_0 = uMidSolutionCallBack(rounds, cube, last, res, 10000, 128, midround, BASEROUND, zero_s);
			// if (status_0 == EXPAND)
			// {
			// 	logger("timeout" + string(" : output state."));
			// 	ofstream ff(to_string(rounds)+"timeout_states.log",ios::app);
			// 	ff<<last<<endl;
			// }
		}
	}

	else {
		if (status == EXPAND)
		{
			indicator = false;
		}
	}

	{
		lock_guard<mutex> guard(threadMutex);
		for (auto& x : res)
			resMap[x] ++;
	}
}

void app_newExpandFunc(bitset<80>& cube, vector<bitset<288> >& states, int& start, int step, ThreadPool& threadpool, float time, int singlethread, int threshold, bool mode, bool& indicator, bitset<BITSET_SIZE> zero_s,int p_id)
{
	if (step > start)
		return;
	int midround = start - step;
	int execCnt = 0;
	int threads = singlethread;
	// ofstream sl("compare_" + to_string(FASTBOUND) + "_" + to_string(BASEROUND) + "_"+to_string(p_id)+".log",ios::app);
	// ofstream sl("840_cubes_" + to_string(FASTBOUND) + "_" + to_string(BASEROUND) + "_"+to_string(p_id)+".log",ios::app);
	ofstream sl("855_spoly_" + to_string(FASTBOUND) + "_" + to_string(BASEROUND) + "_"+to_string(p_id)+".log",ios::app);

	// ofstream sl("ktest_" + to_string(FASTBOUND) + "_" + to_string(BASEROUND) + "_25-50.log",ios::app);
	// ofstream sl("ktuple_" + to_string(FASTBOUND) + "_" + to_string(BASEROUND) + "_0-25.log",ios::app);
	// ofstream sl("ktuple_" + to_string(FASTBOUND) + "_" + to_string(BASEROUND) + "_25-50.log",ios::app);
	// ofstream sl("app_" + to_string(FASTBOUND) + "_" + to_string(BASEROUND) + ".log",ios::app);
	// ofstream sl("sub_" + to_string(FASTBOUND) + "_" + to_string(BASEROUND) + ".log",ios::app);
	// ofstream sl("test" + to_string(FASTBOUND) + "_" + to_string(BASEROUND) + "_"+to_string(p_id)+".log",ios::app);
	// ofstream sl("test_k54k56k100_" + to_string(FASTBOUND) + "_" + to_string(BASEROUND) + "_"+to_string(p_id)+".log",ios::app);
	// ofstream sl("test_k88k90k103_" + to_string(FASTBOUND) + "_" + to_string(BASEROUND) + "_"+to_string(p_id)+".log",ios::app);
	// ofstream sl("test_k55k57k82_" + to_string(FASTBOUND) + "_" + to_string(BASEROUND) + "_"+to_string(p_id)+".log",ios::app);
	// ofstream sl("test_k54k56k58_" + to_string(FASTBOUND) + "_" + to_string(BASEROUND) + "_"+to_string(p_id)+".log",ios::app);
	// ofstream sl("test_k63k65k113_" + to_string(FASTBOUND) + "_" + to_string(BASEROUND) + "_"+to_string(p_id)+".log",ios::app);
	// ofstream sl("test_k100k113k115_" + to_string(FASTBOUND) + "_" + to_string(BASEROUND) + "_"+to_string(p_id)+".log",ios::app);
	// ofstream sl("test_k90k116k118_" + to_string(FASTBOUND) + "_" + to_string(BASEROUND) + "_"+to_string(p_id)+".log",ios::app);
	// ofstream sl("test_k90k114k116_" + to_string(FASTBOUND) + "_" + to_string(BASEROUND) + "_"+to_string(p_id)+".log",ios::app);
	// ofstream sl("test_k57k82k84_" + to_string(FASTBOUND) + "_" + to_string(BASEROUND) + "_"+to_string(p_id)+".log",ios::app);
	// ofstream sl("test_k90k103k105_" + to_string(FASTBOUND) + "_" + to_string(BASEROUND) + "_"+to_string(p_id)+".log",ios::app);
	// ofstream sl("spoly_k114k116k118_" + to_string(FASTBOUND) + "_" + to_string(BASEROUND) + "_"+to_string(p_id)+".log",ios::app);
	// ofstream sl("spoly_k55k57k82_" + to_string(FASTBOUND) + "_" + to_string(BASEROUND) + "_"+to_string(p_id)+".log",ios::app);
	// ofstream sl("spoly_k54k56k100_" + to_string(FASTBOUND) + "_" + to_string(BASEROUND) + "_"+to_string(p_id)+".log",ios::app);
	// ofstream sl("spoly_k88k90k103_" + to_string(FASTBOUND) + "_" + to_string(BASEROUND) + "_"+to_string(p_id)+".log",ios::app);
	// ofstream sl("spoly_k90k103k105_" + to_string(FASTBOUND) + "_" + to_string(BASEROUND) + "_"+to_string(p_id)+".log",ios::app);
	// ofstream sl("spoly_k54k56k58_" + to_string(FASTBOUND) + "_" + to_string(BASEROUND) + "_"+to_string(p_id)+".log",ios::app);
	// ofstream sl("spoly_k90k116k118_" + to_string(FASTBOUND) + "_" + to_string(BASEROUND) + "_"+to_string(p_id)+".log",ios::app);
	// ofstream sl("spoly_k100k113k115_" + to_string(FASTBOUND) + "_" + to_string(BASEROUND) + "_"+to_string(p_id)+".log",ios::app);

	for (int cu = 0; cu < 80; cu++) {
		if (cube[cu] == 1) {
			sl<< cu <<" ";
		}
	}
	sl << endl;
	//计算出vktable
	// while ((states.size() < SIZEBOUND && start > FASTBOUND) || (start <= FASTBOUND && execCnt == 0))
	// while ((start > FASTBOUND) || (start <= FASTBOUND && execCnt == 0))
	while (start > FASTBOUND)
	{
		map<bitset<288>, int, CMPS<288> > resMap;
		vector<std::future<void>> futures;
		for (auto& x : states)
			futures.emplace_back(threadpool.Submit(newThreadWorkerCallBack, start, midround, ref(cube), ref(x), ref(resMap), time, threads, mode, ref(indicator), zero_s));

		for (auto& x : futures)
			x.get();

		logger("from " + to_string(start) + " to " + to_string(midround) + " complete.");
		// filterMap
		filterMap<288>(resMap);
#ifdef _WIN32
#else
		showProcessMemUsage();
		malloc_trim(0);
		showProcessMemUsage();
#endif
		// save resMap
		states.clear();
		for (auto& x : resMap)
		{
			// loggerState(x.first.to_string(), midround);
			states.emplace_back(x.first);
		}
		// update start and midround and states
		start = midround;
		midround = start - step;
		if (midround < FASTBOUND) {
			midround = FASTBOUND;
		}
		filterTerms(cube, start, states);
		logger("next states Size : " + to_string(states.size()));
		execCnt++;
		cout << "round: " << start <<"  solutions:  " << states.size() << endl;
		sl << "round: " << start <<"  solutions:  " << states.size() << endl;
		// auto start = chrono::system_clock::now();
    	string startTime = getCurrentSystemTime(TIMEFLAG);
    	sl << "Start Time: " << startTime << endl;
		
		if ((threshold == 80)&&(start > BCROUND)&&(states.size() > threshold)) {
			selectRandomN(states,threshold);
			// states.resize(threshold);
			// break;
		}	

		// ofstream ff(to_string(start) + "_vts.log",ios::app);
		// for (size_t i = 0; i < states.size(); i++)
		// {
		// 	ff << states[i] <<endl;
		// }

		// if (!indicator) {
		// 	states.clear();
		// 	break;
		// }


		if (states.size() == 0) {
			break;
		}
		logger("cut_next states Size : " + to_string(states.size()));

		sl << "size of a: "<< states.size()<<endl;
		time = time + 100;

	}
}

// Given a cube and a set of eliminable variables, calculate the number of conditional valueable terms 
int varify_app(int round, vector<int> cubeIndex, int threshold, vector<int> kid,int p_id) {
	// int midround = FASTBOUND;
	int step = 300;
	int expandStep = 30;
	float expandTime = 30;
	bitset<80> cube{ 0 };
	string filename0;
	for (auto& it : cubeIndex) {
		cube[it] = 1;
		filename0 += "v" + to_string(it);
	}
	filename0 += ".txt";
	cout << cube << endl;
	// ofstream spolyfile (filename,ios::app);
	bool mode = true;
	bool indicator = true;
	int singlethread = 6;
	bitset<N> key;
	string folder = to_string(FASTBOUND) + "_";
	for (auto it : kid) {
		key[it] = 1;
		folder += "k" + to_string(it);
	}

	bitset<BITSET_SIZE> zero_s;

	ThreadPool thread_pool{};
	auto start = chrono::system_clock::now();
	string startTime = getCurrentSystemTime(TIMEFLAG);
	cout << "Start Time: " << startTime << endl;
	vector<bitset<288>> terms;
	int BB = BackExpandPolynomial(step, terms);
	if (BB != 0)
	{
		return -1;
	}
	int ROUND = round;
	ROUND = ROUND - step;
	filterTerms(cube, ROUND, terms);
	logger(__func__ + string("First expand"));

	vector<KVpoly> pstate0, pstate1;
	vector<KVpoly> state1(288);
	vector<Kpoly> k_fun;
	trivium_simplify_poly(state1, k_fun, BASEROUND);

	map<vector<int>, vector<int>> vk_table = trivium_flag_poly_2(cube, key, state1, pstate1);
	
	auto it = vk_table.begin();
	while (it != vk_table.end()) {
		vector<int> a = (*it).first;
		vector<int> b = (*it).second;
		for (auto b_num : b) {
			zero_s[b_num] = 1;
		}
		it++;
	}
	logger(string("done!"));

	if (ROUND < CALLBACKBOUND)
		app_newExpandFunc(cube, terms, ROUND, expandStep, thread_pool, expandTime, singlethread, threshold, mode, indicator, zero_s,p_id);//
	else {
		expandFunc(cube, terms, ROUND, expandTime, singlethread);
	}
	int a = terms.size();
	
	// if (a <= VTBOUND) {
	// 	if (createFolder(folder)) {
	// 		std::cout << "done" << std::endl;
	// 	} else {
	// 		std::cout << "gg" << std::endl;
	// 	}
	// 	ofstream vts(folder + "/" + filename0);
	// 	for (auto it: terms)
	// 	{
	// 		vts<<it<<endl;
	// 	}
	// }
	return a;
}

//Given a eliminatable variable set and a cube, find pairs with small conditionale valueable terms. 

vector<vector<int>> test_k (int round, vector<int> cubeIndex,int bound,string filename, vector<int> k,int p_id) {
	ofstream ff(filename,ios::app);
	for(auto it: cubeIndex){
		ff<<it<<" ";
	}
	ff << endl;
	vector<pair<int,int>> pairs_1;
	for (size_t i = 0; i < k.size(); i++)
	{
		vector<int> kid;
		kid.push_back(k[i]);
		ff << "k: "<< k[i];
		int a = varify_app(round, cubeIndex, 2000, kid, p_id);
		pair<int,int> tmp;
		ff << " terms: " << a << endl;
		tmp.first = a;
		tmp.second = k[i];
		pairs_1.push_back(tmp);
	}
	sort(pairs_1.begin(),pairs_1.end());

	vector<int> new_k = k;
	for (size_t i = 0; i < 10; i++)
	{
		new_k.push_back(pairs_1[i].second);
	}

	vector<pair<int,vector<int>>> pairs_2;
	for (size_t i = 0; i < 9; i++) {
		for (size_t j = i+1; j < 10; j++) {
			vector<int> kid;
			kid.push_back(new_k[i]);
			kid.push_back(new_k[j]);
			int a = varify_app(round, cubeIndex, 2000, kid,p_id);
			pair<int,vector<int>> tmp;
			tmp.first = a;
			tmp.second = kid;
			pairs_2.push_back(tmp);
		}
	}

	vector<vector<int>> tuples;

	sort(pairs_2.begin(),pairs_2.end());
	for(auto it : pairs_2){
		if (it.first <= bound) {
			tuples.push_back(it.second);
		}
		ff << "k "<< it.second[0] << " " << it.second[1] << " " << "vt: " << it.first << endl;
	}
	
	vector<pair<int,vector<int>>> pairs_3;
	for (size_t i = 0; i < 6; i++)
	{
		for (size_t j = i+1; j < 7; j++)
		{
			for (size_t t = j+1; t < 8; t++) 
			{
				vector<int> kid;
				kid.push_back(new_k[i]);
				kid.push_back(new_k[j]);
				kid.push_back(new_k[t]);
				int a = varify_app(round, cubeIndex, 2000, kid,p_id);
				pair<int,vector<int>> tmp;
				tmp.first = a;
				tmp.second = kid;
				pairs_3.push_back(tmp);
			}
		}
	}
	sort(pairs_3.begin(),pairs_3.end());
	
	for(auto it : pairs_3){
		if(it.first <= bound){
			tuples.push_back(it.second);
		}
		ff << "k "<< it.second[0] << " " << it.second[1] << " " << it.second[2] << " vt: " << it.first << endl;
	}


	// vector<pair<int, vector<int>>> pairs_all;
	// int min_size = 3;  
	// int max_size = new_k.size();  

	// for (int subset_size = min_size; subset_size <= max_size; subset_size++) {
	// 	
	// 	vector<bool> v(new_k.size());
	// 	fill(v.begin(), v.begin() + subset_size, true);

	// 	do {
	// 		vector<int> kid;
	// 		for (size_t i = 0; i < v.size(); ++i) {
	// 			if (v[i]) {
	// 				kid.push_back(new_k[i]);
	// 			}
	// 		}
	// 		int a = varify_app(round, cubeIndex, 2000, kid, p_id);
	// 		pair<int, vector<int>> tmp;
	// 		tmp.first = a;
	// 		tmp.second = kid;
	// 		pairs_all.push_back(tmp);
	// 	} while (prev_permutation(v.begin(), v.end()));
	// }

	// sort(pairs_all.begin(), pairs_all.end());

	// for (auto it : pairs_all) {
	// 	if (it.first <= bound) {
	// 		tuples.push_back(it.second);
	// 	}
	// 	ff << "k ";
	// 	for (auto num : it.second) {
	// 		ff << num << " ";
	// 	}
	// 	ff << "vt: " << it.first << endl;
	// }

	return tuples;
}

// term expand part of the nest_coef
int single_app_newExpandFunc(bitset<80>& cube, vector<bitset<288> >& states, int& start, int step, ThreadPool& threadpool, float time, int singlethread, bitset<BITSET_SIZE> zero_s,int p_id)
{
	if (step > start)
		return -1;

	int midround = max(start - step,OUTROUND);
	int execCnt = 0;
	int threads = singlethread;
	bool mode = true;//
	bool indicator = true;
	// ofstream sl("spoly_k114k116k118_" + to_string(FASTBOUND) + "_" + to_string(BASEROUND) + "_"+to_string(p_id)+".log",ios::app);
	// ofstream sl("spoly_k55k57k82_" + to_string(FASTBOUND) + "_" + to_string(BASEROUND) + "_"+to_string(p_id)+".log",ios::app);
	// ofstream sl("spoly_k54k56k100_" + to_string(FASTBOUND) + "_" + to_string(BASEROUND) + "_"+to_string(p_id)+".log",ios::app);
	// ofstream sl("spoly_k88k90k103_" + to_string(FASTBOUND) + "_" + to_string(BASEROUND) + "_"+to_string(p_id)+".log",ios::app);
	// ofstream sl("spoly_k90k103k105_" + to_string(FASTBOUND) + "_" + to_string(BASEROUND) + "_"+to_string(p_id)+".log",ios::app);
	// ofstream sl("spoly_k54k56k58_" + to_string(FASTBOUND) + "_" + to_string(BASEROUND) + "_"+to_string(p_id)+".log",ios::app);//90 114 116
	// ofstream sl("spoly_k100k113k115_" + to_string(FASTBOUND) + "_" + to_string(BASEROUND) + "_"+to_string(p_id)+".log",ios::app);
	// ofstream sl("spoly_k90k116k118_" + to_string(FASTBOUND) + "_" + to_string(BASEROUND) + "_"+to_string(p_id)+".log",ios::app);
	ofstream sl("compare_" + to_string(FASTBOUND) + "_" + to_string(BASEROUND) + "_"+to_string(p_id)+".log",ios::app);

	for (int cu = 0; cu < 80; cu++) {
		if (cube[cu] == 1) {
			sl<< cu <<" ";
		}
	}
	sl << endl;
	//计算出vktable
	map<bitset<288>, int, CMPS<288> > resMap;
	vector<std::future<void>> futures;
	for (auto& x : states)
		futures.emplace_back(threadpool.Submit(newThreadWorkerCallBack, start, midround, ref(cube), ref(x), ref(resMap), time, threads, mode, ref(indicator), zero_s));
	
	if (!indicator) {
		return -1;
	}
	for (auto& x : futures)
		x.get();

	logger("from " + to_string(start) + " to " + to_string(midround) + " complete.");
	// filterMap
	filterMap<288>(resMap);
#ifdef _WIN32
#else
	showProcessMemUsage();
	malloc_trim(0);
	showProcessMemUsage();
#endif
	// save resMap
	states.clear();
	for (auto& x : resMap)
	{
		// loggerState(x.first.to_string(), midround);
		states.emplace_back(x.first);
	}
	// update start and midround and states
	filterTerms(cube, midround, states);
	logger("next states Size : " + to_string(states.size()));
	sl << "round: " << midround <<"  solutions:  " << states.size() << endl;
	// ofstream ff(to_string(start) + "_vts.log",ios::app);
	ofstream ff(to_string(midround) + "_vts.log",ios::app);
	for (size_t i = 0; i < states.size(); i++)
	{
		ff << states[i] <<endl;
	}
	// auto start = chrono::system_clock::now();
	string startTime = getCurrentSystemTime(TIMEFLAG);
	sl << "Start Time: " << startTime << endl;
	// if (start <= 120) {
	// 	threads = 2;
	// }	
	sl << "size of a: "<< states.size()<<endl;
	start = midround;	
	return 0;
}

// input a set of monomials and a cube, return the corresponding superpoly
vector<bitset<BITSET_SIZE>> coef (int outround, string filename,bitset<80> cube, const vector<bitset<288>>& terms, KVpoly& spoly,int THREAD_NUM,vector<int> kid) {
	// auto start = chrono::system_clock::now();
	// string startTime = getCurrentSystemTime(TIMEFLAG);
	int a = terms.size();
	vector<KVpoly> in_state1(288);
	vector<Kpoly> in_k_fun;
	// KVpoly spoly;
	trivium_simplify_poly(in_state1, in_k_fun, outround);
	vector<KVpoly> in_pstate1;
	// spoly.p.clear();
	// trivium_flag_poly(cube, in_state1, in_pstate1);
	bitset<N> key;
	for(auto it : kid) {
		key[it]=1;
	}
	trivium_flag_poly_1(cube, key, in_state1, in_pstate1);//add cube and key constrains 

	int count = 0;
	int all_trails = 0;
	bool tl = true; // whether time limit
	if (outround==OUTROUND)
	{
		tl=false;
	}
	
	vector<KVpoly> all_spoly(terms.size());
	vector<bitset<BITSET_SIZE>> rest_terms;
	omp_set_num_threads(THREAD_NUM);
	#pragma omp parallel for schedule(dynamic) reduction(+:all_trails, count)
	for (size_t i = 0; i < terms.size(); i++) {
		int result = N0_round_model(in_pstate1, cube, 1, terms[i], all_spoly[i], tl);
		if (result != -1) {
			all_trails += result;
			count++;
		} else {
			#pragma omp critical
			rest_terms.push_back(terms[i]);
		}
	}

	Vmono vmono;
	bitset<M> zero_cube;
	vmono.v = zero_cube;
	omp_set_num_threads(THREAD_NUM);
	std::vector<KVpoly> thread_results(THREAD_NUM);  

	#pragma omp parallel
	{
		int tid = omp_get_thread_num();       
		auto& local = thread_results[tid];    
		local.p.clear();                      

		#pragma omp for schedule(dynamic, 1000) 
		for (auto& it : all_spoly) {          
			local.p[vmono] = local.p[vmono] + it.p[vmono];    
		}
	}


	// Tree Merging
	for (int stride = 1; stride < THREAD_NUM; stride *= 2) {
		#pragma omp parallel for
		for (int i = 0; i < THREAD_NUM; i += 2 * stride) {
			if (i + stride < THREAD_NUM) {
				thread_results[i].p[vmono] = thread_results[i].p[vmono] + thread_results[i + stride].p[vmono];
			}
		}
	}

	spoly.p[vmono] = spoly.p[vmono] +  thread_results[0].p[vmono];

	cout << "Total trails: " << all_trails << endl;
	
	// ofstream spolyfile(to_string(outround)+"_part_spoly.txt",ios::app);
	// spolyfile << spoly << endl;
	// spolyfile << all_trails << endl;
	// cout << spoly << endl;
	// cout << "Success!" << endl;

	return rest_terms;
}

// nested coefficient solver

void nest_coef (int outround, string filename,bitset<80> cube, vector<bitset<288>>& terms, KVpoly& spoly,int THREAD_NUM,vector<int> kid,int p_id){
	auto start = chrono::system_clock::now();
	string startTime = getCurrentSystemTime(TIMEFLAG);
	int midround = outround;
	int expandStep = 30;
	// float time = 180;
	float time = 60;
	int singlethread = 8;
	vector<bitset<BITSET_SIZE>> rest_terms;
	vector<bitset<BITSET_SIZE>> check_terms = terms;
	ThreadPool thread_pool{};

	// bool ct=true;
	while (check_terms.size() > 0) {
		vector<bitset<BITSET_SIZE>> rest_terms = coef (midround, filename, cube, check_terms, spoly, THREAD_NUM,kid);//得到剩下的项，进入下一个环节,并且一旦达到OUTROUND，这个输出一定是空集
		check_terms = rest_terms;
		cout<<"check_size: "<< check_terms.size()<<endl;
		logger("check_size: " + to_string(check_terms.size()));

		// midround = max(midround - expandStep,OUTROUND);
		bitset<BITSET_SIZE> zero_s;
		vector<KVpoly> pstate1;
		vector<KVpoly> state1(288);
		vector<Kpoly> k_fun;
		bitset<N> key;
		for (auto it : kid) {
			key[it] = 1;
		}
		// trivium_simplify_poly(state0, k_fun, 0);
		trivium_simplify_poly(state1, k_fun, BASEROUND);
		// trivium_flag_poly_1(cube, key, state0, pstate0);
		map<vector<int>, vector<int>> vk_table = trivium_flag_poly_2(cube, key, state1, pstate1);//这个表是已经把key的信息带进去了，这玩意记录着为1的key对应的所有的s
		//更新zero_s
		auto it = vk_table.begin();
		while (it != vk_table.end()) {
			vector<int> a = (*it).first;
			vector<int> b = (*it).second;
			for (auto b_num : b) {
				zero_s[b_num] = 1;
			}
			it++;
		}
		int indi = single_app_newExpandFunc(cube, check_terms, midround, expandStep, thread_pool, time,  singlethread, zero_s,p_id);
		if (indi == -1) { // If the function fails, clear the polynomial
			spoly.p.clear();
			break;
		}
	}
	
	auto end = chrono::system_clock::now();
	string endTime = getCurrentSystemTime(TIMEFLAG);
	// cout << "End Time: " << endTime << endl;
	auto duration = chrono::duration_cast<chrono::seconds>(end - start).count();
	ofstream spolyfile (filename,ios::app);
	for (int i=0;i<80;i++) {
		if (cube[i]==1)
		{
			spolyfile << i << " ";
		}			
	}
	spolyfile << endl;
	// cout << "Time Difference: " << duration << " seconds" << endl;
	spolyfile << "coe time: " << duration << " seconds" << endl;
}

// Given a cube and eliminatable variables set, calculate the conditional superpoly
int new_recovery_spoly_with_fix_basis(int round, int THREAD_NUM, vector<int> cubeIndex, int threshold, vector<int> kid,int p_id) {
	int midround = FASTBOUND;
	int step = 300;
	int expandStep = 30;
	float expandTime = 30;
	bitset<80> cube{ 0 };
	for (auto& it : cubeIndex) {
		cube[it] = 1;
	}
	cout << cube << endl;
	string foldername;
	if (!kid.empty())
	{
		for (auto& it: kid) {
			foldername += "k"+ to_string(it);
		}
	}
	else {
		// foldername = "00test_spolys";
		foldername = to_string(round) + "_test_spolys";
	}
	string filename = foldername + "/dim" + to_string(cubeIndex.size());
	for (auto& it: cubeIndex) {
		filename += "v"+ to_string(it);
	}
	createFolder(foldername);
	ofstream spolyfile (filename,ios::app);
	bool mode = true;
	bool indicator = true;
	int singlethread = 6;
	bitset<N> key;
	// vector<int> kid = {27,44,60,62,81,86,88,97,99,104,106,121,123,125,127,140,142};
	for (auto it : kid) {
		key[it] = 1;
	}
	bitset<BITSET_SIZE> zero_s;
	
	int count_times = 0;
	ThreadPool thread_pool{};
	auto start = chrono::system_clock::now();
	string startTime = getCurrentSystemTime(TIMEFLAG);
	cout << "Start Time: " << startTime << endl;
	vector<bitset<288>> terms;
	int BB = BackExpandPolynomial(step, terms);
	if (BB != 0)
	{
		return -1;
	}
	int ROUND = round;
	ROUND = ROUND - step;
	filterTerms(cube, ROUND, terms);
	logger(__func__ + string("First expand"));
	vector<KVpoly> pstate0, pstate1;
	// KVpoly spoly;
	// spoly.p.clear();
	vector<KVpoly> state0(288), state1(288);
	vector<Kpoly> k_fun;
	trivium_simplify_poly(state0, k_fun, 0);
	trivium_simplify_poly(state1, k_fun, BASEROUND);
	trivium_flag_poly_1(cube, key, state0, pstate0);
	map<vector<int>, vector<int>> vk_table = trivium_flag_poly_2(cube, key, state1, pstate1);
	//更新zero_s
	auto it = vk_table.begin();
	while (it != vk_table.end()) {
		vector<int> a = (*it).first;
		vector<int> b = (*it).second;
		for (auto b_num : b) {
			zero_s[b_num] = 1;
		}
		it++;
	}
	
	if (ROUND < CALLBACKBOUND)
		app_newExpandFunc(cube, terms, ROUND, expandStep, thread_pool, expandTime, singlethread, threshold, mode, indicator, zero_s,p_id);
	else {
		expandFunc(cube, terms, ROUND, expandTime, singlethread);
	}
	KVpoly spoly;
	spoly.p.clear();
	auto start_in = chrono::system_clock::now();
	// string startTime = getCurrentSystemTime(TIMEFLAG);
	// cout << "Start Time: " << startTime << endl;
	// coef (midround,  filename,cube, terms,spoly,THREAD_NUM,kid);
	nest_coef (midround, filename, cube, terms, spoly,THREAD_NUM,kid,p_id);
	// cout <<spoly<<endl;
	KVpoly result;
	substitute_kvpoly(result, spoly, OUTROUND, FASTBOUND, key);
	// ofstream spolyfile (filename,ios::app);

	spolyfile << result << endl;
	auto end = chrono::system_clock::now();
	string endTime = getCurrentSystemTime(TIMEFLAG);
	// cout << "End Time: " << endTime << endl;

	auto duration = chrono::duration_cast<chrono::seconds>(end - start).count();
	auto duration_coe = chrono::duration_cast<chrono::seconds>(end - start_in).count();
	// cout << "Time Difference: " << duration << " seconds" << endl;
	spolyfile << "Time all: " << duration << " seconds" << endl;
	spolyfile << "Time coe: " << duration_coe << " seconds" << endl;



	// KVpoly spoly;
	// auto start_in = chrono::system_clock::now();
	// // string startTime = getCurrentSystemTime(TIMEFLAG);
	// // cout << "Start Time: " << startTime << endl;
	// coef (midround,  filename,cube, terms,spoly,THREAD_NUM,kid);
	// // cout <<spoly<<endl;
	// KVpoly result;
	
	// substitute_kvpoly(result, spoly, OUTROUND, FASTBOUND, key);

	// spolyfile << result << endl;
	// auto end = chrono::system_clock::now();
	// string endTime = getCurrentSystemTime(TIMEFLAG);
	// // cout << "End Time: " << endTime << endl;
	
	// auto duration = chrono::duration_cast<chrono::seconds>(end - start).count();
	// auto duration_coe = chrono::duration_cast<chrono::seconds>(end - start_in).count();
	// // cout << "Time Difference: " << duration << " seconds" << endl;
	// spolyfile << "Time all: " << duration << " seconds" << endl;
	// spolyfile << "Time coe: " << duration_coe << " seconds" << endl;
	return 0;
}

// Given cube, find eliminatable variables
vector<int> new_recovery_app(int round, int THREAD_NUM, vector<int> cubeIndex, string foldername,int threshold,int p_id) {

	// int midround = FASTBOUND;
	int step = 300;
	int expandStep = 30;
	float expandTime = 30;
	sort(cubeIndex.begin(),cubeIndex.end());

	ofstream bs (to_string(round) + "new_basis_1.txt",ios::app);
	bitset<80> cube{ 0 };
	for (auto& it : cubeIndex) {
		cube[it] = 1;
		bs << it << " ";
	}
	bs << endl;
	cout << cube << endl;
	string filename = foldername + "/dim" + to_string(cubeIndex.size());
	for (auto& it: cubeIndex) {
		filename += "v"+ to_string(it);
	}
	createFolder(foldername);
	ofstream spolyfile (filename,ios::app);
	bool mode = true;
	bool indicator = true;
	int singlethread = 6;
	bitset<N> key;
	// vector<int> kid = {100, 102, 124, 126, 128};
	// for (auto it : kid) {
	// 	key[it] = 1;
	// }
	bitset<BITSET_SIZE> zero_s;

	int count_times = 0;
	while (true)
	{
		ThreadPool thread_pool{};
		auto start = chrono::system_clock::now();
		string startTime = getCurrentSystemTime(TIMEFLAG);
		cout << "Start Time: " << startTime << endl;
		vector<bitset<288>> terms;
		int BB = BackExpandPolynomial(step, terms);
		if (BB != 0)
		{
			exit(0);
		}
		int ROUND = round;
		ROUND = ROUND - step;
		filterTerms(cube, ROUND, terms);
		logger(__func__ + string("First expand"));
		vector<KVpoly> pstate0, pstate1;
		// KVpoly spoly;
		// spoly.p.clear();
		vector<KVpoly> state1(288);
		vector<Kpoly> k_fun;

		trivium_simplify_poly(state1, k_fun, BASEROUND);//

		map<vector<int>, vector<int>> vk_table = trivium_flag_poly_2(cube, key, state1, pstate1);
		
		auto it = vk_table.begin();
		while (it != vk_table.end()) {
			vector<int> a = (*it).first;
			vector<int> b = (*it).second;
			for (auto b_num : b) {
				zero_s[b_num] = 1;
			}
			it++;
		}
		
		if (ROUND < CALLBACKBOUND)
			app_newExpandFunc(cube, terms, ROUND, expandStep, thread_pool, expandTime, singlethread, threshold, mode, indicator, zero_s,p_id);
		else {
			expandFunc(cube, terms, ROUND, expandTime, singlethread);
		}
		int a = terms.size();
		if (a == 0) {
			vector<int> return_vec;
			for (int i = 0; i < N; i++) {
				if (key[i] == 1) {
					return_vec.push_back(i);
					spolyfile << i << " ";
					bs << i << " ";
				}
			}
			spolyfile << endl;
			bs << endl;
			for (int i = 0; i < 288; i++) {
				if (zero_s[i] == 1) {
					spolyfile << i << " ";
				}
			}
			spolyfile << endl;
			return return_vec;
		}
		if (indicator) {
			KVpoly spoly;
			auto start_in = chrono::system_clock::now();
			// string startTime = getCurrentSystemTime(TIMEFLAG);
			// cout << "Start Time: " << startTime << endl;
			vector<int> kid;
			coef (FASTBOUND,filename,cube, terms,spoly,THREAD_NUM,kid);
			// cout <<spoly<<endl;
			KVpoly result;
			
			substitute_kvpoly(result, spoly, BASEROUND, FASTBOUND, key);
			spolyfile << result << endl;
			auto end = chrono::system_clock::now();
			string endTime = getCurrentSystemTime(TIMEFLAG);
			// cout << "End Time: " << endTime << endl;
			auto duration = chrono::duration_cast<chrono::seconds>(end - start).count();
			// cout << "Time Difference: " << duration << " seconds" << endl;
			spolyfile << "Time Difference: " << duration << " seconds" << endl;
			
			int basis_bound = 2;
			vector<int> sol = k_count(result,basis_bound);
			if (sol[0] != -1)
			{
				for (int i = 0; i < basis_bound; i++) {
					spolyfile << sol[i] << " ";
					key[sol[i]] = 1;
				}
				spolyfile << endl;
				count_times++;
				if (count_times >= 10) {
					vector<int> return_vec;
					for (int i = 0; i < N; i++) {
						if (key[i] == 1) {
							return_vec.push_back(i);
							spolyfile << i << " ";
							bs << i << " ";
						}
					}
					spolyfile << endl;
					bs << endl;
					return return_vec;
				}
			}
			else {
				vector<int> return_vec;
				for (int i = 0; i < N; i++) {
					if (key[i] == 1) {
						return_vec.push_back(i);
						spolyfile << i << " ";
						bs << i << " ";
					}
				}
				spolyfile << endl;
				bs << endl;
				return return_vec;
			}
		}
	}
}


// Calculate the anf of start rounds
void cal_states(int round,string filename) {
	vector<KVpoly> pstate0, pstate1;
	// KVpoly spoly;
	// spoly.p.clear();
	vector<KVpoly> state0(288), state1(288);
	vector<Kpoly> k_fun;
	// trivium_simplify_poly(state0, k_fun, 0);
	trivium_simplify_poly(state1, k_fun, round);
	ofstream ff(filename);
	int i=0;
	for (auto it : state1) {
		ff<<"s[" + to_string(i) + "] = " << it << endl;
		i++;
	}
}

// Given a cube, calculate the anf of start rounds with non-cube variables be zero.
void cal_cube_states(int round,string filename,vector<int> cubeid) {
	vector<KVpoly> pstate1;
	bitset<80> cube;
	for (auto it : cubeid)
	{
		cube[it] = 1;
	}
	cout << cube <<endl;
	vector<KVpoly> state0(288), state1(288);
	vector<Kpoly> k_fun;
	// trivium_simplify_poly(state0, k_fun, 0);
	trivium_simplify_poly(state1, k_fun, round);
	trivium_flag_poly(cube, state1, pstate1);

	ofstream ff(filename);
	int i = 0;
	for (auto it : pstate1) {
		ff<<"s[" + to_string(i) + "] = " << it << endl;
		i++;
	}
}

