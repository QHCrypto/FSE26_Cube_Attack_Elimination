#!/usr/bin/env python3
"""Check parallel evaluation against the independent Python evaluator and CUDA records."""
import csv
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parent.parent
BINARY = Path(sys.argv.pop(1) if len(sys.argv) > 1 else ROOT / 'balance_855').resolve()
sys.path.insert(0, str(ROOT / 'cuda_validation'))
import run as reference


class BalanceTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.directory = Path(self.temporary.name)
        self.polynomial = self.directory / 'polynomial.txt'

    def tearDown(self):
        self.temporary.cleanup()

    def run_tool(self, *args, ok=True):
        result = subprocess.run([str(BINARY), '--polynomial', str(self.polynomial),
                                 *map(str, args)], capture_output=True, text=True, timeout=60)
        self.assertEqual(result.returncode == 0, ok, result.stdout + result.stderr)
        fields = dict(line.split('=', 1) for line in result.stdout.splitlines() if '=' in line)
        return fields

    def read_rows(self, path):
        with path.open(newline='') as stream:
            return list(csv.DictReader(stream))

    def check_keys(self, rows):
        self.assertEqual(len({row['key'] for row in rows}), len(rows))
        for row in rows:
            key = bytes.fromhex(row['key'])
            self.assertEqual(len(key), 10)
            self.assertEqual(reference.condition_values(reference.key_bits(key)), [0]*6)
            self.assertIn(row['superpoly_value'], ['0', '1'])

    def check_predictions(self, rows):
        previous = reference.REFERENCE_POLYNOMIAL
        reference.REFERENCE_POLYNOMIAL = self.polynomial
        try:
            expected = reference.evaluate_references(bytes.fromhex(row['key']) for row in rows)
        finally:
            reference.REFERENCE_POLYNOMIAL = previous
        self.assertEqual([int(row['superpoly_value']) for row in rows],
                         [prediction['value'] for prediction in expected])

    def test_constant_polynomials_and_partial_batches(self):
        for count in [1, 63, 64, 65, 129]:
            for constant in [0, 1]:
                with self.subTest(count=count, constant=constant):
                    self.polynomial.write_text(f'1*({constant})\n')
                    fields = self.run_tool('--samples', count, '--seed', 855, '--threads', 4)
                    self.assertEqual(int(fields['one_count']), count*constant)
                    self.assertEqual(int(fields['zero_count']), count*(1-constant))

    def test_all_basis_rules_constants_repetitions_and_weak_keys(self):
        terms = [f'z{i}' for i in range(153)]
        terms += ['z80z137', 'z81z138', 'z82z152', 'z0z0', 'z17', 'z17', '1', '0']
        self.polynomial.write_text('metadata\n  1*(' + '+'.join(terms) + ')\nstatus: complete\n')
        path = self.directory / 'keys.csv'
        fields = self.run_tool('--samples', 257, '--seed', 12345, '--threads', 4, '--csv', path)
        rows = self.read_rows(path)
        self.check_keys(rows)
        self.check_predictions(rows)
        self.assertEqual(int(fields['one_count']), sum(int(row['superpoly_value']) for row in rows))

    def test_real_polynomial_and_thread_invariance(self):
        self.polynomial = ROOT / 'results/superpoly_z83.txt'
        paths = [self.directory / 'single.csv', self.directory / 'parallel.csv']
        for threads, path in zip([1, 4], paths):
            fields = self.run_tool('--samples', 129, '--seed', 855, '--threads', threads, '--csv', path)
            self.assertEqual(int(fields['source_terms']), 1233115)
        self.assertEqual(paths[0].read_bytes(), paths[1].read_bytes())
        rows = self.read_rows(paths[0])
        self.check_keys(rows)
        self.check_predictions(rows)

    def test_recorded_balance_sample(self):
        summary = json.loads((ROOT / 'results/balance_855_100000_seed855.json').read_text())
        self.polynomial = ROOT / summary['polynomial']
        recorded = ROOT / summary['csv']
        self.assertEqual(hashlib.sha256(self.polynomial.read_bytes()).hexdigest(),
                         summary['polynomial_sha256'])
        self.assertEqual(hashlib.sha256(recorded.read_bytes()).hexdigest(),
                         summary['csv_sha256'])
        rows = self.read_rows(recorded)
        self.check_keys(rows)
        self.assertEqual(len(rows), summary['samples'])
        self.assertEqual(sum(int(row['superpoly_value']) for row in rows),
                         summary['one_count'])
        self.assertEqual(summary['zero_count'] + summary['one_count'], summary['samples'])
        replay = self.directory / 'replayed.csv'
        fields = self.run_tool('--samples', summary['samples'], '--seed', summary['seed'],
                               '--threads', 4, '--csv', replay)
        self.assertEqual(replay.read_bytes(), recorded.read_bytes())
        self.assertEqual(int(fields['source_terms']), summary['source_terms'])
        self.assertEqual(int(fields['one_count']), summary['one_count'])
        self.assertAlmostEqual(float(fields['balance']), summary['one_fraction'])

    def test_matches_all_recorded_cuda_cube_sums(self):
        # The harness supplies the historical keys directly to the same evaluator.
        # Their independently computed full cube sums are the expected values.
        records = json.loads((ROOT / 'cuda_validation/recorded_results/summary.json').read_text())['keys']
        keys_path = self.directory / 'recorded_keys.txt'
        keys_path.write_text(''.join(row['key'] + '\n' for row in records))
        source = self.directory / 'recorded_check.cpp'
        source.write_text('#define main balance_cli_main\n#include ' +
                          json.dumps(str(ROOT / 'tools/balance_855.cpp')) + r'''
#undef main
int main(int argc, char** argv) {
    const auto polynomial = read_polynomial(argv[1]);
    std::ifstream input(argv[2]);
    std::vector<Key> keys;
    std::string text;
    while (input >> text) {
        Key key{0, 0};
        for (unsigned byte = 0; byte < 10; ++byte) {
            const unsigned value = std::stoul(text.substr(2 * byte, 2), nullptr, 16);
            for (unsigned bit = 0; bit < 8; ++bit) key.set(8 * byte + bit, (value >> bit) & 1U);
        }
        if (!is_weak(key)) return 2;
        keys.push_back(key);
    }
    const auto result = evaluate(polynomial, keys, 4);
    for (const auto value : result.values) std::cout << unsigned(value) << '\n';
}
''')
        harness = self.directory / 'recorded_check'
        subprocess.run(['g++', '-O2', '-std=c++17', '-fopenmp', str(source), '-o', str(harness)],
                       capture_output=True, text=True, check=True, timeout=60)
        result = subprocess.run([str(harness), str(ROOT / 'results/superpoly_z83.txt'), str(keys_path)],
                                capture_output=True, text=True, check=True, timeout=60)
        self.assertEqual([int(line) for line in result.stdout.splitlines()], [row['cube_sum'] for row in records])
        self.assertEqual(len(records), 50)

    def test_invalid_input_options_and_output_protection(self):
        for expression in ['', '1*()', '1*(k153)', '1*(k-1)', '1*(k)', '1*(k0+)',
                           '1*(k0++k1)', '1*(k0)\n1*(k1)', '1*(k999999999999999999999)']:
            with self.subTest(expression=expression):
                self.polynomial.write_text(expression)
                self.run_tool('--samples', 1, ok=False)
        self.polynomial.write_text('1*(k0)\n')
        for args in [('--threads', '0'), ('--samples', '0'), ('--seed', '-1'),
                     ('--seed', '18446744073709551616'), ('--threads',), ('--unknown',)]:
            with self.subTest(args=args):
                self.run_tool(*args, ok=False)
        output = self.directory / 'existing.csv'
        output.write_text('preserve this file')
        self.run_tool('--samples', 1, '--csv', output, ok=False)
        self.assertEqual(output.read_text(), 'preserve this file')


if __name__ == '__main__':
    unittest.main()
