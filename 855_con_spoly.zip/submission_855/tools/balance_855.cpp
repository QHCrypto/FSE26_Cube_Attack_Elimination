// Estimate the balance of a round-83 conditional superpoly on uniform weak keys.
// Build: g++ -O3 -std=c++17 -fopenmp tools/balance_855.cpp -o balance_855
#include <algorithm>
#include <array>
#include <charconv>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <random>
#include <stdexcept>
#include <string>
#include <string_view>
#include <unordered_set>
#include <vector>
#include <omp.h>

namespace fs = std::filesystem;

namespace {
constexpr unsigned BASIS_SIZE = 153;
constexpr std::array<unsigned, 6> CONDITIONS{61, 63, 100, 102, 124, 126};

struct Key {
    uint64_t low;
    uint16_t high;

    unsigned bit(unsigned i) const {
        return i < 64 ? (low >> i) & 1U : (high >> (i - 64)) & 1U;
    }
    void set(unsigned i, unsigned value) {
        if (i < 64) low = (low & ~(uint64_t{1} << i)) | (uint64_t{value} << i);
        else high = static_cast<uint16_t>((high & ~(1U << (i - 64))) | (value << (i - 64)));
    }
    bool operator==(const Key& other) const {
        return low == other.low && high == other.high;
    }
};

struct KeyHash {
    size_t operator()(const Key& key) const {
        uint64_t x = key.low ^ (uint64_t{key.high} * 0x9e3779b97f4a7c15ULL);
        x = (x ^ (x >> 30)) * 0xbf58476d1ce4e5b9ULL;
        x = (x ^ (x >> 27)) * 0x94d049bb133111ebULL;
        return static_cast<size_t>(x ^ (x >> 31));
    }
};

bool is_weak(const Key& k) {
    return !k.bit(61) && !k.bit(63)
        && !(k.bit(35) ^ (k.bit(60) & k.bit(61)) ^ k.bit(62))
        && !(k.bit(33) ^ (k.bit(58) & k.bit(59)) ^ k.bit(60))
        && !(k.bit(11) ^ (k.bit(36) & k.bit(37)) ^ k.bit(38))
        && !(k.bit(9) ^ (k.bit(34) & k.bit(35)) ^ k.bit(36));
}

std::vector<Key> sample_weak_keys(size_t count, uint64_t seed) {
    std::mt19937_64 random(seed);
    std::vector<Key> keys;
    keys.reserve(count);
    std::unordered_set<Key, KeyHash> seen;
    seen.reserve(count);
    while (keys.size() < count) {
        Key key{random(), static_cast<uint16_t>(random())};
        // Leave 74 independent bits uniform; complete the six dependent bits.
        key.set(61, 0);
        key.set(63, 0);
        key.set(62, key.bit(35));
        key.set(60, key.bit(33) ^ (key.bit(58) & key.bit(59)));
        key.set(11, (key.bit(36) & key.bit(37)) ^ key.bit(38));
        key.set(9, (key.bit(34) & key.bit(35)) ^ key.bit(36));
        if (!is_weak(key)) throw std::logic_error("weak-key generation failed");
        if (seen.insert(key).second) keys.push_back(key);
    }
    return keys;
}

struct Polynomial {
    std::vector<uint8_t> factors;
    std::vector<uint32_t> offsets{0};
    size_t terms() const { return offsets.size() - 1; }
};

std::string_view trim(std::string_view text) {
    const auto first = text.find_first_not_of(" \t\r\n");
    if (first == std::string_view::npos) return {};
    return text.substr(first, text.find_last_not_of(" \t\r\n") - first + 1);
}

Polynomial read_polynomial(const fs::path& path) {
    std::ifstream input(path);
    if (!input) throw std::runtime_error("cannot open polynomial: " + path.string());
    std::string line, expression;
    while (std::getline(input, line)) {
        const auto candidate = trim(line);
        if (candidate.substr(0, 3) != "1*(") continue;
        if (!expression.empty()) throw std::runtime_error("multiple polynomial expressions in input");
        expression.assign(candidate);
    }
    if (input.bad()) throw std::runtime_error("error reading polynomial");
    if (expression.size() < 5 || expression.back() != ')')
        throw std::runtime_error("expected one 1*(...) expression in round-83 variables k0..k152 or z0..z152");
    const std::string_view body(expression.data() + 3, expression.size() - 4);
    Polynomial polynomial;
    size_t position = 0;
    while (position < body.size()) {
        const auto end = body.find('+', position);
        const auto token = trim(body.substr(position, end == std::string_view::npos ? end : end - position));
        if (token.empty()) throw std::runtime_error("empty monomial");
        if (token != "0") {
            std::array<bool, BASIS_SIZE> seen{};
            if (token != "1") {
                size_t cursor = 0;
                while (cursor < token.size()) {
                    if (token[cursor] != 'k' && token[cursor] != 'z')
                        throw std::runtime_error("malformed monomial");
                    ++cursor;
                    unsigned index = 0;
                    const char* begin = token.data() + cursor;
                    const char* finish = token.data() + token.size();
                    const auto parsed = std::from_chars(begin, finish, index);
                    if (parsed.ec != std::errc{} || index >= BASIS_SIZE)
                        throw std::runtime_error("invalid variable; expected an index from 0 to 152");
                    cursor = static_cast<size_t>(parsed.ptr - token.data());
                    // Boolean powers are idempotent, including repeated factors.
                    if (!seen[index]) {
                        polynomial.factors.push_back(static_cast<uint8_t>(index));
                        seen[index] = true;
                    }
                }
            }
            if (polynomial.factors.size() > std::numeric_limits<uint32_t>::max())
                throw std::runtime_error("polynomial exceeds the supported factor-buffer size");
            polynomial.offsets.push_back(static_cast<uint32_t>(polynomial.factors.size()));
        }
        if (end == std::string_view::npos) break;
        position = end + 1;
        if (position == body.size()) throw std::runtime_error("trailing '+' in polynomial");
    }
    return polynomial;
}

using Planes = std::array<uint64_t, BASIS_SIZE>;

Planes basis_planes(const std::vector<Key>& keys, size_t first, size_t length) {
    Planes z{};
    for (size_t lane = 0; lane < length; ++lane)
        for (unsigned i = 0; i < 80; ++i)
            z[i] |= uint64_t{keys[first + lane].bit(i)} << lane;
    const uint64_t active = length == 64 ? ~uint64_t{0} : (uint64_t{1} << length) - 1;
    z[80] = z[67] ^ active;
    z[81] = z[66] ^ active;
    z[82] = z[53] ^ (z[78] & z[79]);
    for (unsigned i = 83; i < 136; ++i)
        z[i] = z[135 - i] ^ (z[160 - i] & z[161 - i]) ^ z[162 - i];
    for (unsigned i = 136; i < BASIS_SIZE; ++i) {
        z[i] = (z[160 - i] & z[161 - i]) ^ z[162 - i];
        if (i == 137 || i == 138) z[i] ^= z[i - 57];
        else {
            z[i] ^= z[204 - i];
            if (i >= 148) z[i] ^= z[213 - i];
        }
    }
    return z;
}

struct Evaluation {
    std::vector<uint8_t> values;
    uint64_t ones = 0;
    int threads = 0;
};

Evaluation evaluate(const Polynomial& polynomial, const std::vector<Key>& keys, int requested_threads) {
    if (keys.empty() || requested_threads < 1) throw std::invalid_argument("keys and threads must be positive");
    const size_t batches = keys.size() / 64 + (keys.size() % 64 != 0);
    const int threads = static_cast<int>(std::min<size_t>(requested_threads, batches));
    Evaluation result{std::vector<uint8_t>(keys.size()), 0, 0};
    uint64_t ones = 0;
    int invalid_conditions = 0;
    omp_set_dynamic(0);
    #pragma omp parallel num_threads(threads) reduction(+:ones) reduction(|:invalid_conditions)
    {
        #pragma omp single
        result.threads = omp_get_num_threads();
        #pragma omp for schedule(static)
        for (size_t batch = 0; batch < batches; ++batch) {
            const size_t first = batch * 64;
            const size_t length = std::min<size_t>(64, keys.size() - first);
            const uint64_t active = length == 64 ? ~uint64_t{0} : (uint64_t{1} << length) - 1;
            const Planes z = basis_planes(keys, first, length);
            for (const unsigned i : CONDITIONS) invalid_conditions |= z[i] != 0;
            uint64_t parity = 0;
            for (size_t term = 0; term < polynomial.terms(); ++term) {
                uint64_t product = active;
                const uint32_t end = polynomial.offsets[term + 1];
                for (uint32_t j = polynomial.offsets[term]; j < end && product; ++j)
                    product &= z[polynomial.factors[j]];
                parity ^= product;
            }
            ones += static_cast<unsigned>(__builtin_popcountll(parity));
            for (size_t lane = 0; lane < length; ++lane)
                result.values[first + lane] = static_cast<uint8_t>((parity >> lane) & 1U);
        }
    }
    if (invalid_conditions) throw std::runtime_error("a sampled key violates the six round-83 conditions");
    result.ones = ones;
    return result;
}

uint64_t parse_unsigned(std::string_view value, const char* option) {
    uint64_t number = 0;
    const auto parsed = std::from_chars(value.data(), value.data() + value.size(), number);
    if (parsed.ec != std::errc{} || parsed.ptr != value.data() + value.size())
        throw std::invalid_argument(std::string(option) + " requires an unsigned decimal integer");
    return number;
}

void write_csv(const fs::path& path, const std::vector<Key>& keys, const Evaluation& result) {
    if (fs::exists(path)) throw std::runtime_error("CSV output already exists: " + path.string());
    std::ofstream output(path);
    if (!output) throw std::runtime_error("cannot create CSV output: " + path.string());
    output << "key,superpoly_value\n";
    for (size_t i = 0; i < keys.size(); ++i) {
        output << std::hex << std::setfill('0');
        for (unsigned byte = 0; byte < 10; ++byte) {
            const unsigned value = byte < 8 ? (keys[i].low >> (byte * 8)) & 255U
                                          : (keys[i].high >> ((byte - 8) * 8)) & 255U;
            output << std::setw(2) << value;
        }
        output << ',' << std::dec << unsigned(result.values[i]) << '\n';
    }
    output.close();
    if (!output) throw std::runtime_error("error writing CSV output: " + path.string());
}
} // namespace

int main(int argc, char** argv) {
    try {
        fs::path polynomial_path, csv_path;
        uint64_t samples = 100000, seed = 0;
        bool fixed_seed = false;
        int threads = omp_get_max_threads();
        for (int i = 1; i < argc; ++i) {
            const std::string option = argv[i];
            if (option == "--help") {
                std::cout << "Usage: " << argv[0]
                          << " [--polynomial FILE] [--samples N] [--threads N] [--seed N] [--csv FILE]\n"
                          << "Default: 100000 distinct uniform weak keys, all available OpenMP threads,\n"
                          << "and results/superpoly_z83.txt beside this executable.\n"
                          << "Input variables k0..k152 or z0..z152 denote the round-83 basis.\n"
                          << "The seed is always printed; a fixed seed reproduces keys across thread counts.\n"
                          << "--csv optionally saves every 10-byte key (hex) and polynomial value.\n";
                return 0;
            }
            if (option != "--polynomial" && option != "--samples" && option != "--threads"
                && option != "--seed" && option != "--csv")
                throw std::invalid_argument("unknown option: " + option);
            if (++i == argc) throw std::invalid_argument("missing value for " + option);
            const std::string_view value = argv[i];
            if (option == "--polynomial") polynomial_path = value;
            else if (option == "--csv") csv_path = value;
            else {
                const uint64_t number = parse_unsigned(value, option.c_str());
                if (option == "--seed") { seed = number; fixed_seed = true; }
                else if (option == "--samples") {
                    if (!number || number > std::vector<Key>{}.max_size())
                        throw std::invalid_argument("--samples must be a positive supported count");
                    samples = number;
                } else {
                    if (!number || number > static_cast<uint64_t>(omp_get_thread_limit()))
                        throw std::invalid_argument("--threads must be a positive supported count");
                    threads = static_cast<int>(number);
                }
            }
        }
        if (polynomial_path.empty()) {
            std::error_code error;
            const fs::path executable = fs::read_symlink("/proc/self/exe", error);
            const fs::path directory = error ? fs::absolute(argv[0]).parent_path() : executable.parent_path();
            polynomial_path = directory / "results/superpoly_z83.txt";
        }
        if (!csv_path.empty() && fs::exists(csv_path))
            throw std::runtime_error("CSV output already exists: " + csv_path.string());
        if (!fixed_seed) {
            std::random_device entropy;
            seed = (uint64_t{entropy()} << 32) ^ entropy();
        }
        const auto started = std::chrono::steady_clock::now();
        std::cout << "polynomial=" << fs::absolute(polynomial_path).lexically_normal().string() << '\n'
                  << "samples=" << samples << " seed=" << seed << std::endl;
        const Polynomial polynomial = read_polynomial(polynomial_path);
        std::cout << "source_terms=" << polynomial.terms() << std::endl;
        const auto keys = sample_weak_keys(static_cast<size_t>(samples), seed);
        const auto result = evaluate(polynomial, keys, threads);
        if (!csv_path.empty()) write_csv(csv_path, keys, result);
        const double balance = static_cast<double>(result.ones) / samples;
        const double elapsed = std::chrono::duration<double>(std::chrono::steady_clock::now() - started).count();
        std::cout << "threads=" << result.threads << '\n'
                  << "zero_count=" << samples - result.ones << '\n'
                  << "one_count=" << result.ones << '\n'
                  << std::fixed << std::setprecision(8)
                  << "balance=" << balance << '\n'
                  << "absolute_bias=" << std::abs(balance - 0.5) << '\n'
                  << std::setprecision(3) << "elapsed_seconds=" << elapsed << '\n';
        if (!csv_path.empty()) std::cout << "csv=" << fs::absolute(csv_path).lexically_normal().string() << '\n';
        return 0;
    } catch (const std::exception& error) {
        std::cerr << "ERROR: " << error.what() << '\n';
        return 1;
    }
}
