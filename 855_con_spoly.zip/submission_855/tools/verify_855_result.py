#!/usr/bin/env python3
"""Compare a recovered z^83 polynomial with the bundled I4 result (stdlib only)."""
import argparse
import hashlib
import json
from pathlib import Path
import re


def inspect_polynomial(path):
    expression = None
    with Path(path).open('rb') as stream:
        for line in stream:
            if line.startswith(b'1*('):
                if expression is not None:
                    raise ValueError('multiple polynomial expressions in input')
                expression = line.rstrip(b'\r\n')
    if expression is None or not expression.endswith(b')'):
        raise ValueError('expected one 1*(...) expression')
    parity = set()
    source_terms = expanded_terms = 0
    for term in expression[3:-1].split(b'+'):
        if term == b'0':
            continue
        mask, branches = 0, 1
        if term != b'1':
            if re.fullmatch(rb'(?:[kz][0-9]+)+', term) is None:
                raise ValueError('malformed monomial')
            for digits in re.findall(rb'[kz]([0-9]+)', term):
                index = int(digits)
                if index > 152:
                    raise ValueError('expected z^83 variables with indices 0..152')
                mask |= 1 << index
                branches *= (1 if index < 80 else 2 if index <= 82
                             else 4 if index in (137, 138) or index >= 148 else 3)
        source_terms += 1
        expanded_terms += branches
        if mask in parity:
            parity.remove(mask)
        else:
            parity.add(mask)
    # Fixed-width little-endian masks, in numeric order, make the comparison
    # independent of term order, factor order, and the k/z spelling.
    canonical = hashlib.sha256()
    for mask in sorted(parity):
        canonical.update(mask.to_bytes(20, 'little'))
    return {
        'source_terms': source_terms,
        'gf2_terms': len(parity),
        'expanded_terms': expanded_terms,
        'polynomial_line_sha256': hashlib.sha256(expression + b'\n').hexdigest(),
        'canonical_gf2_sha256': canonical.hexdigest(),
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('input', type=Path)
    parser.add_argument('--reference', type=Path,
                        default=Path(__file__).resolve().parent.parent / 'results/superpoly_z83.txt',
                        help='Reference polynomial; defaults to the bundled I4 result')
    args = parser.parse_args()
    try:
        actual = inspect_polynomial(args.input)
        reference = inspect_polynomial(args.reference)
        print(json.dumps(actual, indent=2))
        keys = ('gf2_terms', 'canonical_gf2_sha256', 'source_terms', 'expanded_terms')
        mismatches = [key for key in keys if actual[key] != reference[key]]
        if mismatches:
            print('MISMATCH: ' + ', '.join(mismatches))
            return 1
        print('MATCH: recovered polynomial and unmerged count agree with the reference polynomial.')
        return 0
    except (OSError, ValueError, KeyError) as error:
        parser.exit(1, f'Error: {error}\n')


if __name__ == '__main__':
    raise SystemExit(main())
