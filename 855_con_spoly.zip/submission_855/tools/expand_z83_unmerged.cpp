// Expand a z^83 superpoly into physical k0..k79 bits without cancelling
// repeated GF(2) monomials. Always report the exact expansion count; optionally
// write independent source terms in parallel to disjoint ranges of one file.
#include <algorithm>
#include <array>
#include <atomic>
#include <cerrno>
#include <chrono>
#include <csignal>
#include <cstdint>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <limits>
#include <stdexcept>
#include <string>
#include <string_view>
#include <thread>
#include <vector>
#include <fcntl.h>
#include <unistd.h>

namespace fs = std::filesystem;
using Mask = unsigned __int128;
constexpr size_t BASIS_SIZE = 153;
constexpr size_t KEY_BITS = 80;
volatile std::sig_atomic_t interrupted = 0;

struct BasisEntry {
    std::array<Mask, 5> alternatives{};
    uint8_t count = 0;
};
using Basis = std::array<BasisEntry, BASIS_SIZE>;

Mask bit(int index) {
    if (index < 0 || index >= static_cast<int>(KEY_BITS))
        throw std::runtime_error("invalid physical key index");
    return Mask{1} << index;
}

void add(BasisEntry& entry, Mask monomial) {
    if (entry.count == entry.alternatives.size())
        throw std::runtime_error("too many basis alternatives");
    entry.alternatives[entry.count++] = monomial;
}

Basis make_basis() {
    Basis basis;
    for (int i = 0; i < 80; ++i) add(basis[i], bit(i));
    add(basis[80], bit(67)); add(basis[80], 0);
    add(basis[81], bit(66)); add(basis[81], 0);
    add(basis[82], bit(53)); add(basis[82], bit(78) | bit(79));
    for (int i = 83; i < 136; ++i) {
        add(basis[i], bit(135 - i));
        add(basis[i], bit(160 - i) | bit(161 - i));
        add(basis[i], bit(162 - i));
    }
    for (int i = 136; i < 153; ++i) {
        add(basis[i], bit(160 - i) | bit(161 - i));
        add(basis[i], bit(162 - i));
        if (i == 137 || i == 138) {
            // z137 includes z80=k67+1; z138 includes z81=k66+1.
            add(basis[i], bit(i == 137 ? 67 : 66));
            add(basis[i], 0);
        } else {
            add(basis[i], bit(204 - i));
            if (i >= 148) add(basis[i], bit(213 - i));
        }
    }
    return basis;
}

struct SourceTerm {
    size_t factor_offset = 0;
    size_t factor_count = 0;
    Mask fixed = 0;
    uint64_t expanded_terms = 0;
    uint64_t output_bytes = 0;  // Includes one '+' after every expanded term.
};

uint64_t checked_u64(unsigned __int128 value, const char* description) {
    if (value > std::numeric_limits<uint64_t>::max())
        throw std::runtime_error(std::string(description) + " exceeds uint64_t");
    return static_cast<uint64_t>(value);
}

unsigned next_bit(Mask& bits) {
    const uint64_t low = static_cast<uint64_t>(bits);
    const unsigned index = low ? __builtin_ctzll(low)
                               : 64 + __builtin_ctzll(static_cast<uint64_t>(bits >> 64));
    bits &= bits - 1;
    return index;
}

void measure(SourceTerm& term, const std::vector<uint8_t>& factors, const Basis& basis) {
    unsigned __int128 count = 1;
    Mask used = term.fixed;
    for (size_t j = 0; j < term.factor_count; ++j) {
        const BasisEntry& entry = basis[factors[term.factor_offset + j]];
        count *= entry.count;
        checked_u64(count, "per-term expansion count");
        for (size_t a = 0; a < entry.count; ++a) used |= entry.alternatives[a];
    }
    term.expanded_terms = checked_u64(count, "per-term expansion count");
    unsigned __int128 bytes = count;  // The '+' delimiter for each output term.
    Mask pending = used;
    while (pending) {
        const unsigned index = next_bit(pending);
        const Mask target = bit(index);
        unsigned __int128 absent = (term.fixed & target) ? 0 : 1;
        if (absent) {
            for (size_t j = 0; j < term.factor_count; ++j) {
                const BasisEntry& entry = basis[factors[term.factor_offset + j]];
                unsigned alternatives_without_bit = 0;
                for (size_t a = 0; a < entry.count; ++a)
                    alternatives_without_bit += !(entry.alternatives[a] & target);
                absent *= alternatives_without_bit;
            }
        }
        bytes += (count - absent) * (index < 10 ? 2 : 3);  // "k0" or "k10".
    }
    // A product of constant branches is printed as "1".
    if (!term.fixed) {
        unsigned __int128 constant_count = 1;
        for (size_t j = 0; j < term.factor_count; ++j) {
            const BasisEntry& entry = basis[factors[term.factor_offset + j]];
            unsigned empty = 0;
            for (size_t a = 0; a < entry.count; ++a)
                empty += entry.alternatives[a] == 0;
            constant_count *= empty;
        }
        bytes += constant_count;
    }
    term.output_bytes = checked_u64(bytes, "per-term output size");
}

struct ParsedInput {
    std::vector<SourceTerm> terms;
    std::vector<uint8_t> factors;
    std::vector<uint64_t> prefix_bytes{0};
    uint64_t source_terms = 0;
    uint64_t expanded_terms = 0;
};

ParsedInput parse_input(const fs::path& path, const Basis& basis) {
    std::ifstream input(path);
    if (!input) throw std::runtime_error("cannot open input: " + path.string());
    // Both historical files and journal-driver output are accepted, including
    // metadata before the polynomial. Refuse ambiguous multi-snapshot inputs.
    std::string expression, line;
    while (std::getline(input, line)) {
        if (!line.empty() && line.back() == '\r') line.pop_back();
        if (line.compare(0, 3, "1*(") != 0) continue;
        if (!expression.empty())
            throw std::runtime_error("input contains multiple polynomial expressions");
        expression = std::move(line);
    }
    if (input.bad()) throw std::runtime_error("error reading input: " + path.string());
    if (expression.size() < 5 || expression.compare(0, 3, "1*(") != 0
        || expression.back() != ')')
        throw std::runtime_error("expected one line in 1*(k...+k...) format (z indices also accepted)");
    const std::string_view body(expression.data() + 3, expression.size() - 4);
    ParsedInput parsed;
    size_t position = 0;
    while (position < body.size()) {
        const size_t end = body.find('+', position);
        const std::string_view token = body.substr(position, end == std::string_view::npos
                                                 ? end : end - position);
        if (token.empty()) throw std::runtime_error("empty source monomial");
        SourceTerm term;
        term.factor_offset = parsed.factors.size();
        if (token == "0") {
            // The zero polynomial contributes no expanded terms.
        } else if (token == "1") {
            measure(term, parsed.factors, basis);
        } else {
            size_t cursor = 0;
            while (cursor < token.size()) {
                if ((token[cursor] != 'k' && token[cursor] != 'z') || ++cursor == token.size()
                    || token[cursor] < '0' || token[cursor] > '9')
                    throw std::runtime_error("malformed source monomial");
                unsigned index = 0;
                do {
                    index = index * 10 + static_cast<unsigned>(token[cursor] - '0');
                    if (index >= BASIS_SIZE)
                        throw std::runtime_error("source variable exceeds z152");
                    ++cursor;
                } while (cursor < token.size() && token[cursor] >= '0'
                         && token[cursor] <= '9');
                if (basis[index].count == 1) {
                    term.fixed |= basis[index].alternatives[0];
                } else {
                    parsed.factors.push_back(index);
                    ++term.factor_count;
                }
            }
            measure(term, parsed.factors, basis);
        }
        parsed.terms.push_back(term);
        ++parsed.source_terms;
        parsed.expanded_terms = checked_u64(
            static_cast<unsigned __int128>(parsed.expanded_terms) + term.expanded_terms,
            "total expansion count");
        parsed.prefix_bytes.push_back(checked_u64(
            static_cast<unsigned __int128>(parsed.prefix_bytes.back()) + term.output_bytes,
            "total output size"));
        if (end == std::string_view::npos) break;
        position = end + 1;
        if (position == body.size()) throw std::runtime_error("trailing '+' in input");
    }
    if (parsed.source_terms == 0) throw std::runtime_error("no source terms");
    return parsed;
}

void write_all_at(int fd, const char* data, size_t length, uint64_t offset) {
    while (length) {
        const ssize_t written = ::pwrite(fd, data, length, static_cast<off_t>(offset));
        if (written < 0 && errno == EINTR) continue;
        if (written <= 0) throw std::runtime_error(std::string("pwrite failed: ") + std::strerror(errno));
        data += written;
        length -= static_cast<size_t>(written);
        offset += static_cast<size_t>(written);
    }
}

class BufferedWriter {
    int fd_;
    uint64_t next_offset_;
    std::atomic<uint64_t>& progress_;
    std::vector<char> buffer_;
    size_t filled_ = 0;
public:
    BufferedWriter(int fd, uint64_t offset, std::atomic<uint64_t>& progress)
        : fd_(fd), next_offset_(offset), progress_(progress), buffer_(4 * 1024 * 1024) {}

    void flush() {
        if (!filled_) return;
        write_all_at(fd_, buffer_.data(), filled_, next_offset_);
        next_offset_ += filled_;
        progress_.fetch_add(filled_, std::memory_order_relaxed);
        filled_ = 0;
    }

    void emit(Mask monomial) {
        char term[KEY_BITS * 3 + 1];
        char* cursor = term;
        Mask pending = monomial;
        while (pending) {
            const unsigned index = next_bit(pending);
            *cursor++ = 'k';
            if (index >= 10) *cursor++ = static_cast<char>('0' + index / 10);
            *cursor++ = static_cast<char>('0' + index % 10);
        }
        if (cursor == term) *cursor++ = '1';
        *cursor++ = '+';
        const size_t length = static_cast<size_t>(cursor - term);
        if (filled_ + length > buffer_.size()) flush();
        std::memcpy(buffer_.data() + filled_, term, length);
        filled_ += length;
    }

    uint64_t position() const { return next_offset_ + filled_; }
};

void expand_one(const SourceTerm& term, const std::vector<uint8_t>& factors,
                const Basis& basis, size_t depth, Mask value, BufferedWriter& output) {
    if (depth == term.factor_count) {
        output.emit(value);
        return;
    }
    const BasisEntry& entry = basis[factors[term.factor_offset + depth]];
    for (size_t i = 0; i < entry.count; ++i)
        expand_one(term, factors, basis, depth + 1, value | entry.alternatives[i], output);
}

void on_interrupt(int) { interrupted = 1; }

int main(int argc, char** argv) {
    try {
        const auto usage = [&] {
            std::cout << "Usage: " << argv[0]
                      << " INPUT [OUTPUT] [--threads N] [--count-only|--estimate-only]\n"
                      << "Without OUTPUT, only the exact unmerged term count and file size are printed.\n"
                      << "With OUTPUT, the polynomial is also written; --count-only suppresses writing.\n";
        };
        if (argc == 2 && std::string_view(argv[1]) == "--help") {
            usage();
            return 0;
        }
        if (argc < 2) {
            usage();
            return 2;
        }
        const fs::path input_path = argv[1];
        fs::path output_path;
        unsigned threads = std::max(1u, std::thread::hardware_concurrency());
        bool count_only = false;
        for (int i = 2; i < argc; ++i) {
            const std::string_view arg(argv[i]);
            if (arg == "--count-only" || arg == "--estimate-only") count_only = true;
            else if (arg == "--threads" && i + 1 < argc) {
                const std::string value(argv[++i]);
                if (value.empty() || value.find_first_not_of("0123456789") != std::string::npos)
                    throw std::runtime_error("threads must be a positive integer");
                const unsigned long parsed = std::stoul(value);
                if (parsed == 0 || parsed > 256)
                    throw std::runtime_error("threads must be between 1 and 256");
                threads = static_cast<unsigned>(parsed);
            } else if (!arg.empty() && arg.front() != '-' && output_path.empty()) {
                output_path = argv[i];
            } else throw std::runtime_error("unknown or incomplete option: " + std::string(arg));
        }
        const Basis basis = make_basis();
        const auto started = std::chrono::steady_clock::now();
        const ParsedInput parsed = parse_input(input_path, basis);
        const uint64_t body_bytes = parsed.prefix_bytes.back();
        const uint64_t file_bytes = parsed.expanded_terms
            ? checked_u64(static_cast<unsigned __int128>(body_bytes) + 4, "total file size") : 6;
        std::cout << "source_terms=" << parsed.source_terms
                  << " expanded_terms=" << parsed.expanded_terms
                  << " output_bytes=" << file_bytes << " ("
                  << file_bytes / 1e9 << " GB)" << std::endl;
        if (count_only || output_path.empty()) return 0;
        if (fs::absolute(input_path).lexically_normal() == fs::absolute(output_path).lexically_normal())
            throw std::runtime_error("input and output paths must differ");
        if (fs::exists(output_path))
            throw std::runtime_error("output already exists: " + output_path.string());
        const fs::path output_dir = output_path.has_parent_path() ? output_path.parent_path() : fs::path(".");
        if (!fs::exists(output_dir))
            throw std::runtime_error("output directory does not exist: " + output_dir.string());
        if (fs::space(output_dir).available < file_bytes)
            throw std::runtime_error("insufficient free space for expanded output");
        if (file_bytes > static_cast<uint64_t>(std::numeric_limits<off_t>::max()))
            throw std::runtime_error("expanded output exceeds off_t range");
        const fs::path temp_path = output_path.string() + ".tmp." + std::to_string(::getpid());
        const int fd = ::open(temp_path.c_str(), O_CREAT | O_EXCL | O_WRONLY, 0644);
        if (fd < 0) throw std::runtime_error("cannot create temporary output: " + temp_path.string());
        try {
            if (::ftruncate(fd, static_cast<off_t>(file_bytes)) != 0)
                throw std::runtime_error("ftruncate failed");
            if (!parsed.expanded_terms) {
                write_all_at(fd, "1*(0)\n", 6, 0);
            } else {
                write_all_at(fd, "1*(", 3, 0);
                threads = std::min<unsigned>(threads, parsed.terms.size());
                std::vector<size_t> cuts(threads + 1);
                cuts.front() = 0;
                cuts.back() = parsed.terms.size();
                for (unsigned i = 1; i < threads; ++i) {
                    const uint64_t target = static_cast<uint64_t>(
                        static_cast<unsigned __int128>(body_bytes) * i / threads);
                    cuts[i] = std::lower_bound(parsed.prefix_bytes.begin(), parsed.prefix_bytes.end(), target)
                              - parsed.prefix_bytes.begin();
                }
                std::atomic<uint64_t> written{0};
                std::atomic<unsigned> finished{0};
                std::atomic<bool> failed{false};
                std::vector<std::thread> workers;
                std::vector<std::exception_ptr> errors(threads);
                std::signal(SIGINT, on_interrupt);
                std::signal(SIGTERM, on_interrupt);
                try {
                    for (unsigned t = 0; t < threads; ++t) {
                        workers.emplace_back([&, t] {
                            try {
                                BufferedWriter out(fd, 3 + parsed.prefix_bytes[cuts[t]], written);
                                for (size_t i = cuts[t]; i < cuts[t + 1]; ++i) {
                                    if (interrupted || failed.load(std::memory_order_relaxed))
                                        throw std::runtime_error("expansion interrupted");
                                    const SourceTerm& term = parsed.terms[i];
                                    if (term.expanded_terms)
                                        expand_one(term, parsed.factors, basis, 0, term.fixed, out);
                                }
                                if (out.position() != 3 + parsed.prefix_bytes[cuts[t + 1]])
                                    throw std::runtime_error("output size disagrees with exact preflight estimate");
                                out.flush();
                            } catch (...) {
                                errors[t] = std::current_exception();
                                failed.store(true, std::memory_order_relaxed);
                            }
                            finished.fetch_add(1, std::memory_order_release);
                        });
                    }
                } catch (...) {
                    failed.store(true, std::memory_order_relaxed);
                    for (auto& worker : workers) worker.join();
                    throw;
                }
                uint64_t last_written = 0;
                auto last_report = std::chrono::steady_clock::now();
                while (finished.load(std::memory_order_acquire) != threads) {
                    std::this_thread::sleep_for(std::chrono::seconds(1));
                    const auto now = std::chrono::steady_clock::now();
                    const double seconds = std::chrono::duration<double>(now - last_report).count();
                    if (seconds >= 30) {
                        const uint64_t current = written.load(std::memory_order_relaxed);
                        std::cerr << "expanded " << current << "/" << body_bytes
                                  << " bytes (" << 100.0 * current / body_bytes << "%), "
                                  << (current - last_written) / seconds / 1e6 << " MB/s\n";
                        last_written = current;
                        last_report = now;
                    }
                }
                for (auto& worker : workers) worker.join();
                for (const auto& error : errors) if (error) std::rethrow_exception(error);
                if (written.load() != body_bytes)
                    throw std::runtime_error("not all output bytes were written");
                write_all_at(fd, ")\n", 2, 3 + body_bytes - 1);
            }
            if (interrupted) throw std::runtime_error("expansion interrupted");
            if (::fsync(fd) != 0) throw std::runtime_error("fsync failed");
            if (::close(fd) != 0) throw std::runtime_error("close failed");
            fs::rename(temp_path, output_path);
        } catch (...) {
            ::close(fd);
            fs::remove(temp_path);
            throw;
        }
        const double elapsed = std::chrono::duration<double>(
            std::chrono::steady_clock::now() - started).count();
        std::cout << "saved=" << output_path << " elapsed_seconds=" << elapsed << '\n';
        return 0;
    } catch (const std::exception& error) {
        std::cerr << "Error: " << error.what() << '\n';
        return 1;
    }
}
