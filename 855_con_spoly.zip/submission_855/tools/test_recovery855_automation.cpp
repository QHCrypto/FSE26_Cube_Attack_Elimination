// Exercise the production recovery/journal loop with deterministic solver
// substitutes. No Gurobi environment or license is created by these tests.
#include "../recovery855.cpp"
#include <cstdlib>

namespace {
struct SolverFixture {
    std::mutex mutex;
    unsigned coefficient_calls = 0, callback_calls = 0, unlimited_expansions = 0;
    unsigned special_attempts = 0, transient_failures = 0;
    unsigned other_attempts = 0, other_failures = 0;
    bool persistent_failure = false, expansion_timeout = false;
    bool interrupt_retry = false, fail_seed_once = false;
    bool strict_seen = false, defer_coefficient_once = false;
} fixture;

void require(bool condition, const std::string& message) {
    if(!condition) throw std::runtime_error("test failed: " + message);
}
unsigned variable(const Term& term) {
    for(unsigned i=0;i<288;++i) if(term[i]) return i;
    return 0;
}
void reset_fixture() {
    fixture.coefficient_calls=fixture.callback_calls=fixture.unlimited_expansions=0;
    fixture.special_attempts=fixture.transient_failures=0;
    fixture.other_attempts=fixture.other_failures=0;
    fixture.persistent_failure=fixture.expansion_timeout=fixture.interrupt_retry=false;
    fixture.fail_seed_once=fixture.strict_seen=false;
    fixture.defer_coefficient_once=false;
}
std::string read_file(const fs::path& path) {
    std::ifstream in(path);
    require(bool(in),"missing " + path.string());
    return std::string(std::istreambuf_iterator<char>(in),{});
}
Kpoly expected_polynomial() {
    Kpoly polynomial;
    for(int index:{65,92,161,176,242,287}) {
        Kmono mono; mono.k[index%80]=1; polynomial.p.insert(mono);
    }
    return polynomial;
}
void require_complete(const fs::path& directory) {
    Journal journal(directory.string()); State state; journal.load(state);
    require(state.finished && state.failed.empty() && state.retry.empty(),"unfinished tasks marked complete");
    require(state.output_status=="complete","missing complete status");
    Kpoly difference=state.polynomial+expected_polynomial();
    require(difference.p.empty(),"missing or duplicated polynomial contribution");
    std::ostringstream expression; auto expected=expected_polynomial();
    expression << "1*(" << expected << ")\n";
    require(read_file(directory/"superpoly.txt").find(expression.str())==0,"wrong final polynomial");
    require(read_file(directory/"pending_failed.jsonl").empty(),"stale pending failures");
}
RecoveryOptions options_for(const fs::path& directory) {
    RecoveryOptions options; options.directory=directory.string();
    options.threads=4; options.batch_size=2; return options;
}
}

// These substitutes model solver outcomes, not the mathematical Trivium model.
void trivium_simplify_poly(std::vector<KVpoly>& state, std::vector<Kpoly>& definitions, int) {
    state.assign(288,KVpoly{}); definitions.clear();
}
std::map<std::vector<int>,std::vector<int>> trivium_flag_poly_2(
    std::bitset<80>, std::bitset<N>, std::vector<KVpoly>& state, std::vector<KVpoly>& filtered) {
    filtered=state; return {};
}
void trivium_flag_poly_1(std::bitset<80>, std::bitset<N>,
                         std::vector<KVpoly>& state, std::vector<KVpoly>& filtered) {
    filtered=state;
}
void filterTerms(const std::bitset<80>&, int, std::vector<std::bitset<288>>&) {}
void substitute_kvpoly(KVpoly& result, const KVpoly& original, int, int, const std::bitset<N>&) {
    result=original;
}
int N0_round_model(std::vector<KVpoly>, std::bitset<80>, int threads,
                   std::bitset<288> term, KVpoly& polynomial, bool time_limited) {
    std::lock_guard<std::mutex> guard(fixture.mutex);
    ++fixture.coefficient_calls;
    require(threads==1,"coefficient model thread count changed");
    if(!time_limited) {
        require(omp_get_num_threads()==1,"retries were not serial");
        fixture.strict_seen=true;
        if(fixture.interrupt_retry && variable(term)==65) {
            fixture.interrupt_retry=false;
            throw RecoveryInterrupted(GRB_INTERRUPTED);
        }
    }
    if(fixture.persistent_failure) throw RecoveryError("injected persistent license failure",10009);
    if(variable(term)==65 && ++fixture.special_attempts<=fixture.transient_failures) {
        // An invalid partial contribution must never leak into the result.
        Vmono constant; Kmono invalid; invalid.k[79]=1;
        polynomial.p[constant].p.insert(invalid);
        throw RecoveryError("injected transient failure",10009);
    }
    if(variable(term)==92 && ++fixture.other_attempts<=fixture.other_failures)
        throw RecoveryError("injected second transient failure",10009);
    if(time_limited && variable(term)==161 && fixture.defer_coefficient_once) {
        fixture.defer_coefficient_once=false;
        return -1;
    }
    Vmono constant; Kmono mono; mono.k[variable(term)%80]=1;
    polynomial.p[constant].p.insert(mono); return 1;
}
int SecondBackExpandPolynomial(int rounds, const std::bitset<288>& term,
                               std::vector<std::bitset<288>>& output, int threads, double seconds) {
    std::lock_guard<std::mutex> guard(fixture.mutex);
    if(rounds==300 && variable(term)==242 && fixture.fail_seed_once) {
        fixture.fail_seed_once=false;
        throw RecoveryError("injected seed failure",10009);
    }
    if(seconds>0 && rounds==30 && variable(term)==92 && fixture.expansion_timeout) return -1;
    if(threads==1) {
        require(seconds==0,"exact expansion retry still has a time limit");
        require(omp_get_num_threads()==1,"expansion retries were not serial");
        ++fixture.unlimited_expansions; fixture.strict_seen=true;
    }
    output.push_back(term); return 0;
}
STATUS uMidSolutionCallBack(int round, std::bitset<80>&, const std::bitset<288>& term,
                            std::vector<std::bitset<288>>& output, float, int, int, int, std::bitset<288>) {
    std::lock_guard<std::mutex> guard(fixture.mutex);
    require(!fixture.strict_seen,"bounded callback was used during an exact retry");
    ++fixture.callback_calls;
    if(round==555 && variable(term)==92 && fixture.expansion_timeout) return EXPAND;
    output.push_back(term); return SOLUTION;
}

int main() {
    try {
        char temporary[]="/tmp/recovery855_automation_XXXXXX";
        require(::mkdtemp(temporary)!=nullptr,"mkdtemp failed");
        const fs::path root=temporary;

        // A fresh run generates several error types and needs two automatic
        // retry passes. Other tasks' contributions must be applied only once.
        reset_fixture(); fixture.transient_failures=2;
        fixture.defer_coefficient_once=true;
        fixture.expansion_timeout=fixture.fail_seed_once=true;
        const auto automatic=root/"automatic";
        require(run_recovery855(options_for(automatic))==0,"automatic recovery did not finish");
        require_complete(automatic);
        {
            Journal journal(automatic.string()); State state; journal.load(state);
            require(state.retry_pass==2,"transient failure was not automatically retried twice");
        }
        require(fixture.unlimited_expansions>0 && fixture.strict_seen,"no exact retry was used");
        const auto committed=read_file(automatic/"checkpoint.json");
        const auto calls=fixture.coefficient_calls;
        require(run_recovery855(options_for(automatic))==0,"completed run was not reusable");
        require(read_file(automatic/"checkpoint.json")==committed && fixture.coefficient_calls==calls,
                "completed work was recomputed");
        std::cout << "PASS: fresh run, automatic retries, unlimited fallback, exact contribution merge\n";

        // Crash immediately after RETRY was committed, before START. Later
        // transactions are uncommitted orphans and must be safely replaced.
        const auto after_retry=root/"after_retry";
        fs::copy(automatic,after_retry,fs::copy_options::recursive);
        unsigned long long retry_commit=0;
        for(const auto& entry:fs::directory_iterator(after_retry/"commits")) {
            if(read_file(entry.path()).find("RECOVERY_EVENT 1 RETRY\n")==0) {
                const auto n=std::stoull(entry.path().stem().string());
                if(!retry_commit || n<retry_commit) retry_commit=n;
            }
        }
        require(retry_commit!=0,"retry event missing");
        atomic_file(after_retry/"checkpoint.json",[&](std::ostream& out){out << "{\"last_commit\":" << retry_commit << "}\n";});
        fs::remove(after_retry/"superpoly.txt");
        reset_fixture();
        require(run_recovery855(options_for(after_retry))==0,"resume after RETRY failed");
        require_complete(after_retry);
        std::cout << "PASS: crash after retry commit; orphan transactions do not duplicate contributions\n";

        // Persistent external errors stop without ever claiming completeness.
        reset_fixture(); fixture.persistent_failure=true;
        const auto persistent=root/"persistent";
        require(run_recovery855(options_for(persistent))==2,"persistent failure claimed success");
        require(!fs::exists(persistent/"superpoly.txt"),"incomplete result was named complete");
        require(fs::exists(persistent/"partial_superpoly.txt"),"partial result was not saved");
        {
            Journal journal(persistent.string()); State state; journal.load(state);
            require(state.retry_pass==RECOVERY_STALLED_RETRY_LIMIT && state.failed.size()==6,
                    "no-progress stopping policy lost failed tasks");
        }
        reset_fixture();
        // An old partial OUTPUT event is present. The ordinary command must
        // now retry it automatically, with no --retry-failed flag.
        require(run_recovery855(options_for(persistent))==0,"ordinary resume did not retry a partial run");
        require_complete(persistent);
        std::cout << "PASS: persistent failure stays partial; ordinary rerun recovers saved failures\n";

        reset_fixture(); fixture.transient_failures=fixture.other_failures=1;
        fixture.interrupt_retry=true;
        const auto interrupted=root/"interrupted";
        require(run_recovery855(options_for(interrupted))==130,"solver interruption was swallowed");
        require(!fs::exists(interrupted/"superpoly.txt"),"interrupted run produced a complete result");
        {
            Journal journal(interrupted.string()); State state; journal.load(state);
            require(state.cursor==1 && state.retry_succeeded==1 && state.polynomial.p.size()==5,
                    "completed prefix of interrupted retry batch was not committed");
        }
        reset_fixture();
        require(run_recovery855(options_for(interrupted))==0,"interrupted retry could not resume");
        require_complete(interrupted);
        std::cout << "PASS: interruption during automatic retry resumes without double counting\n";

        // Legacy schema-1 events contain no retry counters. Equal failed
        // linear contributions cancel over GF(2), without any solver call.
        reset_fixture(); fixture.persistent_failure=true;
        const auto parity=root/"legacy_parity";
        fs::create_directories(parity/"commits");
        atomic_file(parity/"configuration.txt",[](std::ostream& out){out << configuration();});
        const std::string term=Term(1).to_string();
        const std::vector<std::string> events={
            "START\n1 3 225 0 0\nTERMS 2\n"+term+"\n"+term+"\n",
            "BATCH\n1 0 2\nPOLY 0\nTERMS 0\nFAILURES 2\n0 10009 \"old error\"\n"+term+
                "\n1 10009 \"old error\"\n"+term+"\n",
            "GROUP_END\n","FINISH\n","OUTPUT\n\"partial\"\n"};
        for(size_t i=0;i<events.size();++i)
            atomic_file(parity/"commits"/(number(i+1)+".txn"),[&](std::ostream& out){out << "RECOVERY_EVENT 1 " << events[i] << "END\n";});
        atomic_file(parity/"checkpoint.json",[](std::ostream& out){out << "{\"last_commit\":5}\n";});
        require(run_recovery855(options_for(parity))==0,"legacy parity-cancelled errors were not resolved");
        require(fixture.coefficient_calls==0 && read_file(parity/"superpoly.txt").find("1*(0)\n")==0,
                "duplicate failed terms did not cancel");
        std::cout << "PASS: legacy partial checkpoint and GF(2) cancellation of failed tasks\n";
        fs::remove_all(root);
        return 0;
    } catch(const std::exception& error) {
        std::cerr << error.what() << '\n'; return 1;
    }
}
