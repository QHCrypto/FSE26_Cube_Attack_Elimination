#!/usr/bin/env python3
"""Check exact counts against explicit small distributive expansions."""
from collections import Counter
from itertools import product
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

BINARY = Path(sys.argv.pop(1) if len(sys.argv) > 1 else './expand_z83_unmerged').resolve()


class ExpansionTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.input = self.root / 'input.txt'

    def tearDown(self):
        self.temp.cleanup()

    def run_tool(self, *args, ok=True):
        result = subprocess.run([str(BINARY), str(self.input), *map(str, args)],
                                capture_output=True, text=True, timeout=30)
        self.assertEqual(result.returncode == 0, ok, result.stdout + result.stderr)
        return result

    def test_distributive_expansion_and_parallel_order(self):
        # Explicit formulas exercise constants, repeated physical bits, and
        # boundaries between the different z^83 substitution rules.
        rules = {
            0: [{0}], 64: [{64}],
            80: [{67}, set()], 81: [{66}, set()],
            82: [{53}, {78, 79}], 83: [{52}, {77, 78}, {79}],
            135: [{0}, {25, 26}, {27}], 136: [{24, 25}, {26}, {68}],
            137: [{23, 24}, {25}, {67}, set()],
            138: [{22, 23}, {24}, {66}, set()],
            147: [{13, 14}, {15}, {57}],
            148: [{12, 13}, {14}, {56}, {65}],
            152: [{8, 9}, {10}, {52}, {61}],
        }
        terms = [(i,) for i in rules] + [(0, 80, 137), (64, 148), (80,), (80,)]
        tokens = [''.join(f'k{i}' for i in term) for term in terms] + ['1', '0']
        self.input.write_text('metadata\n1*(' + '+'.join(tokens) + ')\nstatus: complete\n')
        expected = []
        for term in terms:
            for alternatives in product(*(rules[i] for i in term)):
                bits = set().union(*alternatives)
                expected.append(''.join(f'k{i}' for i in sorted(bits)) or '1')
        expected.append('1')
        expression = '1*(' + '+'.join(expected) + ')\n'
        result = self.run_tool()
        self.assertIn(f'expanded_terms={len(expected)} ', result.stdout)
        self.assertIn(f'output_bytes={len(expression)} ', result.stdout)
        self.assertEqual(set(self.root.iterdir()), {self.input})
        for threads in (1, 8):
            output = self.root / f'out{threads}.txt'
            self.run_tool(output, '--threads', threads)
            self.assertEqual(output.read_text(), expression)
        self.assertTrue(any(count > 1 for count in Counter(expected).values()))
        # The z spelling must give the same result and byte count.
        self.input.write_text(self.input.read_text().replace('k', 'z'))
        self.assertEqual(self.run_tool().stdout, result.stdout)

    def test_count_only_never_writes(self):
        self.input.write_text('1*(k80k80+k80+k80)\n')
        output = self.root / 'existing.txt'
        output.write_text('keep this')
        for option in ('--count-only', '--estimate-only'):
            result = self.run_tool(output, option)
            self.assertIn('expanded_terms=8 ', result.stdout)
            self.assertEqual(output.read_text(), 'keep this')
        self.run_tool(output, ok=False)

    def test_zero_and_constant(self):
        for expression, count in (('1*(0)\n', 0), ('1*(1)\n', 1)):
            self.input.write_text(expression)
            output = self.root / f'{count}.txt'
            result = self.run_tool(output, '--threads', 4)
            self.assertIn(f'expanded_terms={count} ', result.stdout)
            self.assertEqual(output.read_text(), expression)
            self.assertIn(f'output_bytes={output.stat().st_size} ', result.stdout)

    def test_bad_input_and_overflow(self):
        for expression in ('', '1*()', '1*(k153)', '1*(k80+)', '1*(k)',
                           '1*(k0++k1)', '1*(k0)\n1*(k1)', '1*(' + 'k80' * 128 + ')'):
            with self.subTest(expression=expression[:50]):
                self.input.write_text(expression)
                self.run_tool(ok=False)
        self.input.write_text('1*(k80)\n')
        for args in (('--threads', '0'), ('--threads', '257'), ('--threads',), ('--bogus',)):
            self.run_tool(*args, ok=False)


if __name__ == '__main__':
    unittest.main()
