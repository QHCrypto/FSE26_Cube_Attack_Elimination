# 855-round Trivium Conditional Superpoly

Requires Linux, C++17 with OpenMP, and Python 3.9+. Recovery additionally
requires Gurobi with a valid license; configure it in `Makefile`. CUDA
verification requires the CUDA Toolkit and an NVIDIA GPU/driver. Run commands
from this directory.

## Recovery

```bash
make -j 2
./a.out
```

Recovers cube I4 under `z61 = z63 = z100 = z102 = z124 = z126 = 0`.
Output: `runs/recovery855_progress/superpoly.txt`, before physical-key substitution.
Here `k0`–`k152` denote round-83 auxiliary variables.
Bundled result: `results/superpoly_z83.txt` (1,233,115 terms).

## Key substitution

```bash
make expand_z83_unmerged

# Count only
./expand_z83_unmerged results/superpoly_z83.txt

# Write the polynomial
mkdir -p runs
./expand_z83_unmerged results/superpoly_z83.txt runs/unmerged_k0_k79.txt
```

Both modes report the term count after substitution into `k0`–`k79`, without
combining equal terms: 4,162,761,127 terms, approximately 185 GB if written.

## Weak-key balance

Requires only C++17 with OpenMP. The default samples 100,000 distinct keys
under the six conditions above and evaluates the bundled superpoly.

```bash
make balance_855
./balance_855 --threads 8 --seed 855
```

Use `--csv FILE` to save each key and its value; use `make check-balance` to
check the evaluator. The recorded sample is in
`results/balance_855_100000_seed855.csv` with its summary in
`results/balance_855_100000_seed855.json`: 49,981 ones out of 100,000
(0.49981). The sample estimates balance; it does not prove exact balance.

## CUDA verification

```bash
make -C cuda_validation
python3 cuda_validation/batch.py --count 50
```

Compares 50 complete cube sums with the bundled superpoly. Outputs in
`cuda_validation/runs/weakkeys_50/`: `key_XX/result.json`, `summary.json`, and
`summary.csv`, recording keys, CUDA times, cube sums, superpoly values, and match rate.
Use a new `--batch-dir` for another run.
