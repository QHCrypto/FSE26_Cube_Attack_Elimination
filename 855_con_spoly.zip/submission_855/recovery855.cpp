#include "recovery855.h"
#include "trivium.h"
#include "triviumcallback.h"
#include "triviumframework.h"
#include <atomic>
#include <chrono>
#include <deque>
#include <filesystem>
#include <functional>
#include <iomanip>
#include <mutex>
#include <omp.h>
#include <regex>
#include <sstream>
#include <sys/file.h>
#include <fcntl.h>
#include <unistd.h>
#include "main.h"

namespace {
namespace fs = std::filesystem;
using Term = std::bitset<288>;
using Terms = std::vector<Term>;
using Parity = std::set<Term, CMPS<288>>;
enum Kind { NONE, SEED, INITIAL_EXPAND, COEFFICIENT, NESTED_EXPAND };
const std::vector<int> cube_ids = {
    0,1,2,3,5,7,9,10,11,12,13,14,16,18,20,22,24,27,29,31,33,35,37,
    39,42,44,46,48,50,52,54,57,59,61,63,65,67,68,69,70,72,74,76,78,79};
const std::vector<int> zero_ids = {61,63,100,102,124,126};

struct Plan { Kind kind = NONE; int round = 0, target = 0; Terms terms; };
struct Failure {
    unsigned long long stage = 0, index = 0;
    Kind kind = NONE;
    int round = 0, target = 0, code = -1;
    Term term;
    std::string message;
};
struct State {
    Plan plan;
    unsigned long long stage = 0, handled = 0;
    unsigned long long retry_pass = 0, retry_succeeded = 0;
    size_t cursor = 0;
    Parity next;
    Kpoly polynomial;
    std::vector<Failure> failed;
    std::deque<Plan> retry;
    bool finished = false;
    std::string output_status;
};
struct Batch {
    size_t begin = 0, end = 0;
    Parity next;
    Kpoly delta;
    std::vector<Failure> failed;
};
struct Result {
    bool handled = false, interrupted = false, defer = false, expand = false;
    Terms terms;
    Kpoly coefficient;
    int code = -1;
    std::string error;
};

std::string json(const std::string& value) {
    std::ostringstream out;
    out << '"';
    for (unsigned char c : value) {
        switch(c) {
        case '"': out << "\\\""; break;
        case '\\': out << "\\\\"; break;
        case '\n': out << "\\n"; break;
        case '\r': out << "\\r"; break;
        case '\t': out << "\\t"; break;
        default:
            if (c < 32) out << "\\u" << std::hex << std::setw(4) << std::setfill('0') << int(c) << std::dec;
            else out << c;
        }
    }
    out << '"';
    return out.str();
}
std::string number(unsigned long long n) {
    std::ostringstream out; out << std::setw(10) << std::setfill('0') << n; return out.str();
}
std::string kind_name(Kind kind) {
    switch(kind) {
    case SEED: return "seed_expand";
    case INITIAL_EXPAND: return "initial_expand";
    case COEFFICIENT: return "coef";
    case NESTED_EXPAND: return "nested_expand";
    default: return "none";
    }
}
void toggle(Parity& set, const Term& term) {
    auto it = set.find(term);
    if (it == set.end()) set.insert(term); else set.erase(it);
}
void xor_polynomial(Kpoly& accumulated, const Kpoly& delta) {
    for(const auto& mono:delta.p) {
        auto found=accumulated.p.find(mono);
        if(found==accumulated.p.end()) accumulated.p.insert(mono);
        else accumulated.p.erase(found);
    }
}

void sync_path(const fs::path& path, bool directory = false) {
    int fd = ::open(path.c_str(), O_RDONLY | (directory ? O_DIRECTORY : 0));
    if(fd < 0) throw std::runtime_error("cannot open for fsync: " + path.string());
    int rc = ::fsync(fd); ::close(fd);
    if(rc) throw std::runtime_error("fsync failed: " + path.string());
}
void atomic_file(const fs::path& path, const std::function<void(std::ostream&)>& writer) {
    const fs::path temp = path.string() + ".tmp";
    {
        std::ofstream out(temp, std::ios::trunc);
        out.exceptions(std::ios::badbit | std::ios::failbit);
        writer(out); out.flush(); out.close();
    }
    sync_path(temp);
    fs::rename(temp,path);
    sync_path(path.parent_path(),true);
}
void expect(std::istream& in, const std::string& token) {
    std::string actual;
    if(!(in >> actual) || actual != token) throw std::runtime_error("invalid recovery journal, expected " + token);
}
Term read_term(std::istream& in) {
    std::string text;
    if(!(in >> text) || text.size()!=288 || text.find_first_not_of("01")!=std::string::npos)
        throw std::runtime_error("invalid 288-bit state term in journal");
    return Term(text);
}
void write_terms(std::ostream& out, const Terms& terms) {
    out << "TERMS " << terms.size() << '\n';
    for(const auto& term:terms) out << term << '\n';
}
Terms read_terms(std::istream& in) {
    expect(in,"TERMS"); size_t count;
    if(!(in >> count)) throw std::runtime_error("missing term count");
    Terms terms; terms.reserve(count);
    for(size_t i=0;i<count;++i) terms.push_back(read_term(in));
    return terms;
}
void write_poly(std::ostream& out, const Kpoly& poly) {
    out << "POLY " << poly.p.size() << '\n';
    for(const auto& term:poly.p) {
        out << term.k.count();
        for(int i=0;i<N;++i) if(term.k[i]) out << ' ' << i;
        out << '\n';
    }
}
Kpoly read_poly(std::istream& in) {
    expect(in,"POLY"); size_t count;
    if(!(in >> count)) throw std::runtime_error("missing polynomial count");
    Kpoly poly;
    for(size_t i=0;i<count;++i) {
        size_t degree; if(!(in >> degree) || degree>N) throw std::runtime_error("invalid monomial degree");
        Kmono term; int previous=-1;
        for(size_t j=0;j<degree;++j) {
            int index;
            if(!(in >> index) || index<=previous || index>=N) throw std::runtime_error("invalid variable index");
            term.k[index]=1; previous=index;
        }
        if(!poly.p.insert(term).second) throw std::runtime_error("duplicate monomial in journal");
    }
    return poly;
}
std::string failure_json(const Failure& f) {
    std::ostringstream out;
    out << "{\"stage\":" << f.stage << ",\"index\":" << f.index
        << ",\"kind\":" << json(kind_name(f.kind)) << ",\"round\":" << f.round
        << ",\"target_round\":" << f.target << ",\"code\":" << f.code
        << ",\"state_s287_to_s0\":" << json(f.term.to_string())
        << ",\"error\":" << json(f.message) << "}\n";
    return out.str();
}
std::string configuration() {
    std::ostringstream out;
    out << "recovery855-v1\nN=" << N << "\nround=855\nFASTBOUND=" << FASTBOUND
        << "\nOUTROUND=" << OUTROUND << "\nBASEROUND=" << BASEROUND << "\ncube=";
    for(int i:cube_ids) out << i << ',';
    out << "\nzero="; for(int i:zero_ids) out << i << ',';
    out << "\nstate_text=s287..s0\npolynomial_variables=z0..z881\n";
    return out.str();
}
class Journal {
    fs::path root;
    int lock_fd = -1;
    unsigned long long last = 0;
public:
    explicit Journal(const std::string& directory):root(fs::absolute(directory)) {
        fs::create_directories(root/"commits");
        fs::create_directories(root/"failures");
        lock_fd=::open((root/"run.lock").c_str(),O_CREAT|O_RDWR,0600);
        if(lock_fd<0 || ::flock(lock_fd,LOCK_EX|LOCK_NB)) {
            if(lock_fd>=0) ::close(lock_fd);
            lock_fd=-1; throw std::runtime_error("recovery directory is locked: " + root.string());
        }
        const auto config=root/"configuration.txt";
        if(fs::exists(config)) {
            std::ifstream in(config);
            std::string text((std::istreambuf_iterator<char>(in)),{});
            if(text!=configuration()) throw std::runtime_error("checkpoint configuration does not match this recovery");
        } else {
            if(fs::exists(root/"checkpoint.json")) throw std::runtime_error("checkpoint lacks configuration.txt");
            atomic_file(config,[](std::ostream& out){out << configuration();});
        }
        if(fs::exists(root/"checkpoint.json")) {
            std::ifstream in(root/"checkpoint.json");
            const std::string text((std::istreambuf_iterator<char>(in)),{});
            std::smatch match;
            if(!std::regex_search(text,match,std::regex("\"last_commit\"\\s*:\\s*([0-9]+)")))
                throw std::runtime_error("invalid checkpoint.json");
            last=std::stoull(match[1]);
        }
    }
    ~Journal() { if(lock_fd>=0) ::close(lock_fd); }
    fs::path path() const { return root; }
    bool empty() const { return last==0; }
    void append(const std::string& type, const std::function<void(std::ostream&)>& writer,
                const State& state) {
        const auto next=last+1;
        // A transaction beyond checkpoint.last_commit is uncommitted. Replacing
        // such an orphan after a crash cannot apply a contribution twice.
        atomic_file(root/"commits"/(number(next)+".txn"),[&](std::ostream& out){
            out << "RECOVERY_EVENT 1 " << type << '\n'; writer(out); out << "END\n";
        });
        atomic_file(root/"checkpoint.json",[&](std::ostream& out){
            size_t queued=0; for(const auto& plan:state.retry) queued+=plan.terms.size();
            out << "{\n  \"schema\":1,\n  \"last_commit\":" << next
                << ",\n  \"status\":" << json(state.output_status.empty()
                    ? (state.finished ? (state.failed.empty()?"enumeration_complete":"partial") : "running") : state.output_status)
                << ",\n  \"stage\":" << state.stage << ",\n  \"kind\":" << json(kind_name(state.plan.kind))
                << ",\n  \"round\":" << state.plan.round << ",\n  \"target_round\":" << state.plan.target
                << ",\n  \"cursor\":" << state.cursor << ",\n  \"stage_terms\":" << state.plan.terms.size()
                << ",\n  \"handled_tasks\":" << state.handled << ",\n  \"unresolved_failed_tasks\":" << state.failed.size()
                << ",\n  \"retry_pass\":" << state.retry_pass
                << ",\n  \"retry_pass_completed_tasks\":" << state.retry_succeeded
                << ",\n  \"queued_retry_terms\":" << queued << ",\n  \"partial_monomials\":" << state.polynomial.p.size()
                << ",\n  \"intermediate_coefficient_seconds\":" << TIMELIMIT
                << ",\n  \"path_seconds\":" << RECOVERY_PATH_SECONDS
                << ",\n  \"fallback_seconds\":" << RECOVERY_FALLBACK_SECONDS << "\n}\n";
        });
        last=next;
    }
    void load(State& state) {
        for(unsigned long long n=1;n<=last;++n) {
            std::ifstream in(root/"commits"/(number(n)+".txn"));
            if(!in) throw std::runtime_error("missing committed recovery transaction " + number(n));
            expect(in,"RECOVERY_EVENT"); int version; std::string type;
            if(!(in >> version >> type) || version!=1) throw std::runtime_error("unsupported journal version");
            if(type=="START") {
                unsigned long long stage; int kind,round,target; bool from_retry;
                if(!(in >> stage >> kind >> round >> target >> from_retry) || kind<SEED || kind>NESTED_EXPAND)
                    throw std::runtime_error("invalid stage header");
                if(stage!=state.stage+1) throw std::runtime_error("stage sequence mismatch");
                if(state.finished || (state.plan.kind!=NONE && state.cursor!=state.plan.terms.size()))
                    throw std::runtime_error("starting a stage before its predecessor finished");
                if(from_retry && state.plan.kind!=NONE) throw std::runtime_error("retry started inside an active group");
                state.stage=stage; state.plan={Kind(kind),round,target,read_terms(in)};
                if(from_retry) {
                    if(state.retry.empty()) throw std::runtime_error("retry queue is empty");
                    const auto& queued=state.retry.front();
                    if(queued.kind!=state.plan.kind || queued.round!=round || queued.target!=target || queued.terms!=state.plan.terms)
                        throw std::runtime_error("retry plan mismatch");
                    state.retry.pop_front();
                }
                state.cursor=0; state.next.clear(); state.finished=false; state.output_status.clear();
            } else if(type=="BATCH") {
                size_t begin,end; unsigned long long stage;
                if(!(in >> stage >> begin >> end) || stage!=state.stage || begin!=state.cursor || state.plan.kind==NONE || state.finished || end<=begin || end>state.plan.terms.size())
                    throw std::runtime_error("batch cursor mismatch");
                xor_polynomial(state.polynomial,read_poly(in));
                for(const auto& term:read_terms(in)) toggle(state.next,term);
                expect(in,"FAILURES"); size_t count;
                if(!(in >> count) || count>end-begin) throw std::runtime_error("invalid failures count");
                for(size_t i=0;i<count;++i) {
                    Failure f; f.stage=stage; f.kind=state.plan.kind; f.round=state.plan.round; f.target=state.plan.target;
                    if(!(in >> f.index >> f.code >> std::quoted(f.message)) || f.index<begin || f.index>=end)
                        throw std::runtime_error("invalid failed task");
                    f.term=read_term(in);
                    if(f.term!=state.plan.terms[f.index]) throw std::runtime_error("failed term mismatch");
                    state.failed.push_back(std::move(f));
                }
                state.cursor=end; state.handled+=end-begin;
                if(state.retry_pass) state.retry_succeeded+=end-begin-count;
            } else if(type=="GROUP_END") {
                if(state.plan.kind==NONE || state.cursor!=state.plan.terms.size()) throw std::runtime_error("incomplete stage ended");
                state.plan=Plan{}; state.cursor=0; state.next.clear();
            } else if(type=="RETRY") {
                make_retry(state);
            } else if(type=="FINISH") {
                if(state.plan.kind!=NONE || !state.retry.empty()) throw std::runtime_error("unfinished task queue");
                state.finished=true;
            } else if(type=="OUTPUT") {
                if(!(in >> std::quoted(state.output_status))) throw std::runtime_error("missing output status");
                if(!state.finished || state.output_status!=(state.failed.empty()?"complete":"partial"))
                    throw std::runtime_error("output status conflicts with pending recovery work");
            } else throw std::runtime_error("unknown journal event");
            expect(in,"END");
            std::string trailing; if(in >> trailing) throw std::runtime_error("extra data in recovery transaction");
        }
    }
    static void make_retry(State& state) {
        if(!state.finished || state.plan.kind!=NONE || !state.retry.empty())
            throw std::runtime_error("finish the active recovery before retrying failed tasks");
        std::map<std::tuple<int,int,int>,Parity> groups;
        for(const auto& f:state.failed) toggle(groups[{int(f.kind),f.round,f.target}],f.term);
        for(const auto& entry:groups) {
            if(entry.second.empty()) continue;
            Plan plan;
            plan.kind=Kind(std::get<0>(entry.first)); plan.round=std::get<1>(entry.first); plan.target=std::get<2>(entry.first);
            plan.terms.assign(entry.second.begin(),entry.second.end()); state.retry.push_back(std::move(plan));
        }
        state.failed.clear(); state.finished=false; state.output_status.clear();
        ++state.retry_pass; state.retry_succeeded=0;
    }
    void export_failures(const State& state) {
        atomic_file(root/"pending_failed.jsonl",[&](std::ostream& out){for(const auto& f:state.failed) out << failure_json(f);});
        std::map<std::string,std::vector<const Failure*>> files;
        for(const auto& f:state.failed) {
            std::string name="r"+std::to_string(f.round);
            if(f.kind!=COEFFICIENT) name+="_to"+std::to_string(f.target);
            name+="_"+kind_name(f.kind)+"_failed_stage"+number(f.stage);
            files[name].push_back(&f);
        }
        for(const auto& entry:files) {
            atomic_file(root/"failures"/(entry.first+".jsonl"),[&](std::ostream& out){for(auto f:entry.second) out << failure_json(*f);});
            atomic_file(root/"failures"/(entry.first+".vts"),[&](std::ostream& out){for(auto f:entry.second) out << f->term << '\n';});
        }
    }
    void export_polynomial(const State& state) {
        atomic_file(root/"partial_spoly.txt",[&](std::ostream& out){
            out << "basis_round=225; variables=z0..z881; terms complete individually; overall recovery may be incomplete\n1*("
                << const_cast<Kpoly&>(state.polynomial) << ")\n";
        });
    }
    void export_vts(const State& state) {
        const auto name="stage"+number(state.stage)+"_r"+std::to_string(state.plan.round)+"_"+kind_name(state.plan.kind)+"_vts.txt";
        atomic_file(root/name,[&](std::ostream& out){for(const auto& term:state.plan.terms) out << term << '\n';});
    }
};

void start(Journal& journal, State& state, Plan plan, bool retry=false) {
    if(retry) state.retry.pop_front();
    ++state.stage; state.plan=std::move(plan); state.cursor=0; state.next.clear(); state.finished=false; state.output_status.clear();
    journal.append("START",[&](std::ostream& out){
        out << state.stage << ' ' << int(state.plan.kind) << ' ' << state.plan.round << ' ' << state.plan.target << ' ' << retry << '\n';
        write_terms(out,state.plan.terms);
    },state);
    journal.export_vts(state);
    std::cout << "Stage " << state.stage << ": " << kind_name(state.plan.kind) << " r" << state.plan.round
              << " -> r" << state.plan.target << ", terms=" << state.plan.terms.size() << std::endl;
}
Plan next_plan(const State& state, const std::bitset<80>& cube) {
    Plan plan;
    plan.terms.assign(state.next.begin(),state.next.end());
    if(plan.terms.empty()) return Plan{};
    if(state.plan.kind==COEFFICIENT) {
        if(state.plan.round==OUTROUND) throw std::runtime_error("final unlimited coefficient model requested expansion");
        plan.kind=NESTED_EXPAND; plan.round=state.plan.round; plan.target=std::max(plan.round-30,OUTROUND);
    } else {
        plan.round=state.plan.target;
        filterTerms(cube,plan.round,plan.terms);
        if(plan.terms.empty()) return Plan{};
        if(state.plan.kind==NESTED_EXPAND || plan.round<=FASTBOUND) {
            plan.kind=COEFFICIENT; plan.target=0;
        } else {
            plan.kind=INITIAL_EXPAND; plan.target=std::max(plan.round-30,FASTBOUND);
        }
    }
    return plan;
}
Result work(const Plan& plan, const Term& term, std::bitset<80>& cube,
            const std::bitset<288>& zero_states, const std::vector<KVpoly>& coefficient_state,
            bool exact_retry) {
    Result result;
    try {
        if(plan.kind==COEFFICIENT) {
            KVpoly poly;
            int count=N0_round_model(coefficient_state,cube,1,term,poly,!exact_retry && plan.round!=OUTROUND);
            if(count==-1) {
                if(exact_retry) throw RecoveryError("unlimited coefficient retry returned a time limit",GRB_TIME_LIMIT);
                result.expand=true;
            }
            else {
                Vmono constant;
                for(const auto& item:poly.p) if(!item.first.v.none()) throw RecoveryError("coefficient contains residual IV variables");
                auto it=poly.p.find(constant); if(it!=poly.p.end()) result.coefficient=std::move(it->second);
            }
        } else if(plan.kind==SEED || exact_retry) {
            // Retrying the same bounded callback can time out forever. Use the
            // complete back expansion directly, with no time limit, instead.
            if(SecondBackExpandPolynomial(plan.round-plan.target,term,result.terms,exact_retry?1:6,0)==-1)
                throw RecoveryError("unlimited back expansion returned a time limit",GRB_TIME_LIMIT);
        } else {
            const double budget=plan.kind==INITIAL_EXPAND ? 30.0 : 60.0;
            const int threads=plan.kind==INITIAL_EXPAND ? 6 : 8;
            STATUS status=uMidSolutionCallBack(plan.round,cube,term,result.terms,budget,threads,plan.target,BASEROUND,zero_states);
            if(status==EXPAND) {
                result.terms.clear();
                if(SecondBackExpandPolynomial(plan.round-plan.target,term,result.terms,threads,RECOVERY_FALLBACK_SECONDS)==-1)
                    throw RecoveryError("callback incomplete; fallback expansion exceeded 120 seconds",GRB_TIME_LIMIT);
            }
        }
        result.handled=true;
    } catch(const RecoveryInterrupted&) {
        result=Result{}; result.interrupted=true;
    } catch(const RecoveryError& e) {
        result=Result{}; result.handled=result.defer=true; result.code=e.code; result.error=e.what();
    } catch(const GRBException& e) {
        result=Result{}; result.handled=result.defer=true; result.code=e.getErrorCode(); result.error=e.getMessage();
    } catch(const std::exception& e) {
        result=Result{}; result.handled=result.defer=true; result.error=e.what();
    } catch(...) {
        result=Result{}; result.handled=result.defer=true; result.error="unknown task exception";
    }
    return result;
}
bool process_batch(Journal& journal, State& state, const RecoveryOptions& options,
                   std::bitset<80>& cube, const std::bitset<288>& zero_states,
                   const std::vector<KVpoly>& coefficient_state) {
    const auto begin=state.cursor;
    const auto end=std::min(state.plan.terms.size(),begin+options.batch_size);
    std::vector<Result> results(end-begin);
    std::atomic<bool> interrupted{false};
    const bool exact_retry=state.retry_pass!=0;
    const int workers=exact_retry ? 1 : (state.plan.kind==COEFFICIENT ? options.threads : std::min(options.threads,400));
    #pragma omp parallel for schedule(dynamic) num_threads(workers)
    for(size_t i=0;i<results.size();++i) {
        if(interrupted.load()) continue;
        results[i]=work(state.plan,state.plan.terms[begin+i],cube,zero_states,coefficient_state,exact_retry);
        if(results[i].interrupted) interrupted.store(true);
    }
    Batch batch; batch.begin=begin; batch.end=begin;
    // If interrupted, commit only a contiguous handled prefix. Results after
    // an uncommitted gap are discarded and safely recomputed on resume.
    for(size_t i=0;i<results.size() && results[i].handled;++i) {
        auto& result=results[i]; ++batch.end;
        if(result.defer) {
            Failure failure;
            failure.stage=state.stage; failure.index=begin+i; failure.kind=state.plan.kind;
            failure.round=state.plan.round; failure.target=state.plan.target;
            failure.term=state.plan.terms[begin+i]; failure.code=result.code; failure.message=result.error;
            batch.failed.push_back(std::move(failure));
        } else if(result.expand) toggle(batch.next,state.plan.terms[begin+i]);
        else {
            xor_polynomial(batch.delta,result.coefficient);
            for(const auto& term:result.terms) toggle(batch.next,term);
        }
    }
    if(batch.end>batch.begin) {
        xor_polynomial(state.polynomial,batch.delta);
        for(const auto& term:batch.next) toggle(state.next,term);
        state.failed.insert(state.failed.end(),batch.failed.begin(),batch.failed.end());
        state.cursor=batch.end; state.handled+=batch.end-batch.begin;
        if(exact_retry) state.retry_succeeded+=batch.end-batch.begin-batch.failed.size();
        journal.append("BATCH",[&](std::ostream& out){
            out << state.stage << ' ' << batch.begin << ' ' << batch.end << '\n';
            write_poly(out,batch.delta);
            write_terms(out,Terms(batch.next.begin(),batch.next.end()));
            out << "FAILURES " << batch.failed.size() << '\n';
            for(const auto& f:batch.failed) out << f.index << ' ' << f.code << ' ' << std::quoted(f.message) << '\n' << f.term << '\n';
        },state);
        journal.export_failures(state);
        for(const auto& failure:batch.failed) {
            std::cerr << "Failed r" << failure.round << " " << kind_name(failure.kind)
                      << " stage=" << failure.stage << " term=" << failure.index
                      << " code=" << failure.code << ": " << failure.message
                      << "; original term archived in " << journal.path()/"failures" << std::endl;
        }
        std::cout << "Saved stage " << state.stage << ": " << state.cursor << '/' << state.plan.terms.size()
                  << ", deferred this batch=" << batch.failed.size() << ", unresolved=" << state.failed.size()
                  << ", accumulated monomials=" << state.polynomial.p.size() << std::endl;
    }
    return !interrupted.load();
}
} // namespace

int run_recovery855(const RecoveryOptions& options) {
    if(options.threads<1 || options.batch_size<1) throw std::invalid_argument("threads and batch size must be positive");
    static_assert(N==882 && FASTBOUND==225 && BASEROUND==69 && OUTROUND==83,"855 configuration changed");
    Journal journal(options.directory);
    State state; journal.load(state);
    if(state.finished && state.failed.empty() && state.output_status=="complete") {
        const auto output=journal.path()/"superpoly.txt";
        if(fs::is_regular_file(output)) {
            journal.export_failures(state);
            std::cout << "Recovery pass already finished; unresolved tasks=" << state.failed.size()
                      << "; result=" << output << std::endl;
            return 0;
        }
    }
    std::bitset<80> cube; for(int i:cube_ids) cube[i]=1;
    std::bitset<N> zero; for(int i:zero_ids) zero[i]=1;
    std::vector<KVpoly> basis,filtered;
    std::vector<Kpoly> definitions;
    trivium_simplify_poly(basis,definitions,BASEROUND);
    auto eliminated=trivium_flag_poly_2(cube,zero,basis,filtered);
    std::bitset<288> zero_states;
    for(const auto& entry:eliminated) for(int i:entry.second) {
        if(!filtered[i].p.empty()) throw std::runtime_error("cannot prune a partly nonzero state");
        zero_states[i]=1;
    }
    omp_set_num_threads(options.threads);
    std::cout << "Recovery directory: " << journal.path() << "\nCoefficient limit: " << TIMELIMIT
              << " seconds (final r83 unlimited); first-pass path and fallback limits: 120 seconds\n"
              << "Failed tasks are retried automatically, serially, with unlimited exact models." << std::endl;
    if(journal.empty()) {
        Plan seed; seed.kind=SEED; seed.round=855; seed.target=555;
        for(int i:{65,92,161,176,242,287}) { Term term; term[i]=1; seed.terms.push_back(term); }
        start(journal,state,std::move(seed));
    }
    journal.export_failures(state);
    if(state.plan.kind!=NONE) journal.export_vts(state);
    journal.export_polynomial(state);
    unsigned stalled_passes=0;
    for(;;) {
        if(state.finished) {
            if(state.failed.empty()) break;
            if(stalled_passes>=RECOVERY_STALLED_RETRY_LIMIT) {
                std::cerr << "Automatic recovery could not resolve any task in " << stalled_passes
                          << " consecutive retry passes; " << state.failed.size()
                          << " failed tasks remain. Progress is saved; no complete result will be produced."
                          << std::endl;
                break;
            }
            std::cout << "Automatic retry pass " << state.retry_pass+1 << ": unresolved tasks="
                      << state.failed.size() << "; serial exact solving without time limits." << std::endl;
            Journal::make_retry(state);
            journal.append("RETRY",[](std::ostream&){},state);
            journal.export_failures(state);
        }
        if(state.plan.kind==NONE) {
            if(!state.retry.empty()) {
                Plan next=state.retry.front(); start(journal,state,std::move(next),true); continue;
            }
            state.finished=true;
            journal.append("FINISH",[](std::ostream&){},state);
            if(state.retry_pass) {
                stalled_passes=state.retry_succeeded ? 0 : stalled_passes+1;
                std::cout << "Retry pass " << state.retry_pass << " finished; completed tasks="
                          << state.retry_succeeded << ", unresolved=" << state.failed.size() << std::endl;
            }
            continue;
        }
        std::vector<KVpoly> coefficient_state;
        if(state.plan.kind==COEFFICIENT) {
            trivium_simplify_poly(basis,definitions,state.plan.round);
            trivium_flag_poly_1(cube,zero,basis,coefficient_state);
        }
        while(state.cursor<state.plan.terms.size()) {
            if(!process_batch(journal,state,options,cube,zero_states,coefficient_state)) {
                journal.export_polynomial(state);
                std::cerr << "Interrupted; committed progress retained. Resume with the same directory." << std::endl;
                return 130;
            }
        }
        journal.export_polynomial(state);
        Plan next=next_plan(state,cube);
        if(next.kind!=NONE) start(journal,state,std::move(next));
        else {
            state.plan=Plan{}; state.cursor=0; state.next.clear();
            journal.append("GROUP_END",[](std::ostream&){},state);
        }
    }
    journal.export_polynomial(state);
    // This uses the author's existing parallel substitution, as requested.
    KVpoly original,result; Vmono constant;
    original.p[constant]=state.polynomial;
    substitute_kvpoly(result,original,OUTROUND,FASTBOUND,zero);
    const bool complete=state.failed.empty();
    const auto output=journal.path()/(complete?"superpoly.txt":"partial_superpoly.txt");
    atomic_file(output,[&](std::ostream& out){
        // Keep the polynomial on the first line, as in the published files.
        out << "1*(";
        auto it=result.p.find(constant);
        if(it==result.p.end()) out << '0'; else out << it->second;
        out << ")\nconditions: z61=z63=z100=z102=z124=z126=0\ncube: ";
        for(int i:cube_ids) out << i << ' ';
        out << "\nstatus: " << (complete?"complete":"partial") << "; unresolved=" << state.failed.size() << '\n';
    });
    if(!complete) {
        // Avoid leaving a stale full output after a later partial retry run.
        const auto full=journal.path()/"superpoly.txt";
        if(fs::exists(full)) throw std::runtime_error("partial recovery directory contains an unexpected full result");
    }
    state.output_status=complete?"complete":"partial";
    journal.append("OUTPUT",[&](std::ostream& out){out << std::quoted(state.output_status) << '\n';},state);
    std::cout << "Recovery pass finished; unresolved tasks=" << state.failed.size()
              << "; result=" << output << std::endl;
    return complete?0:2;
}
