#include "recovery855.h"
#include<map>
#include<cmath>
#include<vector>
#include<bitset>
#include<string>
#include"gurobi_c++.h" 
#include"node.h"
#include"log.h"
#include"trivium.h"
#include"triviumtrack.h"
#include"newtrivium.h"
#include"utrivium.h"

using namespace std;
const int MAX = 200000000;

// for back expand
class backcallback : public GRBCallback
{
public:
    vector<bitset<288> >* psolutions = NULL;
    vector<GRBVar> solvars;
    bitset<288> last;
    int rounds;
    int midround;
    bool failed = false;
    bool needs_expand = false;
    bool interrupted = false;
    int failure_code = -1;
    string failure_message;

    backcallback(vector<GRBVar>& solvars, vector<bitset<288> >& solutions, int rounds, int midround, const bitset<288>& last)
    {
        this->solvars = solvars;
        this->psolutions = &solutions;
        this->last = last;
        this->rounds = rounds;
        this->midround = midround;
    }

protected:
    void callback()
    {
        if (failed) return;
        try {
            if (where == GRB_CB_MIPSOL)
            {
                // read solution
                bitset<288> sol;
                for (int i = 0; i < 288; i++)
                    if (recovery_binary(getSolution(solvars[i])))
                        sol[i] = 1;

                // add lazy constr
                GRBLinExpr excludeCon = 0;
                for (int i = 0; i < 288; i++)
                    if (sol[i] == 1)
                        excludeCon += (1 - solvars[i]);
                    else
                        excludeCon += solvars[i];


                // check its parity
                int pathcnt = 0;
                STATUS status;
                status = MidSolutionCounter(midround, rounds, sol, last, pathcnt, RECOVERY_PATH_SECONDS, 1);
                if (status == EXPAND)
                {
                    failed = needs_expand = true;
                    failure_message = "callback path count exceeded 120 seconds";
                    abort();
                    return;
                }

                addLazy(excludeCon >= 1);
                if (pathcnt % 2 == 1)
                {
                    // save solution
                    //cout << "back find one solution : " << sol << endl;
                    (*psolutions).emplace_back(sol);
                    // if (midround == 200) {
                    //     ofstream vtfile("vtfile.txt",ios::app);
                    //     cout << sol << endl;
                    //     vtfile << sol << endl;
                    // }
                }

            }
        }
        catch (const RecoveryInterrupted& e) {
            failed = interrupted = true; failure_code = e.code;
            failure_message = e.what(); abort();
        }
        catch (const RecoveryError& e) {
            failed = true; failure_code = e.code;
            failure_message = e.what(); abort();
        }
        catch (const GRBException& e) {
            failed = true; failure_code = e.getErrorCode();
            failure_message = e.getMessage(); abort();
        }
        catch (const std::exception& e) {
            failed = true; failure_message = e.what(); abort();
        }
        catch (...) {
            failed = true; failure_message = "unknown callback exception"; abort();
        }
    }
};

STATUS uMidSolutionCallBack(int rounds, bitset<80>& cube, const bitset<288>& last, vector<bitset<288> >& sols, float time, int threads, int midround, int basis_round, bitset<288> zero_s)
{

// An all-zero zero_s imposes no additional restrictions.
    vector<bitset<288>> nonZeroTrackReps;
    triviumTrack(cube, nonZeroTrackReps, basis_round, zero_s);// Apply zero_s while tracking nonzero state positions.


    vector<bitset<288>> varsTrackReps;
    triviumVarsTrack(cube, varsTrackReps, nonZeroTrackReps);


    // close standard output
    GRBEnv env = GRBEnv();
    env.set(GRB_IntParam_LogToConsole, 0);
    env.set(GRB_IntParam_Threads, threads);
    env.set(GRB_IntParam_LazyConstraints, 1);
    env.set(GRB_IntParam_MIPFocus, 1);
    GRBModel model = GRBModel(env);



    // register
    vector<GRBVar> s(288);
    for (int i = 0; i < 288; i++)
        s[i] = model.addVar(0, 1, 0, GRB_BINARY);


    // constraints
    for (int i = 0; i < 80; i++)
        if (cube[i] == 0)
            model.addConstr(s[i + 93] == 0);
        else
            model.addConstr(s[i + 93] == 1);

    for (int i = 0; i < 93; i++)
        model.addConstr(s[i] == 0);
    for (int i = 93 + 80; i < 288; i++)
        model.addConstr(s[i] == 0);

        // int basis_round, bitset<288> zero_s
    // update
    for (int r = 0; r < basis_round-1; r++)
    {
        bitset<288> nonZeroFlag;
        bitset<288> varsFlag;
        setRoundFlags(r, cube, nonZeroFlag, varsFlag, nonZeroTrackReps, varsTrackReps);
        uupdate(model, s, nonZeroFlag, varsFlag);
    }
    for (int r = basis_round-1; r < basis_round; r++)
    {
        bitset<288> nonZeroFlag;
        bitset<288> varsFlag;
        setRoundFlags(r, cube, nonZeroFlag, varsFlag, nonZeroTrackReps, varsTrackReps);// Use the precomputed flags for this round.
        uupdate(model, s, nonZeroFlag, varsFlag);// Apply zero-state restrictions after reaching basis_round.
        for (int id = 0; id < 288; id++) {
            if (zero_s[id] == 1) {
                model.addConstr(s[id] == 0);
            }
        }
    }
    for (int r = basis_round; r < midround; r++)
    {
        bitset<288> nonZeroFlag;
        bitset<288> varsFlag;
        setRoundFlags(r, cube, nonZeroFlag, varsFlag, nonZeroTrackReps, varsTrackReps);
        uupdate(model, s, nonZeroFlag, varsFlag);
    }

    // mid constraints
    bitset<288> midNonZeroFlag;
    bitset<288> midVarsFlag;
    setRoundFlags(midround, cube, midNonZeroFlag, midVarsFlag, nonZeroTrackReps, varsTrackReps);

    vector<GRBVar> mids(288);
    for (int i = 0; i < 288; i++)
        mids[i] = model.addVar(0, 1, 0, GRB_BINARY);

    GRBLinExpr nk = 0;
    for (int i = 0; i < 288; i++)
        if (midNonZeroFlag[i])
        {
            model.addConstr(mids[i] >= s[i]);
            nk += (mids[i] - s[i]);
        }
        else
            model.addConstr(mids[i] == 0);

    s = mids;

    // second Phase
    for (int r = midround; r < rounds; r++)
        update(model, s);

    for (int i = 0; i < 288; i++)// State variables now represent the target round.
        if (last[i])
            model.addConstr(s[i] == 1);
        else
            model.addConstr(s[i] == 0);

    model.setObjective(nk, GRB_MAXIMIZE);


    // set callback function
    backcallback cb = backcallback(mids, sols, rounds, midround, last);
    model.setCallback(&cb);

    if (time > 0)
        model.set(GRB_DoubleParam_TimeLimit, time);

    model.optimize();

    const int status = model.get(GRB_IntAttr_Status);
    if (cb.failed) {
        sols.clear();
        if (cb.interrupted) throw RecoveryInterrupted(cb.failure_code);
        if (cb.needs_expand) return EXPAND;
        throw RecoveryError("callback failed: " + cb.failure_message, cb.failure_code);
    }
    if (status == GRB_INTERRUPTED) { sols.clear(); throw RecoveryInterrupted(status); }
    if (status == GRB_TIME_LIMIT) { sols.clear(); return EXPAND; }
    // Every visited candidate is excluded by a lazy constraint. Exhaustion
    // therefore normally ends INFEASIBLE, with the saved odd-parity terms.
    if (status != GRB_INFEASIBLE) {
        sols.clear();
        throw RecoveryError("callback enumeration did not exhaust candidates: status=" + to_string(status), status);
    }
    return sols.empty() ? NOSOLUTION : SOLUTION;
}
