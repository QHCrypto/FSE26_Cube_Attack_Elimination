#include "trivium_core.h"
#include <cuda_runtime.h>
#include <chrono>
#include <iomanip>
#include <iostream>
#include <limits>
#include <vector>

#define CUDA(call) do { cudaError_t e=(call); if(e!=cudaSuccess) \
    throw std::runtime_error(std::string(#call)+": "+cudaGetErrorString(e)); } while(0)
using namespace trivium;
constexpr int THREADS=256;

__global__ void cube_kernel(State initial_state,uint64_t start,uint64_t count,unsigned* result) {
    unsigned parity=0;
    for (uint64_t i=uint64_t(blockIdx.x)*blockDim.x+threadIdx.x; i<count;
         i+=uint64_t(gridDim.x)*blockDim.x)
        parity ^= packed855(initial_state,start+i);
    for (int d=16;d>0;d>>=1) parity^=__shfl_down_sync(0xffffffff,parity,d);
    __shared__ unsigned warps[THREADS/32];
    if ((threadIdx.x&31)==0) warps[threadIdx.x/32]=parity;
    __syncthreads();
    if (threadIdx.x<32) {
        parity=threadIdx.x<THREADS/32 ? warps[threadIdx.x] : 0;
        for(int d=16;d>0;d>>=1) parity^=__shfl_down_sync(0xffffffff,parity,d);
        if(threadIdx.x==0) atomicXor(result,parity);
    }
}
__global__ void sample_kernel(State s,const uint64_t* counters,unsigned* out,int n) {
    int i=blockIdx.x*blockDim.x+threadIdx.x;
    if(i<n) out[i]=packed855(s,counters[i]);
}
unsigned sum(State s,uint64_t start,uint64_t count,int blocks,unsigned* device_result) {
    CUDA(cudaMemset(device_result,0,sizeof(unsigned)));
    cube_kernel<<<blocks,THREADS>>>(s,start,count,device_result);
    CUDA(cudaGetLastError());
    unsigned value;
    CUDA(cudaMemcpy(&value,device_result,sizeof(value),cudaMemcpyDeviceToHost));
    if(value>1) throw std::runtime_error("invalid parity");
    return value;
}
// Executed on the selected GPU before enumeration, including high counter bits,
// full per-IV outputs (not only parity), and non-aligned reduction boundaries.
void self_test(const Key& key,int blocks,unsigned* device_result) {
    std::vector<uint64_t> counters={0,1,TOTAL-1,TOTAL-2};
    for(int j=0;j<DIM;++j) counters.push_back(uint64_t{1}<<j);
    uint64_t x=0x123456789abcdefULL;
    for(int i=0;i<128;++i) { x^=x<<13; x^=x>>7; x^=x<<17; counters.push_back(x&(TOTAL-1)); }
    uint64_t* dc=nullptr; unsigned* dr=nullptr;
    CUDA(cudaMalloc(&dc,counters.size()*sizeof(uint64_t)));
    CUDA(cudaMalloc(&dr,counters.size()*sizeof(unsigned)));
    CUDA(cudaMemcpy(dc,counters.data(),counters.size()*sizeof(uint64_t),cudaMemcpyHostToDevice));
    sample_kernel<<<(counters.size()+255)/256,256>>>(initial(key),dc,dr,int(counters.size()));
    CUDA(cudaGetLastError());
    std::vector<unsigned> result(counters.size());
    CUDA(cudaMemcpy(result.data(),dr,result.size()*sizeof(unsigned),cudaMemcpyDeviceToHost));
    CUDA(cudaFree(dc)); CUDA(cudaFree(dr));
    for(size_t i=0;i<counters.size();++i)
        if(result[i]!=scalar(key,cube_iv(counters[i])))
            throw std::runtime_error("GPU per-IV check failed at counter "+std::to_string(counters[i]));
    for(uint64_t count : {uint64_t{1},uint64_t{257},uint64_t{1025}}) {
        const uint64_t start=(uint64_t{1}<<44)+37;
        unsigned expected=0;
        for(uint64_t i=0;i<count;++i) expected^=scalar(key,cube_iv(start+i));
        if(sum(initial(key),start,count,blocks,device_result)!=expected)
            throw std::runtime_error("GPU reduction self-test failed");
    }
}
uint64_t number(const std::string& s) {
    if(s.empty() || s.find_first_not_of("0123456789")!=std::string::npos)
        throw std::runtime_error("expected a nonnegative decimal integer");
    return std::stoull(s);
}
int main(int argc,char** argv) {
    try {
        std::string hex;
        uint64_t start=0,count=TOTAL,chunk=uint64_t{1}<<26;
        int device=0; bool only_test=false;
        for(int i=1;i<argc;++i) {
            std::string a=argv[i];
            if(a=="--self-test") { only_test=true; continue; }
            if(a=="--help") {
                std::cout<<"cube855 --key-hex HEX [--start N --count N --chunk-size N --device N --self-test]\n";
                return 0;
            }
            if(i+1==argc) throw std::runtime_error("missing value for "+a);
            std::string v=argv[++i];
            if(a=="--key-hex") hex=v;
            else if(a=="--start") start=number(v);
            else if(a=="--count") count=number(v);
            else if(a=="--chunk-size") chunk=number(v);
            else if(a=="--device") {
                auto n=number(v);
                if(n>std::numeric_limits<int>::max()) throw std::runtime_error("invalid device");
                device=int(n);
            } else throw std::runtime_error("unknown option: "+a);
        }
        Key key=parse_key(hex);
        if(!weak_key(key)) throw std::runtime_error("key does not satisfy all six weak-key conditions");
        if(start>=TOTAL || count==0 || count>TOTAL-start || chunk==0)
            throw std::runtime_error("invalid enumeration range / chunk size");
        CUDA(cudaSetDevice(device));
        cudaDeviceProp prop{}; CUDA(cudaGetDeviceProperties(&prop,device));
        const int blocks=prop.multiProcessorCount*32;
        unsigned* result=nullptr; CUDA(cudaMalloc(&result,sizeof(unsigned)));
        self_test(key,blocks,result);
        if(!only_test) {
            State s=initial(key);
            for(uint64_t offset=0;offset<count;) {
                const uint64_t n=chunk<count-offset ? chunk : count-offset;
                auto begin=std::chrono::steady_clock::now();
                unsigned parity=sum(s,start+offset,n,blocks,result);
                double seconds=std::chrono::duration<double>(std::chrono::steady_clock::now()-begin).count();
                std::cout<<"{\"start\":"<<start+offset<<",\"count\":"<<n
                    <<",\"xor\":"<<parity<<",\"seconds\":"<<std::setprecision(10)<<seconds<<"}"<<std::endl;
                offset+=n;
            }
        }
        CUDA(cudaFree(result));
        return 0;
    } catch(const std::exception& e) { std::cerr<<"ERROR: "<<e.what()<<"\n"; return 1; }
}
