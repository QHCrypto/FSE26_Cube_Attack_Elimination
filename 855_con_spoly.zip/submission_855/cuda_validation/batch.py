#!/usr/bin/env python3
"""Verify random weak keys; write only per-key results and a summary."""
import argparse
from pathlib import Path
import sys

import run as single

DEFAULT_DIR = single.HERE / "runs/weakkeys_50"
DEFAULT_COUNT = 50


def sample_keys(count):
    keys, seen = [], set()
    while len(keys) < count:
        key = single.random_weak_key()
        if key not in seen:
            keys.append(key)
            seen.add(key)
    return keys


def run_batch(directory, keys, predictions, args):
    rows = [{"key": key.hex(), "time_seconds": 0.0, "cube_sum": None,
             "superpoly_value": prediction["value"]}
            for key, prediction in zip(keys, predictions)]
    single.save_summary(directory, rows)
    try:
        for index, key in enumerate(keys):
            row = single.compute_cube_sum(key, predictions[index]["value"], args)
            key_directory = directory / f"key_{index+1:02d}"
            key_directory.mkdir()
            single.atomic_json(key_directory / "result.json", row)
            rows[index] = row
            single.print_result(row)
            single.save_summary(directory, rows)
    finally:
        summary = single.save_summary(directory, rows)
        single.print_summary(summary)
    return summary


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=["run"], nargs="?", default="run")
    parser.add_argument("--batch-dir", type=Path, default=DEFAULT_DIR)
    parser.add_argument("--count", type=int, default=DEFAULT_COUNT)
    single.add_compute_arguments(parser)
    args = parser.parse_args()
    try:
        if args.count < 1:
            raise ValueError("count must be positive")
        single.configure(args)
        directory = args.batch_dir.resolve()
        if directory.exists():
            raise ValueError(f"Output directory already exists; choose a new directory: {directory}")
        keys = sample_keys(args.count)
        predictions = single.evaluate_references(keys)
        single.create_directory(directory)
        run_batch(directory, keys, predictions, args)
        return 0
    except KeyboardInterrupt:
        print("Interrupted; completed results are saved. Start unfinished calculations again.", file=sys.stderr)
        return 130
    except (OSError, ValueError, KeyError, TypeError) as error:
        print("ERROR:", error, file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
