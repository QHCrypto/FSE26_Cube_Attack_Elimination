#include "trivium_core.h"
#include <iostream>
#include <random>
using namespace trivium;
void check(bool ok,const char* what) { if(!ok) throw std::runtime_error(what); }
int main() {
    try {
        std::mt19937_64 rng(20260926);
        Key k{};
        k[0]=1; check(bit(k,0)==1 && bit(k,7)==0,"k0 order");
        check(initial(k).a1==(uint64_t{1}<<28),"s0 placement");
        k[0]=128; check(bit(k,0)==0 && bit(k,7)==1,"k7 order");
        for(int j=0;j<DIM;++j) {
            auto iv=cube_iv(uint64_t{1}<<j);
            State s; deposit_iv(s,uint64_t{1}<<j);
            State ref=initial(Key{},iv);
            check(s.b0==ref.b0 && s.b1==ref.b1,"cube IV deposit");
        }
        for(int n=0;n<160;++n) {
            Key key{},iv{};
            for(auto& b:key) b=rng();
            for(auto& b:iv) b=rng();
            for(int rounds : {0,1,23,31,32,33,64,69,83,832,854,855,856,1152}) {
                State s=initial(key,iv);
                for(int j=0;j<rounds/32;++j) step<32>(s);
                for(int j=0;j<rounds%32;++j) step<1>(s);
                check(output(s)==scalar(key,iv,rounds),"packed vs scalar arbitrary rounds/IV");
            }
            auto counter=rng()&(TOTAL-1);
            check(packed855(initial(key),counter)==scalar(key,cube_iv(counter)),"855 packed counter");
        }
        for(auto& b:k) b=rng();
        unsigned reference=0,packed=0,left=0,right=0;
        for(uint64_t i=0;i<1024;++i) {
            auto value=packed855(initial(k),i);
            check(value==scalar(k,cube_iv(i)),"small cube per-IV");
            reference^=scalar(k,cube_iv(i)); packed^=value;
            (i<379?left:right)^=value;
        }
        check(reference==packed && packed==(left^right),"partition parity");
        std::cout<<"PASS: key/IV bit order, cube mapping, random keys/IVs, round boundaries,\n"
                 <<"855-round outputs, full 10-dimensional subcube and partition parity.\n";
    } catch(const std::exception& e) { std::cerr<<e.what()<<"\n"; return 1; }
}
