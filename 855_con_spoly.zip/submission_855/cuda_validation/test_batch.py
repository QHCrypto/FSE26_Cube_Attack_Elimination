import contextlib
import csv
import io
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import batch
import run as single


class BatchTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.directory = self.root/"experiment"
        self.binary = self.root/"binary_fixture"
        self.binary.write_bytes(b"protocol fixture; not a cipher implementation")
        self.polynomial = self.root/"polynomial.txt"
        self.polynomial.write_text("1*(k0)\n")
        self.keys = [bytes(10), bytes([1]+[0]*9), bytes([2]+[0]*9)]
        self.argv = ["batch.py", "--count", "3", "--batch-dir", str(self.directory),
                     "--binary", str(self.binary)]

    def execute(self, worker):
        self.output, self.errors = io.StringIO(), io.StringIO()
        with patch("sys.argv", self.argv), \
             patch.object(single, "REFERENCE_POLYNOMIAL", self.polynomial), \
             patch.object(single, "random_weak_key", side_effect=self.keys), \
             patch.object(single, "compute_cube_sum", side_effect=worker), \
             contextlib.redirect_stdout(self.output), contextlib.redirect_stderr(self.errors):
            return batch.main()

    def files(self):
        return {str(p.relative_to(self.directory)) for p in self.directory.rglob('*') if p.is_file()}

    def test_only_requested_files_and_mismatches_continue(self):
        visited = []
        def worker(key, prediction, args):
            visited.append(key)
            return {"key":key.hex(), "time_seconds":1.25, "cube_sum":1,
                    "superpoly_value":prediction}
        self.assertEqual(self.execute(worker), 0)
        self.assertEqual(visited, self.keys)
        self.assertEqual(self.files(), {"key_01/result.json", "key_02/result.json", "key_03/result.json",
                                       "summary.json", "summary.csv"})
        summary = json.loads((self.directory/"summary.json").read_text())
        self.assertEqual((summary["completed"], summary["matched"], summary["mismatched"]), (3,1,2))
        self.assertAlmostEqual(summary["match_rate_percent"], 100/3)
        self.assertEqual(self.output.getvalue().splitlines()[-1],
                         "Summary: completed=3/3 matched=1/3 match_rate=33.33%")
        self.assertEqual(len(self.output.getvalue().splitlines()), 4)
        for index in range(3):
            row = json.loads((self.directory/f"key_{index+1:02d}/result.json").read_text())
            self.assertEqual(set(row), set(single.RESULT_FIELDS))
            self.assertEqual(row, summary["keys"][index])
        rows = list(csv.DictReader(io.StringIO((self.directory/"summary.csv").read_text())))
        self.assertEqual(list(rows[0]), single.RESULT_FIELDS)

    def test_interruption_saves_completed_keys_without_partial_result(self):
        def worker(key, prediction, args):
            if key == self.keys[1]:
                raise KeyboardInterrupt
            return {"key":key.hex(), "time_seconds":0.5, "cube_sum":prediction,
                    "superpoly_value":prediction}
        self.assertEqual(self.execute(worker), 130)
        self.assertEqual(self.files(), {"key_01/result.json", "summary.json", "summary.csv"})
        summary = json.loads((self.directory/"summary.json").read_text())
        self.assertEqual((summary["count"],summary["completed"],summary["compared"]), (3,1,1))
        self.assertEqual(summary["match_rate_percent"], 100.0)
        self.assertIsNone(summary["all_match"])
        self.assertIsNone(summary["keys"][1]["cube_sum"])
        self.assertEqual(self.output.getvalue().splitlines()[-1],
                         "Summary: completed=1/3 matched=1/1 match_rate=100.00%")

    def test_execution_error_does_not_publish_a_cube_sum(self):
        def worker(key, prediction, args):
            raise ValueError("CUDA enumeration incomplete")
        self.assertEqual(self.execute(worker), 1)
        self.assertEqual(self.files(), {"summary.json", "summary.csv"})
        summary = json.loads((self.directory/"summary.json").read_text())
        self.assertEqual(summary["completed"], 0)
        self.assertIsNone(summary["match_rate_percent"])
        self.assertTrue(all(row["cube_sum"] is None for row in summary["keys"]))

    def test_existing_output_directory_is_preserved(self):
        self.directory.mkdir()
        original = self.directory/"result.json"
        original.write_text("existing experiment")
        self.assertEqual(self.execute(lambda *args:self.fail("must not compute")), 1)
        self.assertEqual(original.read_text(), "existing experiment")
        self.assertIn("already exists", self.errors.getvalue())
        self.assertEqual(self.files(), {"result.json"})

    def test_sampling_excludes_duplicate_keys(self):
        with patch.object(single, "random_weak_key", side_effect=[self.keys[0],self.keys[0],*self.keys[1:]]):
            self.assertEqual(batch.sample_keys(3), self.keys)


if __name__ == "__main__":
    unittest.main()
