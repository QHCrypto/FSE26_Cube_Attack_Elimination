import contextlib
import io
import json
import re
import tempfile
from types import SimpleNamespace
import unittest
from pathlib import Path
from unittest.mock import patch
import run

class Tests(unittest.TestCase):
    def test_uniform_weak_key_completion_and_basis(self):
        for _ in range(1000):
            key = run.random_weak_key()
            k = run.key_bits(key)
            self.assertEqual(run.condition_values(k),[0]*6)
            self.assertEqual([run.basis_z83(k)[i] for i in run.CONDITION_IDS],[0]*6)
        raw = bytes.fromhex("0123456789abcdef0123")
        with patch.object(run.secrets,"token_bytes",return_value=raw):
            k = run.key_bits(run.random_weak_key())
        for i in set(range(80))-{9,11,60,61,62,63}:
            self.assertEqual(k[i],run.key_bits(raw)[i])

    def test_byte_order(self):
        self.assertEqual(run.key_bits(bytes([1]+[0]*9)),[1]+[0]*79)
        k=run.key_bits(bytes([128]+[0]*8+[128]))
        self.assertEqual([i for i,b in enumerate(k) if b],[7,79])

    def test_cuda_cube_matches_driver_and_recovery(self):
        header=(run.HERE/"trivium_core.h").read_text()
        content=re.search(r"CUBE\[DIM\] = \{([^}]+)\}",header).group(1)
        self.assertEqual([int(i) for i in re.findall(r"\d+",content)],run.CUBE)
        recovery = (run.HERE.parent / "recovery855.cpp").read_text()
        content = re.search(r"cube_ids\s*=\s*\{([^}]+)\}", recovery).group(1)
        self.assertEqual([int(i) for i in re.findall(r"\d+", content)], run.CUBE)
        self.assertEqual(len(set(run.CUBE)),45)

    def test_reference_evaluation_accepts_metadata_and_evaluates_keys_in_parallel(self):
        keys = [bytes(10), bytes([1]+[0]*9)]
        with tempfile.TemporaryDirectory() as name:
            path = Path(name) / "polynomial.txt"
            path.write_text("header\n1*(z80z81+z0+z137+1+z0+z0+0)\nstatus: complete\n")
            with patch.object(run, "REFERENCE_POLYNOMIAL", path):
                refs = run.evaluate_references(keys)
                self.assertEqual([r["value"] for r in refs], [1, 0])
                self.assertEqual([r["file_term_count"] for r in refs], [6, 6])
                self.assertEqual(run.evaluate_reference(keys[1]), refs[1])
                for expression in ("1*()", "1*(k153)", "1*(k0+)\n", "1*(k0)\n1*(k1)"):
                    path.write_text(expression)
                    with self.assertRaises(ValueError):
                        run.evaluate_reference(keys[0])
                path.write_text("1*(1)\n")
                invalid = bytearray(10)
                invalid[7] = 1 << 5  # k61 violates the condition.
                with self.assertRaises(ValueError):
                    run.evaluate_reference(bytes(invalid))

    def protocol(self, records, returncode=0):
        # Deterministic subprocess messages test the protocol, not cipher results.
        process = SimpleNamespace(stdout=io.StringIO("".join(json.dumps(r)+"\n" for r in records)),
                                  wait=lambda:returncode, poll=lambda:returncode)
        args = SimpleNamespace(binary=Path("/tmp/cuda_protocol_fixture"), chunk_log2=10, device=0)
        with patch.object(run, "TOTAL", 2048), patch.object(run.subprocess, "Popen", return_value=process):
            return run.compute_cube_sum(bytes(10), 0, args)

    def test_full_enumeration_parity_and_time(self):
        row = self.protocol([{"start":0,"count":1024,"xor":1,"seconds":0.25},
                             {"start":1024,"count":1024,"xor":1,"seconds":0.5}])
        self.assertEqual(row, {"key":"00"*10, "time_seconds":0.75,
                               "cube_sum":0, "superpoly_value":0})

    def test_incomplete_invalid_and_failed_streams_are_rejected(self):
        first = {"start":0,"count":1024,"xor":1,"seconds":0.25}
        second = {"start":1024,"count":1024,"xor":1,"seconds":0.5}
        cases = [[first], [first, first], [dict(first, start=1), second],
                 [dict(first, count=2048)], [dict(first, xor=2), second],
                 [dict(first, seconds=-1), second], [dict(first, seconds=float("nan")), second],
                 [first, second, second]]
        for records in cases:
            with self.subTest(records=records), self.assertRaises(ValueError):
                self.protocol(records)
        with self.assertRaisesRegex(ValueError, "exited with code"):
            self.protocol([first, second], returncode=1)

    def test_single_cli_writes_only_result_and_summaries(self):
        # A small fake executable exercises real subprocess I/O and file output.
        with tempfile.TemporaryDirectory() as name:
            temp = Path(name)
            binary = temp/"fake_cuda.py"
            binary.write_text("""#!/usr/bin/env python3
import argparse, json
p=argparse.ArgumentParser()
p.add_argument('--count', type=int)
p.add_argument('--chunk-size', type=int)
a,_=p.parse_known_args()
for start in range(0,a.count,a.chunk_size):
    print(json.dumps({'start':start,'count':min(a.chunk_size,a.count-start),'xor':1,'seconds':0.25}),flush=True)
""")
            binary.chmod(0o755)
            polynomial = temp/"polynomial.txt"
            polynomial.write_text("1*(0)\n")
            directory = temp/"experiment"
            argv = ["run.py", "--run-dir", str(directory), "--binary", str(binary),
                    "--key-hex", "00"*10, "--chunk-log2", "10"]
            output = io.StringIO()
            with patch.object(run, "TOTAL", 2048), patch.object(run, "REFERENCE_POLYNOMIAL", polynomial), \
                 patch("sys.argv", argv), contextlib.redirect_stdout(output):
                self.assertEqual(run.main(), 0)
            self.assertEqual({str(p.relative_to(directory)) for p in directory.rglob('*') if p.is_file()},
                             {"result.json", "summary.json", "summary.csv"})
            row = json.loads((directory/"result.json").read_text())
            self.assertEqual(set(row), set(run.RESULT_FIELDS))
            self.assertEqual(row["time_seconds"], 0.5)
            self.assertEqual(row["cube_sum"], 0)
            self.assertEqual(len(output.getvalue().splitlines()), 2)
            summary = json.loads((directory/"summary.json").read_text())
            self.assertEqual(summary["match_rate_percent"], 100.0)
            self.assertEqual(summary["keys"], [row])

if __name__ == "__main__":
    unittest.main()
