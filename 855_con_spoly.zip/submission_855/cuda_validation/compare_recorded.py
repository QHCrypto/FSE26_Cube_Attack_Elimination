#!/usr/bin/env python3
"""Compare historical complete CUDA cube sums with the bundled z83 polynomial."""
import argparse
import csv
import math
import json
from pathlib import Path
import sys

import run as single


def load_records(directory):
    paths = sorted(directory.glob("key_*/result.json"))
    if not paths:
        raise ValueError("No per-key result.json files found")
    keys, results = [], []
    for path in paths:
        row = json.loads(path.read_text())
        if set(row) != set(single.RESULT_FIELDS):
            raise ValueError(f"Unexpected result fields: {path}")
        key = bytes.fromhex(row["key"])
        if (key in keys or any(single.condition_values(single.key_bits(key)))
                or not math.isfinite(row["time_seconds"]) or row["time_seconds"] < 0
                or row["cube_sum"] not in (0, 1) or row["superpoly_value"] not in (0, 1)):
            raise ValueError(f"Invalid or incomplete recorded result: {path}")
        keys.append(key)
        results.append(row)
    return keys, results


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--recorded-dir", type=Path, default=single.HERE / "recorded_results")
    parser.add_argument("--polynomial", type=Path, help="Defaults to ../results/superpoly_z83.txt")
    parser.add_argument("--output", type=Path, help="Write a new CSV; refuses to overwrite an existing file")
    parser.add_argument("--json-output", type=Path, help="Write a new JSON summary; refuses to overwrite an existing file")
    args = parser.parse_args()
    try:
        if args.polynomial is not None:
            single.REFERENCE_POLYNOMIAL = args.polynomial.resolve()
        keys, results = load_records(args.recorded_dir)
        predictions = single.evaluate_references(keys)
        rows = [{"key": key.hex(), "time_seconds": result["time_seconds"],
                 "cube_sum": result["cube_sum"], "superpoly_value": prediction["value"]}
                for key, result, prediction in zip(keys, results, predictions)]
        summary = single.comparison_summary(rows)
        if args.output is not None:
            with args.output.open("x", newline="") as stream:
                writer = csv.DictWriter(stream, fieldnames=single.RESULT_FIELDS)
                writer.writeheader()
                writer.writerows(rows)
        if args.json_output is not None:
            with args.json_output.open("x") as stream:
                json.dump(dict(summary, keys=rows), stream, indent=2)
                stream.write("\n")
        for row in rows:
            single.print_result(row)
        single.print_summary(summary)
        return 0 if summary["all_match"] else 1
    except (OSError, ValueError, KeyError, TypeError) as error:
        parser.exit(1, f"Error: {error}\n")


if __name__ == "__main__":
    raise SystemExit(main())
