#pragma once
#include <array>
#include <cstdint>
#include <stdexcept>
#include <string>

#ifdef __CUDACC__
#define HD __host__ __device__ __forceinline__
#else
#define HD inline
#endif

namespace trivium {
constexpr int ROUNDS = 855;
constexpr int DIM = 45;
constexpr uint64_t TOTAL = uint64_t{1} << DIM;
// Sorted I4 from Appendix G. Counter bit j supplies IV[CUBE[j]].
constexpr int CUBE[DIM] = {
    0,1,2,3,5,7,9,10,11,12,13,14,16,18,20,22,24,27,29,31,33,35,37,
    39,42,44,46,48,50,52,54,57,59,61,63,65,67,68,69,70,72,74,76,78,79
};
using Key = std::array<uint8_t, 10>;
inline unsigned bit(const Key& k, int i) { return (k[i/8] >> (i%8)) & 1; }
inline std::array<unsigned, 6> conditions(const Key& k) {
    return {bit(k,61), bit(k,63), bit(k,35) ^ (bit(k,60)&bit(k,61)) ^ bit(k,62),
        bit(k,33) ^ (bit(k,58)&bit(k,59)) ^ bit(k,60),
        bit(k,11) ^ (bit(k,36)&bit(k,37)) ^ bit(k,38),
        bit(k,9) ^ (bit(k,34)&bit(k,35)) ^ bit(k,36)};
}
inline bool weak_key(const Key& k) {
    for (auto x : conditions(k)) if (x) return false;
    return true;
}
inline Key parse_key(const std::string& s) {
    if (s.size() != 20 || s.find_first_not_of("0123456789abcdefABCDEF") != std::string::npos)
        throw std::runtime_error("key must be exactly 20 hexadecimal digits, bytes key[0]..key[9]");
    Key k{};
    for (int i=0; i<10; ++i) k[i] = static_cast<uint8_t>(std::stoul(s.substr(2*i,2),nullptr,16));
    return k;
}

// Independent, deliberately literal reference: index i is paper state s_i.
inline unsigned scalar(const Key& key, const Key& iv, int rounds=ROUNDS) {
    std::array<uint8_t,288> s{};
    for (int i=0;i<80;++i) { s[i]=bit(key,i); s[93+i]=bit(iv,i); }
    s[285]=s[286]=s[287]=1;
    for (int r=0;r<rounds;++r) {
        const unsigned a=s[65]^(s[90]&s[91])^s[92]^s[170];
        const unsigned b=s[161]^(s[174]&s[175])^s[176]^s[263];
        const unsigned c=s[242]^(s[285]&s[286])^s[287]^s[68];
        for (int i=287;i>0;--i) s[i]=s[i-1];
        s[0]=c; s[93]=a; s[177]=b;
    }
    return s[65]^s[92]^s[161]^s[176]^s[242]^s[287];
}
inline Key cube_iv(uint64_t counter) {
    Key iv{};
    for (int j=0;j<DIM;++j) iv[CUBE[j]/8] |= ((counter>>j)&1) << (CUBE[j]%8);
    return iv;
}

// For each register the OLDEST bit is packed at bit 0. This is only an
// internal representation; external key/IV bit numbering never changes.
struct State { uint64_t a0=0,a1=0,b0=0,b1=0,c0=7,c1=0; };
inline State initial(const Key& key, const Key& iv={}) {
    State s;
    for (int i=0;i<80;++i) {
        int p=92-i;
        (p<64?s.a0:s.a1) |= uint64_t(bit(key,i)) << (p%64);
        p=83-i;
        (p<64?s.b0:s.b1) |= uint64_t(bit(iv,i)) << (p%64);
    }
    return s;
}
template<int J=0> HD void deposit_iv(State& s, uint64_t counter) {
    if constexpr (J<DIM) {
        constexpr int pos=83-CUBE[J];
        if constexpr (pos<64) s.b0 |= ((counter>>J)&1) << pos;
        else s.b1 |= ((counter>>J)&1) << (pos-64);
        deposit_iv<J+1>(s,counter);
    }
}
template<int P> HD uint32_t window(uint64_t lo,uint64_t hi) {
    if constexpr (P==0) return uint32_t(lo);
    else if constexpr (P<=32) return uint32_t(lo>>P);
    else return uint32_t((lo>>P)|(hi<<(64-P)));
}
template<int LENGTH,int N> HD void advance(uint64_t& lo,uint64_t& hi,uint32_t f) {
    static_assert(N>0 && N<=32);
    if constexpr (N<32) f &= (uint32_t{1}<<N)-1;
    lo=(lo>>N)|(hi<<(64-N));
    hi>>=N;
    constexpr int pos=LENGTH-N;
    if constexpr (pos<64) {
        lo |= uint64_t(f)<<pos;
        hi |= uint64_t(f)>>(64-pos);
    } else hi |= uint64_t(f)<<(pos-64);
}
// All feedback taps are >=65 positions from their register's input.
// Thus 32 consecutive feedback bits depend only on the old state; wordwise
// AND/XOR performs 32 exact rounds together (no approximation / key elimination).
template<int N> HD void step(State& s) {
    const uint32_t a=window<27>(s.a0,s.a1)^window<0>(s.a0,s.a1)
        ^(window<2>(s.a0,s.a1)&window<1>(s.a0,s.a1))^window<6>(s.b0,s.b1);
    const uint32_t b=window<15>(s.b0,s.b1)^window<0>(s.b0,s.b1)
        ^(window<2>(s.b0,s.b1)&window<1>(s.b0,s.b1))^window<24>(s.c0,s.c1);
    const uint32_t c=window<45>(s.c0,s.c1)^window<0>(s.c0,s.c1)
        ^(window<2>(s.c0,s.c1)&window<1>(s.c0,s.c1))^window<24>(s.a0,s.a1);
    advance<93,N>(s.a0,s.a1,c);
    advance<84,N>(s.b0,s.b1,a);
    advance<111,N>(s.c0,s.c1,b);
}
HD unsigned output(const State& s) {
    return unsigned(((s.a0>>27)^s.a0^(s.b0>>15)^s.b0^(s.c0>>45)^s.c0)&1);
}
HD unsigned packed855(State s,uint64_t counter) {
    deposit_iv(s,counter);
    #ifdef __CUDACC__
    #pragma unroll
    #endif
    for (int i=0;i<26;++i) step<32>(s); // 832 rounds
    step<23>(s);                       // exactly 855 updates
    return output(s);                  // read BEFORE update 856
}
} // namespace trivium
