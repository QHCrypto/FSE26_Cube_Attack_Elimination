#!/usr/bin/env python3
"""Compute one complete CUDA cube sum and write only results and summaries."""
import argparse
import csv
import hashlib
import io
import json
import math
import os
from pathlib import Path
import re
import secrets
import subprocess
import sys
import tempfile

HERE = Path(__file__).resolve().parent
REFERENCE_POLYNOMIAL = HERE.parent / "results/superpoly_z83.txt"
CUBE = [0,1,2,3,5,7,9,10,11,12,13,14,16,18,20,22,24,27,29,31,33,35,37,
        39,42,44,46,48,50,52,54,57,59,61,63,65,67,68,69,70,72,74,76,78,79]
TOTAL = 1 << 45
CONDITION_IDS = [61,63,100,102,124,126]
RESULT_FIELDS = ["key", "time_seconds", "cube_sum", "superpoly_value"]

def key_bits(key):
    if len(key) != 10:
        raise ValueError("Key must be exactly 10 bytes")
    return [(key[i//8] >> (i%8)) & 1 for i in range(80)]

def condition_values(k):
    return [k[61], k[63], k[35] ^ (k[60]&k[61]) ^ k[62],
            k[33] ^ (k[58]&k[59]) ^ k[60],
            k[11] ^ (k[36]&k[37]) ^ k[38], k[9] ^ (k[34]&k[35]) ^ k[36]]

def random_weak_key():
    k = key_bits(secrets.token_bytes(10))
    # The other 74 independent bits remain uniform. Each has one completion.
    k[61] = k[63] = 0
    k[62] = k[35]
    k[60] = k[33] ^ (k[58]&k[59])
    k[11] = (k[36]&k[37]) ^ k[38]
    k[9] = (k[34]&k[35]) ^ k[36]
    assert condition_values(k) == [0]*6
    return bytes(sum(k[8*j+t] << t for t in range(8)) for j in range(10))

def basis_z83(k):
    """Matches the author's calculate_balance.cpp, lines 65-89 (z_0..z_152)."""
    z = list(k) + [0]*73
    z[80], z[81] = k[67]^1, k[66]^1
    z[82] = k[53] ^ (k[78]&k[79])
    for i in range(83,136):
        z[i] = k[135-i] ^ (k[160-i]&k[161-i]) ^ k[162-i]
    for i in range(136,153):
        z[i] = (k[160-i]&k[161-i]) ^ k[162-i]
        if i in (137,138):
            z[i] ^= z[i-57]
        else:
            z[i] ^= k[204-i]
            if i >= 148:
                z[i] ^= k[213-i]
    return z

def source_polynomial():
    if not REFERENCE_POLYNOMIAL.is_file():
        raise ValueError(f"Reference polynomial not found: {REFERENCE_POLYNOMIAL}")
    return REFERENCE_POLYNOMIAL

def evaluate_references(keys):
    """Evaluate one polynomial for all keys, using one Python integer per variable.

    Bit j of each integer is the value for key j. This shares the parsing work
    across recorded samples without expanding the polynomial into physical keys.
    """
    keys = list(keys)
    if not keys:
        raise ValueError("At least one key is required")
    bases = [basis_z83(key_bits(key)) for key in keys]
    if any(z[i] for z in bases for i in CONDITION_IDS):
        raise ValueError("A key does not satisfy the six z83 conditions")
    path = source_polynomial()
    raw = path.read_bytes()
    expressions = [line.strip() for line in raw.decode("ascii").splitlines()
                   if line.strip().startswith("1*(")]
    if len(expressions) != 1 or not expressions[0].endswith(")"):
        raise ValueError("Expected exactly one 1*(...) polynomial expression")
    expression = expressions[0]
    variables = [sum(z[i] << j for j, z in enumerate(bases)) for i in range(153)]
    all_keys = (1 << len(keys)) - 1
    parity, terms = 0, 0
    for term in expression[3:-1].split("+"):
        if term == "0":
            continue
        value = all_keys
        if term != "1":
            if not re.fullmatch(r"(?:[kz][0-9]+)+", term):
                raise ValueError("Malformed polynomial monomial")
            for index in re.findall(r"[kz]([0-9]+)", term):
                index = int(index)
                if index >= len(variables):
                    raise ValueError("Expected z83 variables with indices 0..152")
                value &= variables[index]
        parity ^= value
        terms += 1
    digest = hashlib.sha256(raw).hexdigest()
    return [{"value": (parity >> j) & 1, "method": "recovered_z83_superpoly_evaluation",
            "source": str(path), "source_sha256": digest,
            "file_term_count": terms,
            "note": "Prediction; compare with an independent complete 2^45-IV cube sum."}
            for j in range(len(keys))]

def evaluate_reference(key):
    return evaluate_references([key])[0]

def comparison_summary(rows):
    completed = sum(row["cube_sum"] is not None for row in rows)
    compared = [row for row in rows
                if row["cube_sum"] is not None and row["superpoly_value"] is not None]
    matched = sum(row["cube_sum"] == row["superpoly_value"] for row in compared)
    count = len(rows)
    return {"count": count, "completed": completed, "compared": len(compared),
            "matched": matched, "mismatched": len(compared) - matched,
            "match_rate": matched / len(compared) if compared else None,
            "match_rate_percent": 100 * matched / len(compared) if compared else None,
            "all_match": matched == count if len(compared) == count and count else None}

def print_result(row):
    cube_sum = row["cube_sum"] if row["cube_sum"] is not None else "N/A"
    superpoly = row["superpoly_value"] if row["superpoly_value"] is not None else "N/A"
    print(f"key={row['key']} time_seconds={row['time_seconds']:.3f} "
          f"cube_sum={cube_sum} superpoly_value={superpoly}", flush=True)

def print_summary(summary):
    rate = f"{summary['match_rate']:.2%}" if summary["match_rate"] is not None else "N/A"
    print(f"Summary: completed={summary['completed']}/{summary['count']} "
          f"matched={summary['matched']}/{summary['compared']} match_rate={rate}", flush=True)

def atomic_text(path, text):
    fd, temporary = tempfile.mkstemp(prefix=".result-", dir=path.parent)
    try:
        with os.fdopen(fd, "w") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def atomic_json(path, data):
    atomic_text(path, json.dumps(data, indent=2) + "\n")


def save_summary(directory, rows):
    summary = dict(comparison_summary(rows), keys=rows)
    atomic_json(directory / "summary.json", summary)
    stream = io.StringIO(newline="")
    writer = csv.DictWriter(stream, fieldnames=RESULT_FIELDS)
    writer.writeheader()
    writer.writerows(rows)
    atomic_text(directory / "summary.csv", stream.getvalue())
    return summary


def compute_cube_sum(key, prediction, args):
    """Accept only a successful, contiguous enumeration of all 2^45 IVs."""
    command = [str(args.binary.resolve()), "--key-hex", key.hex(),
               "--start", "0", "--count", str(TOTAL),
               "--chunk-size", str(1 << args.chunk_log2), "--device", str(args.device)]
    process = subprocess.Popen(command, stdout=subprocess.PIPE, text=True, bufsize=1)
    processed, parity, seconds = 0, 0, 0.0
    try:
        for line in process.stdout:
            record = json.loads(line)
            expected = min(1 << args.chunk_log2, TOTAL - processed)
            if (expected <= 0 or record["start"] != processed or record["count"] != expected
                    or record["xor"] not in (0, 1)
                    or not math.isfinite(record["seconds"]) or record["seconds"] < 0):
                raise ValueError("Invalid CUDA chunk range or result")
            processed += record["count"]
            parity ^= record["xor"]
            seconds += record["seconds"]
        code = process.wait()
        if code:
            raise ValueError(f"CUDA executable exited with code {code}")
        if processed != TOTAL:
            raise ValueError("CUDA enumeration is incomplete; no result was saved")
    finally:
        if process.poll() is None:
            process.terminate()
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait()
        process.stdout.close()
    return {"key": key.hex(), "time_seconds": seconds, "cube_sum": parity,
            "superpoly_value": prediction}


def add_compute_arguments(parser):
    parser.add_argument("--device", type=int, default=0)
    parser.add_argument("--chunk-log2", type=int, default=24, choices=range(10, 31), metavar="10..30")
    parser.add_argument("--binary", type=Path, default=HERE / "cube855")
    parser.add_argument("--polynomial", type=Path, help="Defaults to ../results/superpoly_z83.txt")


def configure(args):
    global REFERENCE_POLYNOMIAL
    if args.device < 0:
        raise ValueError("device must be nonnegative")
    if not args.binary.is_file():
        raise ValueError("CUDA executable not found; run make -C cuda_validation first")
    if args.polynomial is not None:
        REFERENCE_POLYNOMIAL = args.polynomial.resolve()


def create_directory(directory):
    try:
        directory.mkdir(parents=True, exist_ok=False)
    except FileExistsError:
        raise ValueError(f"Output directory already exists; choose a new directory: {directory}") from None


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=["run"], nargs="?", default="run")
    parser.add_argument("--run-dir", type=Path, default=HERE / "runs/weakkey_001")
    parser.add_argument("--key-hex", help="10-byte weak key; randomly generated if omitted")
    add_compute_arguments(parser)
    args = parser.parse_args()
    try:
        configure(args)
        key = bytes.fromhex(args.key_hex) if args.key_hex is not None else random_weak_key()
        prediction = evaluate_reference(key)["value"]
        directory = args.run_dir.resolve()
        create_directory(directory)
        rows = [{"key": key.hex(), "time_seconds": 0.0, "cube_sum": None,
                 "superpoly_value": prediction}]
        save_summary(directory, rows)
        try:
            rows[0] = compute_cube_sum(key, prediction, args)
            atomic_json(directory / "result.json", rows[0])
            print_result(rows[0])
        finally:
            print_summary(save_summary(directory, rows))
        return 0 if rows[0]["cube_sum"] == prediction else 1
    except KeyboardInterrupt:
        print("Interrupted; completed results are saved. Start unfinished calculations again.", file=sys.stderr)
        return 130
    except (OSError, ValueError, KeyError, TypeError) as error:
        print("ERROR:", error, file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
