#include <bitset>
#include <charconv>
#include <chrono>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <limits>
#include <set>
#include <stdexcept>
#include <string>
#include <string_view>
#include <system_error>
#include <utility>
#include <vector>
#include <unistd.h>

#include "log.h"
#include "triviumframework.h"
#include "main.h"
#include "recovery855.h"

using namespace std;
namespace fs = std::filesystem;

// Section 7.3: recover the 855-round conditional superpoly for cube I4.
int calculate_con_spoly855(const RecoveryOptions& options) {
    static_assert(N == 882, "855-round recovery requires N=882");
    static_assert(FASTBOUND == 225 && BASEROUND == 69 && OUTROUND == 83,
                  "Use the Section 7.3 round configuration");
    static_assert(POOL_SIZE == 2000000000, "Use the 2-billion solution pool");
    cout << "Recovering 855-round Trivium conditional superpoly: I4 (45 IV bits)\n"
         << "Conditions: z61=z63=z100=z102=z124=z126=0\n"
         << "FASTBOUND=225, BASEROUND=69, OUTROUND=83, N=882\n"
         << "Coefficient time limit: " << TIMELIMIT
         << " seconds at intermediate layers; infinity at OUTROUND; pool: " << POOL_SIZE
         << "; OpenMP threads: " << options.threads << endl;
    return run_recovery855(options);
}

// A part_spoly snapshot contains one coefficient polynomial and one trail count.
// All additions below are in GF(2), so repeated monomials cancel.
KVpoly read_part_spoly(const fs::path& polynomialPath) {
    ifstream savedFile(polynomialPath);
    if (!savedFile) throw RecoveryError("Cannot open " + polynomialPath.string());
    string expression;
    if (!getline(savedFile, expression))
        throw RecoveryError("Empty polynomial snapshot: " + polynomialPath.string());
    if (!expression.empty() && expression.back() == '\r') expression.pop_back();
    string metadata;
    if (!getline(savedFile, metadata))
        throw RecoveryError("Missing statistics line in " + polynomialPath.string());
    if (!metadata.empty() && metadata.back() == '\r') metadata.pop_back();
    if (metadata.empty() || metadata.find_first_not_of("0123456789") != string::npos)
        throw RecoveryError("Invalid statistics line in " + polynomialPath.string());
    string extra;
    while (getline(savedFile, extra)) {
        if (extra.find_first_not_of(" \t\r") != string::npos)
            throw RecoveryError("Expected one snapshot in " + polynomialPath.string());
    }
    if (savedFile.bad()) throw RecoveryError("Error reading " + polynomialPath.string());

    string_view body(expression);
    if (body.size() >= 5 && body.substr(0, 3) == "1*(" && body.back() == ')')
        body = body.substr(3, body.size() - 4);
    else if (body.substr(0, 2) == "1*") body.remove_prefix(2);
    else if (body != "0") throw RecoveryError("Unsupported saved polynomial format");
    Kpoly savedCoefficients;
    for (size_t pos = 0; pos < body.size();) {
        size_t end = body.find('+', pos);
        if (end == string_view::npos) end = body.size();
        string_view term = body.substr(pos, end - pos);
        if (term.empty()) throw RecoveryError("Empty saved polynomial term");
        if (term != "0") {
            Kmono mono;
            if (term != "1") {
                const char* q = term.data();
                const char* stop = q + term.size();
                while (q < stop) {
                    if (*q++ != 'k' || q == stop || *q < '0' || *q > '9')
                        throw RecoveryError("Invalid saved polynomial term");
                    int index = -1;
                    auto parsed = from_chars(q, stop, index);
                    if (parsed.ec != errc() || index < 0 || index >= N)
                        throw RecoveryError("Saved polynomial variable out of range");
                    mono.k.set(index);
                    q = parsed.ptr;
                }
            }
            auto inserted = savedCoefficients.p.insert(mono);
            if (!inserted.second) savedCoefficients.p.erase(inserted.first);
        }
        if (end == body.size()) break;
        pos = end + 1;
        if (pos == body.size()) throw RecoveryError("Trailing '+' in saved polynomial");
    }
    if (body.empty()) throw RecoveryError("Empty saved polynomial expression");
    KVpoly savedPolynomial;
    Vmono constantIV;
    if (!savedCoefficients.p.empty())
        savedPolynomial.p.emplace(constantIV, move(savedCoefficients));
    return savedPolynomial;
}

int resume_con_spoly855_165() {
    static_assert(N == 882, "855-round recovery requires N=882");
    static_assert(FASTBOUND == 225 && BASEROUND == 69 && OUTROUND == 83,
                  "Use the Section 7.3 round configuration");
    static_assert(POOL_SIZE == 2000000000, "Use the 2-billion solution pool");
    const int threads = 512;
    // Same I4 and ordering as the author's published polynomial filename.
    vector<int> cubeIndex = {
        1,3,5,7,9,12,14,16,18,20,22,24,27,29,31,33,35,37,39,42,
        44,46,48,50,52,54,57,59,61,63,65,67,72,74,76,78,70,68,
        0,69,2,11,10,13,79
    };
    vector<int> kid = {61,63,100,102,124,126};
    cout << "Resuming 855-round Trivium conditional superpoly at round 165: I4 (45 IV bits)\n"
         << "Conditions: z61=z63=z100=z102=z124=z126=0\n"
         << "FASTBOUND=225, BASEROUND=69, OUTROUND=83, N=882\n"
         << "Coefficient time limit: " << TIMELIMIT
         << " seconds at intermediate layers; infinity at OUTROUND; pool: " << POOL_SIZE
         << "; OpenMP threads: " << threads << endl;
    // Resume the original nested recovery at round 165. Paths are relative to
    // the directory from which a.out is started; existing input files are read-only.
    const int resumeRound = 165;
    const fs::path statesPath = "165_vts.log";
    const fs::path polynomialPath = "195_part_spoly.txt";
    auto begin = chrono::steady_clock::now();

    KVpoly savedPolynomial = read_part_spoly(polynomialPath);
    cout << "Loaded 195-round cumulative polynomial: "
         << (savedPolynomial.p.empty() ? 0 : savedPolynomial.p.begin()->second.p.size())
         << " monomials" << endl;

    ifstream stateFile(statesPath);
    if (!stateFile) throw RecoveryError("Cannot open " + statesPath.string());
    vector<bitset<288>> terms;
    terms.reserve(fs::file_size(statesPath) / 289);
    string line;
    size_t lineNumber = 0;
    while (getline(stateFile, line)) {
        ++lineNumber;
        if (!line.empty() && line.back() == '\r') line.pop_back();
        if (line.size() != 288 || line.find_first_not_of("01") != string::npos)
            throw RecoveryError("Invalid 165-round state at line " + to_string(lineNumber));
        // std::bitset text is s287 ... s0: the rightmost character is s0.
        terms.emplace_back(line);
    }
    if (stateFile.bad()) throw RecoveryError("Error reading " + statesPath.string());
    stateFile.close();
    cout << "Loaded " << terms.size() << " states from " << statesPath
         << "; continuing coefficient recovery at round " << resumeRound << endl;

    // Check licensing before submitting parallel coefficient tasks.
    { GRBEnv licenseCheck; }
    fs::create_directories("LOG");
    string foldername;
    for (int index : kid) foldername += "k" + to_string(index);
    fs::create_directories(foldername);
    string filename = foldername + "/dim" + to_string(cubeIndex.size());
    bitset<80> cube;
    for (int index : cubeIndex) {
        cube[index] = 1;
        filename += "v" + to_string(index);
    }
    // Probe the output before spending time on recovery.
    { ofstream check(filename, ios::app);
      if (!check) throw RecoveryError("Cannot write final output: " + filename); }

    KVpoly resumedPolynomial;
    std::uint64_t failedTerms = 0;
    logger("resume: coefficient recovery starts at round 165; states=" + to_string(terms.size()));
    // Existing 10-second limits and nested expansion; round 83 is unlimited.
    nest_coef(resumeRound, filename, cube, terms, resumedPolynomial, threads, kid, 0, &failedTerms);
    // The 195 snapshot already includes round 225. Add this snapshot exactly once.
    resumedPolynomial = resumedPolynomial + savedPolynomial;
    logger("resume: merged new coefficients with the saved 195-round cumulative polynomial");

    bitset<N> zeroKey;
    for (int index : kid) zeroKey[index] = 1;
    KVpoly result;
    substitute_kvpoly(result, resumedPolynomial, OUTROUND, FASTBOUND, zeroKey);
    ofstream output(filename, ios::app);
    if (!output) throw RecoveryError("Cannot write final output: " + filename);
    output << result << endl;
    output << "Failed coefficient items: " << failedTerms << endl;
    if (failedTerms != 0)
        output << "Status: PARTIAL (failed coefficient items require separate recovery)" << endl;
    output << "Resume from round: " << resumeRound << endl;
    output << "Resume time: "
           << chrono::duration<double>(chrono::steady_clock::now() - begin).count()
           << " seconds" << endl;
    output.close();
    if (!output) throw RecoveryError("Failed to save final output: " + filename);
    cout << (failedTerms == 0 ? "Resumed polynomial saved to " : "PARTIAL resumed polynomial saved to ")
         << filename << "; failed coefficient items=" << failedTerms << endl;
    logger("resume: final polynomial saved to " + filename);
    return 0;
}

// Recover only the five coefficient items excluded from the earlier 135-round run.
int recover_failed_135() {
    static_assert(N == 882 && FASTBOUND == 225 && BASEROUND == 69 && OUTROUND == 83,
                  "Use the same model as the original 855-round recovery");
    const fs::path failedPath = "135_coef_failed_states.log";
    ifstream failedFile(failedPath);
    if (!failedFile) throw RecoveryError("Cannot open " + failedPath.string());
    vector<bitset<288>> terms;
    set<string> seenStates;
    string line;
    size_t lineNumber = 0;
    while (getline(failedFile, line)) {
        ++lineNumber;
        if (!line.empty() && line.back() == '\r') line.pop_back();
        if (line.size() != 288 || line.find_first_not_of("01") != string::npos)
            throw RecoveryError("Invalid 135-round state at line " + to_string(lineNumber));
        if (!seenStates.insert(line).second)
            throw RecoveryError("Duplicate 135-round failed state at line " + to_string(lineNumber));
        // std::bitset text is s287 ... s0; the rightmost character is s0.
        terms.emplace_back(line);
    }
    if (failedFile.bad()) throw RecoveryError("Error reading " + failedPath.string());
    if (terms.size() != 5)
        throw RecoveryError("Expected exactly five 135-round failed states, found " + to_string(terms.size()));

    vector<int> cubeIndex = {
        1,3,5,7,9,12,14,16,18,20,22,24,27,29,31,33,35,37,39,42,
        44,46,48,50,52,54,57,59,61,63,65,67,72,74,76,78,70,68,
        0,69,2,11,10,13,79
    };
    vector<int> kid = {61,63,100,102,124,126};
    bitset<80> cube;
    for (int index : cubeIndex) cube[index] = 1;
    { GRBEnv licenseCheck; }

    // Keep all recovery snapshots, failed states and expansion logs separate
    // from the original run's files. Paths remain relative to the launch directory.
    const fs::path launchDirectory = fs::current_path();
    const string runId = to_string(chrono::system_clock::now().time_since_epoch().count())
                       + "_" + to_string(getpid());
    const fs::path runDirectory = fs::path("recover_failed_135") / ("run_" + runId);
    fs::create_directories("recover_failed_135");
    if (!fs::create_directory(runDirectory))
        throw RecoveryError("Recovery directory already exists: " + runDirectory.string());
    fs::create_directory(runDirectory / "LOG");

    KVpoly recovered;
    std::uint64_t newFailures = 0;
    cout << "Recovering " << terms.size() << " failed 135-round states in "
         << runDirectory << endl;
    try {
        fs::current_path(runDirectory);
        nest_coef(135, "recovery_summary.log", cube, terms, recovered,
                  512, kid, 0, &newFailures);
        fs::current_path(launchDirectory);
    } catch (...) {
        fs::current_path(launchDirectory);
        throw;
    }
    if (newFailures != 0)
        throw RecoveryError(to_string(newFailures) + " coefficient items still failed; see "
                            + runDirectory.string());
    for (const auto& entry : fs::directory_iterator(runDirectory)) {
        const string name = entry.path().filename().string();
        const string suffix = "timeout_states.log";
        if (name.size() >= suffix.size()
            && name.compare(name.size() - suffix.size(), suffix.size(), suffix) == 0
            && entry.is_regular_file() && entry.file_size() != 0)
            throw RecoveryError("Unrecovered expansion states remain in " + entry.path().string());
    }

    // Load large snapshots after the solver finishes so they do not consume
    // memory while Gurobi processes the five states.
    // The 195 snapshot already includes 225; the 135 snapshot already includes
    // the successful 165 and 135 contributions from the resumed run.
    KVpoly saved195 = read_part_spoly("195_part_spoly.txt");
    KVpoly saved135 = read_part_spoly("135_part_spoly.txt");
    KVpoly combined = saved195 + saved135;
    combined = combined + recovered;
    bitset<N> zeroKey;
    for (int index : kid) zeroKey[index] = 1;
    KVpoly result;
    substitute_kvpoly(result, combined, OUTROUND, FASTBOUND, zeroKey);

    string foldername;
    for (int index : kid) foldername += "k" + to_string(index);
    fs::create_directories(foldername);
    fs::path outputPath = foldername + "/dim" + to_string(cubeIndex.size());
    for (int index : cubeIndex) outputPath += "v" + to_string(index);
    outputPath += "_completed_135.txt";
    fs::path tempPath = outputPath.string() + ".tmp." + runId;
    {
        ofstream output(tempPath, ios::trunc);
        if (!output) throw RecoveryError("Cannot write " + tempPath.string());
        output << result << '\n';
        output << "Recovered 135-round coefficient items: " << terms.size() << '\n';
        output << "Additional coefficient failures: 0\n";
        output << "Sources: 195_part_spoly.txt, 135_part_spoly.txt, 135_coef_failed_states.log\n";
        output << "Recovery run: " << runDirectory.string() << '\n';
        output.close();
        if (!output) throw RecoveryError("Failed to save " + tempPath.string());
    }
    fs::rename(tempPath, outputPath);
    cout << "Completed polynomial saved to " << outputPath << endl;
    fs::create_directories("LOG");
    logger("135-round failed items recovered; completed polynomial saved to " + outputPath.string());
    return 0;
}

int main(int argc, char** argv) {
    try {
        const auto usage = [&] {
            cout << "Usage: " << argv[0]
                 << " [--checkpoint-dir DIR] [--threads N] [--batch-size N]\n"
                 << "Default: recover I4, resume checkpoints, and retry failed tasks automatically.\n"
                 << "Compatibility: --retry-failed is accepted; retries are already automatic.\n"
                 << "Historical local inputs only: --resume-165 | --recover-failed-135\n";
        };
        if (argc == 2 && string(argv[1]) == "--help") {
            usage();
            return 0;
        }
        if (argc == 2 && string(argv[1]) == "--resume-165")
            return resume_con_spoly855_165();
        if (argc == 2 && string(argv[1]) == "--recover-failed-135")
            return recover_failed_135();
        RecoveryOptions options;
        for (int i = 1; i < argc; ++i) {
            const string arg(argv[i]);
            if (arg == "--retry-failed") continue;
            else if (arg == "--checkpoint-dir" && i + 1 < argc) {
                options.directory = argv[++i];
                if (options.directory.empty() || options.directory.front() == '-')
                    throw invalid_argument("--checkpoint-dir requires a directory");
            } else if ((arg == "--threads" || arg == "--batch-size") && i + 1 < argc) {
                const string value(argv[++i]);
                unsigned number = 0;
                const auto parsed = from_chars(value.data(), value.data() + value.size(), number);
                if (parsed.ec != errc() || parsed.ptr != value.data() + value.size()
                    || number == 0 || number > static_cast<unsigned>(numeric_limits<int>::max()))
                    throw invalid_argument(arg + " requires a positive integer <= INT_MAX");
                if (arg == "--threads") options.threads = static_cast<int>(number);
                else options.batch_size = number;
            } else {
                usage();
                throw invalid_argument("unknown or incomplete option: " + arg);
            }
        }
        fs::create_directories("LOG");
        return calculate_con_spoly855(options);
    }
    catch (const GRBException& e) {
        cerr << "[Gurobi error] code=" << e.getErrorCode()
             << " message=" << e.getMessage() << endl;
    }
    catch (const RecoveryError& e) {
        cerr << "[Recovery error] code=" << e.code
             << " message=" << e.what() << endl;
    }
    catch (const std::exception& e) {
        cerr << "[Program error] " << e.what() << endl;
    }
    return 1;
}
