#ifndef __LOG_H__
#define __LOG_H__
#include<chrono>
#include<iostream>
#include<fstream>
#include<string>
#include<sstream>
#include<thread>
#include <filesystem>

using namespace std;

typedef bool TIMETYPE;

const int DATEFLAG = false;
const int TIMEFLAG = true;

inline string getCurrentSystemTime(TIMETYPE type)
{
    auto tt = chrono::system_clock::to_time_t(std::chrono::system_clock::now());
    struct tm* ptm = localtime(&tt);
    char date[60] = { 0 };
    if ( type == DATEFLAG )
        sprintf( date, "%d-%02d-%02d", (int)ptm->tm_year + 1900, (int)ptm->tm_mon + 1, (int)ptm->tm_mday );
    else 
        sprintf( date, "%02d:%02d:%02d", (int) ptm->tm_hour, (int)ptm->tm_min, (int)ptm -> tm_sec);

    return string(date);
}

inline void logger( string logMsg )
{
    string filePath = "LOG/log_" + getCurrentSystemTime( DATEFLAG ) + "spoly.log"; 
    string now = getCurrentSystemTime(TIMEFLAG);
    ofstream os ( filePath.c_str(), ios_base::out | ios_base::app ); 
    os << now << "\t" << logMsg << "\n";
    os.close();
}


inline void loggerState(string logMsg,int rounds)
{
    string filePath = "./STATE/state_" + to_string(rounds) + ".log";
    ofstream os(filePath.c_str(), ios_base::out | ios_base::app);

    os << logMsg << "\n";
    os.close();
}

inline void loggerStream(stringstream& ss, int rounds)
{
    stringstream ss2;
    ss2 << this_thread::get_id();
    string threadIdStr;
    ss2 >> threadIdStr;

    string filePath = "./TERM/term_" + to_string(rounds) +"_" + threadIdStr + ".log";
    ofstream os(filePath.c_str(), ios_base::out | ios_base::app);

    os << ss.str() << "\n";
    os.close();
}

inline bool createFolder(const std::string& folderName) {
    try {
        // Check if the folder already exists
        if (std::filesystem::exists(folderName)) {
            std::cout << "Folder already exists: " << folderName << std::endl;
            return false; // Folder exists, return false
        }

        // Attempt to create the folder
        if (std::filesystem::create_directory(folderName)) {
            std::cout << "Folder created successfully: " << folderName << std::endl;
            return true; // Creation successful, return true
        } else {
            std::cout << "Failed to create folder: " << folderName << std::endl;
            return false; // Creation failed, return false
        }
    } catch (const std::filesystem::filesystem_error& e) {
        std::cerr << "Error: " << e.what() << std::endl;
        return false; // Exception occurred, return false
    }
}


#ifndef _WIN32
#include<unistd.h>
inline void showProcessMemUsage()
{
    double virMem = 0;
    double resMem = 0;

    fstream fs;
    fs.open("/proc/self/stat", ios_base::in);

    int dataCnt = 0;
    string dataStr;
    unsigned long virMemB, resMemP;
    while (fs >> dataStr)
    {
        dataCnt++;
        if (dataCnt == 22)
            break;
    }
    fs >> virMemB >> resMemP;

    fs.close();

    long page_size_kb = sysconf(_SC_PAGE_SIZE) / 1024;
    virMem = virMemB / 1024.0 / 1024.0 / 1024.0;
    resMem = resMemP * page_size_kb / 1024.0 / 1024.0;

    logger("Current virtual memory usage : " + to_string(virMem) + "G.");
    logger("Current resident memory usage : " + to_string(resMem) + "G.");
}
#endif


#endif
