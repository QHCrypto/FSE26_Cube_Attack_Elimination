#pragma once
#include <cmath>
#include <stdexcept>
#include <string>

constexpr double RECOVERY_PATH_SECONDS = 120.0;
constexpr double RECOVERY_FALLBACK_SECONDS = 120.0;
constexpr unsigned RECOVERY_STALLED_RETRY_LIMIT = 3;

class RecoveryError : public std::runtime_error {
public:
    int code;
    RecoveryError(const std::string& message, int status = -1)
        : std::runtime_error(message), code(status) {}
};
class RecoveryInterrupted : public RecoveryError {
public:
    explicit RecoveryInterrupted(int status) : RecoveryError("solver interrupted", status) {}
};

// Reject unusable numeric values instead of silently rounding a partial or
// invalid binary solution into a polynomial contribution.
inline bool recovery_binary(double value) {
    constexpr double tolerance = 1e-5;
    if (std::isfinite(value)) {
        if (std::abs(value) <= tolerance) return false;
        if (std::abs(value - 1.0) <= tolerance) return true;
    }
    throw RecoveryError("invalid binary solution value: " + std::to_string(value));
}

struct RecoveryOptions {
    std::string directory = "runs/recovery855_progress";
    int threads = 512;
    unsigned batch_size = 256;
};
int run_recovery855(const RecoveryOptions& options);
