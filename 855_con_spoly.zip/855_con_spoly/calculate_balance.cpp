#include <stdio.h>
#include <stdint.h>
#include <assert.h>
#include <time.h>
#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <sstream>
#include <cmath>
#include <random>
#include <algorithm>
#include <thread>
#include <bitset>
#include <mutex>
#include <chrono>
#include <iostream>
#include <cstdint>  // for uint8_t
#include <random>   // for random number generation
#include <algorithm> // for std::generate

// Generate random uint8_t array ks[k_num][10]
void generate_random_ks(uint8_t (&ks)[][10], size_t k_num) {
    // Random number generator (C++11 <random>)
    std::random_device rd;  // Hardware random seed
    std::mt19937 gen(rd()); // Mersenne Twister engine
    std::uniform_int_distribution<uint8_t> dist(0, 255); // Uniform distribution [0, 255]

    // Fill ks array
    for (size_t i = 0; i < k_num; ++i) {
        std::generate(ks[i], ks[i] + 10, [&]() { return dist(gen); });
    }
}

using namespace std;

typedef unsigned char u8;
typedef unsigned int u32;
typedef unsigned long long u64;

#define k_num 10000
#define basis_num 153

// Generate k values and return vector<string> directly
vector<string> generate_k_values() {
    uint8_t ks[k_num][10] = {};
    generate_random_ks(ks, k_num);
    
    vector<string> k_values;
    k_values.reserve(k_num);
    
    u8 key[10] = { 0 };
    
    for (int i = 0; i < k_num; i++) {
        for (int j = 0; j < 10; j++) {
            key[j] = ks[i][j];
        }
        
        u8 k[basis_num] = { 0 };
        for (int t = 0; t < 80; t++) {
            k[t] += (key[t / 8] >> (t % 8)) & 1;
        }
        
        // Include all original k value calculation parts
        k[80] += k[67] ^ 1;
        k[81] += k[66] ^ 1;
        k[82] += k[53] ^ (k[78] & k[79]);
        
        for (int t = 83; t < 136; t++) {
            k[t] += k[135 - t] ^ (k[160 - t] & k[161 - t]) ^ k[162 - t];
        }
        {
            k[136] += k[24] & k[25] ^ k[26] ^ k[68];
            k[137] += k[23] & k[24] ^ k[25] ^ k[80];
            k[138] += k[22] & k[23] ^ k[24] ^ k[81];
            k[139] += k[21] & k[22] ^ k[23] ^ k[65];
            k[140] += k[20] & k[21] ^ k[22] ^ k[64];
            k[141] += k[19] & k[20] ^ k[21] ^ k[63];
            k[142] += k[18] & k[19] ^ k[20] ^ k[62];
            k[143] += k[17] & k[18] ^ k[19] ^ k[61];
            k[144] += k[16] & k[17] ^ k[18] ^ k[60];
            k[145] += k[15] & k[16] ^ k[17] ^ k[59];
            k[146] += k[14] & k[15] ^ k[16] ^ k[58];
            k[147] += k[13] & k[14] ^ k[15] ^ k[57];
            k[148] += k[12] & k[13] ^ k[14] ^ k[56] ^ k[65];
            k[149] += k[11] & k[12] ^ k[13] ^ k[55] ^ k[64];
            k[150] += k[10] & k[11] ^ k[12] ^ k[54] ^ k[63];
            k[151] += k[9] & k[10] ^ k[11] ^ k[53] ^ k[62];
            k[152] += k[8] & k[9] ^ k[10] ^ k[52] ^ k[61];
        }        
        
        // Convert k values to string
        string k_str;
        k_str.reserve(basis_num);
        for (int index = 0; index < basis_num; ++index) {
            k_str += (k[index] ? '1' : '0');
        }
        
        k_values.push_back(move(k_str));
    }
    
    return k_values;
}

class ResultCollector {
    mutex mtx;
    bitset<k_num> results;
public:
    void set(size_t index, bool value) {
        lock_guard<mutex> lock(mtx);
        results.set(index, value);
    }
    
    bitset<k_num> get() const {
        return results;
    }
};

string read_boolean_function_from_file(const string& file_path) {
    ifstream file(file_path);
    if (!file.is_open()) {
        cerr << "Cannot open file: " << file_path << endl;
        return "";
    }
    
    string line;
    if (getline(file, line)) {
        return line;
    }
    return "";
}

vector<string> read_k_values_from_file(const string& file_path) {
    ifstream file(file_path);
    if (!file.is_open()) {
        cerr << "Cannot open file: " << file_path << endl;
        return {};
    }

    // Pre-estimate file size to reserve space
    file.seekg(0, ios::end);
    size_t file_size = file.tellg();
    file.seekg(0, ios::beg);
    
    vector<string> k_values;
    // Assume average line length is about 900 bytes
    k_values.reserve(file_size / 900 + 1);

    string line;
    while (getline(file, line)) {
        if (line.size() == 882) {
            k_values.push_back(move(line)); // Use move semantics
        }
    }
    return k_values;
}

string replace_variables(const string& expression, const string& k_values_line) {
    string result;
    result.reserve(expression.size() * 2); // Pre-allocate space
    
    for (size_t i = 0; i < expression.size(); ) {
        if (expression[i] == 'k' && i + 1 < expression.size() && isdigit(expression[i+1])) {
            // Extract the number after 'k'
            size_t j = i + 1;
            while (j < expression.size() && isdigit(expression[j])) {
                ++j;
            }
            
            int index = stoi(expression.substr(i+1, j-i-1));
            if (index >= 0 && index < 882) {
                result += '*';
                result += k_values_line[index];
            }
            i = j;
        } else {
            result += expression[i++];
        }
    }
    
    return result;
}

bool evaluate_boolean_function(const string& expression_with_values) {
    bool final_result = false;
    bool current_and_result = true;
    bool is_xor = false;

    for (char ch : expression_with_values) {
        if (ch == '0' || ch == '1') {
            current_and_result = current_and_result && (ch == '1');
        } else if (ch == '+') {
            final_result ^= current_and_result;
            current_and_result = true;
            is_xor = true;
        }
        // Ignore '*' character
    }

    return is_xor ? (final_result ^ current_and_result) : current_and_result;
}

void process_k_value_line(const string& boolean_expression, 
                         const string& k_values_line,
                         size_t index,
                         ResultCollector& collector) {
    string expression_with_values = replace_variables(boolean_expression, k_values_line);
    bool result = evaluate_boolean_function(expression_with_values);
    collector.set(index, result);
}

bitset<k_num> evaluate_boolean_functions_parallel(const string& boolean_function_file, 
                                                vector<string> k_values_lines) {
    ResultCollector collector;
    
    string boolean_expression = read_boolean_function_from_file(boolean_function_file);
    if (boolean_expression.empty()) {
        cerr << "Failed to read boolean function" << endl;
        return collector.get();
    }

    const size_t num_threads = thread::hardware_concurrency();
    vector<thread> threads;
    threads.reserve(num_threads);

    // Simple parallel processing: each thread processes a portion of data
    const size_t chunk_size = (k_values_lines.size() + num_threads - 1) / num_threads;
    
    for (size_t t = 0; t < num_threads; ++t) {
        threads.emplace_back([t, chunk_size, &boolean_expression, &k_values_lines, &collector]() {
            const size_t start = t * chunk_size;
            const size_t end = min((t + 1) * chunk_size, k_values_lines.size());
            
            for (size_t i = start; i < end; ++i) {
                process_k_value_line(boolean_expression, k_values_lines[i], i, collector);
            }
        });
    }

    for (auto& t : threads) {
        t.join();
    }

    return collector.get();
}

int main() {
    // Step 1: Generate k values
    cout << "Generating k values..." << endl;
    auto start_gen = chrono::high_resolution_clock::now();
    vector<string> k_values = generate_k_values();
    auto end_gen = chrono::high_resolution_clock::now();
    chrono::duration<double> elapsed_gen = end_gen - start_gen;
    cout << "K values generation time: " << elapsed_gen.count() << " seconds\n";
    cout << "Generated " << k_values.size() << " k value lines" << endl;
    
    // Step 2: Evaluate boolean functions
    string boolean_function_file = "/home/LHR/Practical_Trivium_attack/855_con_spoly/variable_z83_k61k63k100k102k124k126/dim45v1v3v5v7v9v12v14v16v18v20v22v24v27v29v31v33v35v37v39v42v44v46v48v50v52v54v57v59v61v63v65v67v72v74v76v78v70v68v0v69v2v11v10v13v79.txt";
    
    cout << "Evaluating boolean functions..." << endl;
    auto start_eval = chrono::high_resolution_clock::now();
    
    bitset<k_num> results = evaluate_boolean_functions_parallel(boolean_function_file, k_values);
    
    auto end_eval = chrono::high_resolution_clock::now();
    chrono::duration<double> elapsed_eval = end_eval - start_eval;
    cout << "Boolean function evaluation time: " << elapsed_eval.count() << " seconds\n";
    double pr = static_cast<double>(results.count()) / k_num;
    
    // Save results
    ofstream result_file("result.txt");
    result_file << "P(f=1): " << pr << endl;
    cout << "Results saved to result.txt" << endl;
    cout << "P(f=1): " << pr << endl;
    
    return 0;
}