#include "main.h"
//#include "num.h"
#include <algorithm> 
int dn = 0;

bool isInVector(const vector<int>& vec, int value) {
	return find(vec.begin(), vec.end(), value) != vec.end();
}

class initial_singular : public GRBCallback {
public:
	int evalNumRounds;
	int mode;
	int cube_size;
	int delta;
	vector<GRBVar> s;
public:
	initial_singular(int xevalNumRounds, int xmode, int xcube_size, int xdelta, vector<GRBVar> xs) {
		evalNumRounds = xevalNumRounds;
		mode = xmode;
		cube_size = xcube_size;
		delta = xdelta;
		s = xs;
	}
protected:
	void callback() override {
		try {
			if (where == GRB_CB_MIPSOL) {
				bitset<80> cube,k_degree;
				vector<int> cube_id;
				for (int i = 0; i < 80; ++i) {
					if (round(getSolution(s[i])) == 1) {
						cube_id.push_back(i);
						cube[i] = 1;
					}
				}
				
				
				
				int nd = trivium_numeric_degree_estimation(evalNumRounds, mode, cube, k_degree);
				cout << nd << endl;
				srand(static_cast<unsigned int>(time(0)));
				
				if (nd <= cube_size + delta) { 
					ofstream outputFile(to_string(evalNumRounds) + "_" + to_string(cube_size) + "_" + to_string(delta) + "_" + to_string(mode) + "solutions.txt", ios::app); 
					if (outputFile.is_open()) {
						for (int val : cube_id) {
							outputFile << val << " ";
							cout << val << " ";
						}
						outputFile << endl;
						cout << endl;
						// if (nd < cube_size) {
						// 	outputFile << nd << endl;						
						// }

						GRBLinExpr addCon = 0.0;
						for (int i : cube_id) {
							addCon += s[i];
						}
						addLazy(addCon <= cube_id.size()-1);
						// cout << "Solution saved to file: ";
						// for (int val : cube_id) {
						// 	cout << val << " ";
						// }
						// cout << endl;

						outputFile.close(); 
					}
					else {
						cerr << "Error: Unable to open output file." << endl;
					}
				}
				else {
					bool flag = true;
					while (flag) {
						int random_id = rand() % cube_id.size();
						vector<int> cubeid_copy = cube_id;
						cubeid_copy.erase(cubeid_copy.begin() + random_id);
						bitset<80> cube_copy;
						for (int j: cubeid_copy) {
							cube_copy[j] = 1;
							cout << j << " ";
						}
						cout << endl;
						nd = trivium_numeric_degree_estimation(evalNumRounds, mode, cube_copy, k_degree);
						cout << nd << endl;
						if (nd <= cube_size + delta) {
							GRBLinExpr addCon = 0.0;
							for (int i : cube_id) {
								addCon += s[i];
							}
							addLazy(addCon <= cube_id.size()-1);
							flag = false;
							break;
						}
						else {
							cube_id = cubeid_copy;
						}
					}

				}

				// GRBLinExpr addCon = 0.0;
				// for (int i = 0; i < 80; i++) {
				// 	if (cube[i] == 1) {
				// 		//cout << i << " ";
				// 		addCon += (1 - s[i]);
				// 	}
				// 	else {
				// 		addCon += s[i];
				// 	}
				// }
				// addLazy(addCon >= 1);

			}
		}
		catch (GRBException& e) {
			cerr << "Error during callback: " << e.getMessage() << endl;
		}
	}
};

void singular_1(int output_round, int output_mode, int cube_size, int delta) {
	
	bitset<80> k_degree;
	cout << endl;
	cout << "++++++++++++++++++++++++++++" << endl;
	cout << " cube_size :  " << cube_size << endl;
	int threadNumber = 128;
	//gurobi
	try {
		// Create the environment
		GRBEnv env = GRBEnv();
		// close standard output
		env.set(GRB_IntParam_LogToConsole, 0);
		env.set(GRB_IntParam_Threads, threadNumber);
		//env.set(GRB_IntParam_MIPFocus, GRB_MIPFOCUS_BESTBOUND);
		env.set(GRB_StringParam_LogFile, "log_trivium.txt");
		env.set(GRB_IntParam_PoolSearchMode, 2);
		env.set(GRB_IntParam_MIPFocus, 3);
		env.set(GRB_IntParam_PoolSolutions, 1);

		//env.set(GRB_IntParam_PoolSolutions, 20000000);
		env.set(GRB_DoubleParam_PoolGap, GRB_INFINITY);
		env.set(GRB_IntParam_LazyConstraints, 1);
		// Create the model
		GRBModel model = GRBModel(env);

		// Create variables
		vector<GRBVar> s(80);
		
		for (int i = 0; i < 80; i++) {
			s[i] = model.addVar(0, 1, 0, GRB_BINARY);
		}
		//trivium_numeric_degree_estimation(int output_round, int output_mode, bitset<80> v_degree, bitset<80> k_degree)
		
		//adj times 0
		GRBLinExpr k_var = 0.0;
		for (int i = 0; i < 79; i++) {
			GRBLinExpr adj = 0.0;
			adj += s[i] + s[i + 1];
			model.addConstr(adj <= 1);
			// GRBQuadExpr quadExpr = 0.0;
			// quadExpr = s[i]*s[i + 1];
			// model.addQConstr(quadExpr == 0);
			k_var += s[i];
		}
		k_var += s[79];
		model.addConstr(k_var == cube_size);

		initial_singular cb = initial_singular(output_round, output_mode, cube_size, delta, s);
		
		model.setCallback(&cb);

		model.optimize();


	}
	catch (GRBException e) {
		cerr << "Error code = " << e.getErrorCode() << endl;
		cerr << e.getMessage() << endl;
	}
	catch (...) {
		cerr << "Exception during optimization" << endl;
	}

}

class sol_found : public GRBCallback {
private:
	bool solutionFound; 
public:
	sol_found() : solutionFound(false) {}

	void callback() override {
		try {
			if (where == GRB_CB_MIPSOL) { 
				solutionFound = true;    
				abort();                 
			}
		}
		catch (GRBException& e) {
			cerr << "Error during callback: " << e.getMessage() << endl;
		}
	}

	bool hasFoundSolution() const {
		return solutionFound;
	}
};
