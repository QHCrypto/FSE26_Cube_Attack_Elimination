#include "main.h"
//#include "num.h"
#include <iostream>
#include <string>
#include <unordered_map>
#include <omp.h>
#include <ctime>
#include <fstream>
#include <thread>
#include <chrono>

using std::chrono::high_resolution_clock;
using std::chrono::duration_cast;
using std::chrono::seconds;


vector<vector<int>> readFileTo2DVector(const string& filePath) {
    ifstream inputFile(filePath);
    if (!inputFile.is_open()) {
        cerr << "Error: Unable to open file " << filePath << endl;
        return {};
    }   
    vector<vector<int>> result;
    string line;   
    while (getline(inputFile, line)) {        
        vector<int> row;
        stringstream ss(line);
        int number;        
        while (ss >> number) {
            row.push_back(number);
        }
        result.push_back(row);
    }
    inputFile.close();
    return result;
}

// Given a round and cube index, calculate the numeric degree
void Calculate_numeric_degree() {
	int target_round = 845;
	vector<int> cube_index = {0,2,4,6,8,10,12,15,17,19,21,23,25,27,30,32,34,36,38,40,42,47,49,51,53,55,57,60,62,64,66,71,73,75,77,79};
	bitset<80> k_degree;
	bitset<80> cube;
	for (int j : cube_index) {
		cube[j] = 1;
		cout << j << " ";
	}
	// One can change the output mode to get the numeric degree of different output functions
	int output_mode = 2; // 0: z1, 1: z2, 2: z3, 3: z4, 4: z5, 5: z6, others: max
	int num_deg = trivium_numeric_degree_estimation(target_round, output_mode, cube, k_degree);
	cout << num_deg << endl;
}

void initial_cube_search_840() {
	int output_round = 840;
	int output_mode = 0;
	int cube_size = 37;
	int delta = 0;
	auto start = chrono::high_resolution_clock::now();
	singular_1(output_round, output_mode, cube_size,delta);
	auto end = chrono::high_resolution_clock::now();
	chrono::duration<double, milli> elapsed = end - start;
	cout << "Elapsed time: " << elapsed.count() << " ms" << endl;
}


void initial_cube_search_845() {
	int output_round = 845;
	int output_mode = 6;
	int cube_size = 37;
	int delta = 3;
	auto start = chrono::high_resolution_clock::now();
	singular_1(output_round, output_mode, cube_size,delta);
	auto end = chrono::high_resolution_clock::now();
	chrono::duration<double, milli> elapsed = end - start;
	cout << "Elapsed time: " << elapsed.count() << " ms" << endl;
}


int main() {
	initial_cube_search_840();
	// initial_cube_search_845();
	// Calculate_numeric_degree();
	return 0;
}
