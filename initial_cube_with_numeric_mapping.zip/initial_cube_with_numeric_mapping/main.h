#include"gurobi_c++.h"
#include <string.h>
#include<iostream>
#include<fstream>
#include<string>
#include<sstream>
#include<vector>
#include<bitset>
#include<set>
#include<algorithm>
#include<map>
#include<iomanip>
#include<utility>
#include<math.h>
#include<time.h>
#include<stdlib.h>
#include <iterator>


#ifndef __MAIN_H__
#define __MAIN_H__

//#define N 542
#define N 542
#define M 80
#define INDEG -4096


#define BOUND 200000 //prevent out of memory
#define BOUND1 79
#define TIMELIMIT 1200 //time limit for optimizer


using namespace std;

int trivium_numeric_degree_estimation(int output_round, int output_mode, bitset<80> v_degree, bitset<80> k_degree);
void singular_1(int output_round, int output_mode, int cube_size, int delta);

//void singular_1(int output_round, int output_mode, int cube_size);
#endif
