//#include "main.h"
//#include "assert.h"
//
//#define INDEG -4096
//
////calculate numeric degree.
//int trivium_index[3][5] = { {65, 92, 170, 90, 91}, {161, 176, 263, 174, 175}, {242, 287, 68, 285, 286} };
//int trivium_length[3] = { 93, 84, 111 };
//
//
//void trivium_default_initial_numeric_degree(vector<int>& D, bitset<80> v_degree, bitset<80> k_degree)
//{
//	for (int i = 0; i < 80; i++)
//	{
//		if (k_degree[i] == 1)
//		{
//			;
//		}
//		else
//			D[i] = 0;
//
//		/*cout << "D"<< D[i][0] << "done!" << endl;*/
//	}
//	
//	for (int i = 93; i < 173; i++)
//	{
//		if (v_degree[i - 93] == 1)
//		{
//			D[i] = 1;
//		}
//
//	}
//	for (int i = 285; i < 288; i++)
//	{
//		D[i] = 0;
//	}
//	
//	
//}
//
//int trivium_numeric_deg_of_three_adjacent_terms(int k, vector<int> D, vector<int> mul_D, vector<int> three_D)
//{
//	int d1;
//	int m1, m2, m3;
//	m1 = three_D[trivium_index[k][3] - 1] + mul_D[trivium_index[k][4]];
//	m2 = three_D[trivium_index[k][4]] + mul_D[trivium_index[k][3]];
//	m3 = min(m1, m2);
//	m1 = three_D[trivium_index[k][3] - 1] + three_D[trivium_index[k][3]] + three_D[trivium_index[k][4]]; 
//	d1 = min(m3, m1);
//	return(d1);
//}
//
//int trivium_numeric_degree_of_mul_term(int r, int k, vector<int> D, vector<int> mul_D, vector<int> lin_D, vector<int> three_D)
//{
//	int mul_d;
//	int d1, d2, d3;
//	if (r < trivium_length[k])
//	{
//		mul_d = D[trivium_index[k][3]] + D[trivium_index[k][4]];
//	}
//	else
//	{
//		d1 = trivium_numeric_deg_of_three_adjacent_terms(k, D, mul_D, three_D);
//		d2 = mul_D[trivium_index[k][3]] + lin_D[trivium_index[k][4]];
//		d3 = lin_D[trivium_index[k][3]] + D[trivium_index[k][4]];
//		int a = max(d1, d2);
//		mul_d = max(a, d3);
//	}
//	return(mul_d);
//}
//
//void trivium_numeric_degree_update(int r, vector<int>& D, vector<int>& mul_D, vector<int>& lin_D, vector<int>& three_D)
//{
//	vector<int> mul_d, lin_d;
//	for (int i = 0; i < 3; i++)
//	{
//		mul_d.push_back(0);
//		lin_d.push_back(0);
//	}
//	for (int i = 0; i < 3; i++)
//	{
//		mul_d[i] = trivium_numeric_degree_of_mul_term(r, i, D, mul_D, lin_D, three_D);
//		int a = max(D[trivium_index[i][0]], D[trivium_index[i][1]]);
//		lin_d[i] = max(a, D[trivium_index[i][2]]);
//	}
//
//	for (int i = 0; i < 2; i++)
//	{
//		mul_D[trivium_index[i][1]] = mul_d[i];
//		lin_D[trivium_index[i][1]] = lin_d[i];
//		three_D[trivium_index[i][1]] = D[trivium_index[i][4]];
//		D[trivium_index[i][1]] = max(mul_d[i], lin_d[i]);
//	}
//	mul_D.pop_back();  mul_D.insert(mul_D.begin(), mul_d[2]);
//	lin_D.pop_back();  lin_D.insert(lin_D.begin(), lin_d[2]);
//	three_D.pop_back();  three_D.insert(three_D.begin(), D[trivium_index[2][4]]);
//	D.pop_back();  D.insert(D.begin(), max(mul_d[2], lin_d[2]));
//}
//
//int trivium_output_z(vector<int> D, int output_mode)
//{
//	if (output_mode == 1) {
//		return(D[trivium_index[0][0]]);
//	}
//	else {
//		int a1, a2, a3, b1, b2;
//		a1 = max(D[trivium_index[0][0]], D[trivium_index[0][1]]);
//		a2 = max(D[trivium_index[1][0]], D[trivium_index[1][1]]);
//		a3 = max(D[trivium_index[2][0]], D[trivium_index[2][1]]);
//		b1 = max(a1, a2);
//		b2 = max(b1, a3);
//		return(b2);
//	}
//}
//
//int trivium_numeric_degree_estimation(int output_round, int output_mode, bitset<80> v_degree, bitset<80> k_degree) {
//	vector<int> D, mul_D, lin_D, three_D;
//	for (int i = 0; i < 288; i++) {
//		D.push_back(INDEG);
//		mul_D.push_back(INDEG);
//		lin_D.push_back(INDEG);
//		three_D.push_back(INDEG);
//
//	}
//	trivium_default_initial_numeric_degree(D, v_degree, k_degree);
//	for (int i = 1; i <= output_round; i++)
//	{
//		
//		trivium_numeric_degree_update(i, D, mul_D, lin_D, three_D);
//
//	}
//	
//	return(trivium_output_z(D, output_mode));
//}

//void singular_1(int output_round, int output_mode, int cube_size);





